# -*- coding: utf-8 -*-
from apis._http import TIMEOUT_STANDARD
from caches.settings_cache import get_setting, set_setting
from caches.tmdb_lists import tmdb_lists_cache, tmdb_lists_cache_object
from modules.kodi_utils import confirm_dialog, logger, make_session, notification, progress_dialog, sleep
from modules.settings import max_threads
from modules.utils import TaskPool, copy2clip, launch_browser, make_qrcode

# from modules.kodi_utils import logger

session = make_session("https://api.themoviedb.org")


def _make_tinyurl(url):
	# Local to the TMDb auth flow only — the request_token is a long JWT, so the auth
	# URL is unwieldy on screen. Shorten it via tinyurl; "" on any failure (caller falls
	# back to the full URL).
	import requests

	try:
		response = requests.get("https://tinyurl.com/api-create.php", params={"url": url}, timeout=10)
		if response.status_code == 200:
			return response.text.strip()
	except Exception:
		pass
	return ""


class TMDbListFetchError(Exception):
	def __init__(self, message, http_status=0, status_code=0):
		super().__init__(message)
		self.http_status = http_status
		self.status_code = status_code


class TMDbListAPI:
	def __init__(self):
		self.base_url = "https://api.themoviedb.org/4"
		self.base_url_v3 = "https://api.themoviedb.org/3"
		self.read_access_token = get_setting("finder.tmdb_read_access_token", "").strip()
		if self.read_access_token == "empty_setting":
			self.read_access_token = ""

	def auth(self):
		import requests

		if not self.read_access_token:
			return notification("Enter your TMDb Read Access Token (V4) in Finder Settings > Meta Accounts > TMDb API")

		headers = {"accept": "application/json", "content-type": "application/json", "Authorization": "Bearer %s" % self.read_access_token}
		data = requests.post("%s/auth/request_token" % self.base_url, headers=headers, timeout=TIMEOUT_STANDARD).json()
		if not data.get("success") or "request_token" not in data:
			return notification(data.get("status_message") or "Failed to Auth Account")
		request_token = data["request_token"]
		token_url = "https://www.themoviedb.org/auth/access?request_token=%s" % request_token
		short_url = _make_tinyurl(token_url) or token_url
		qr_code = make_qrcode(short_url) or ""
		copy2clip(short_url)
		if confirm_dialog(
			heading="TMDb Account Authorization",
			text="Open the authorization page in your browser now?",
			ok_label="Open Browser",
			cancel_label="Use QR Code",
		):
			launch_browser(token_url)
		p_dialog_insert = "[CR]OR visit: [B]%s[/B] (copied to clipboard)" % short_url
		progressDialog = progress_dialog(heading="TMDb Account Authorization", icon=qr_code)
		count, success = 72, None
		while not progressDialog.iscanceled() and count >= 0 and success == None:
			try:
				count -= 1
				response = requests.post(
					"%s/auth/access_token" % self.base_url, json={"request_token": request_token}, headers=headers, timeout=TIMEOUT_STANDARD
				).json()
				if response.get("success") and response.get("access_token"):
					success = True
				progressDialog.update("Please Scan the QR Code%s[CR]Confirm Access to your TMDb Account" % p_dialog_insert, count)
				sleep(2500)
			except:
				success = False
		progressDialog.close()
		if success:
			success = self.add_tmdb3_to_session(response["access_token"], response["account_id"])
		tmdb_lists_cache.clear_all()
		notification("Success" if success else "Failed")

	def add_tmdb3_to_session(self, access_token, account_id):
		import requests

		headers = {"accept": "application/json", "content-type": "application/json", "Authorization": "Bearer %s" % self.read_access_token}
		response = requests.post(
			"https://api.themoviedb.org/3/authentication/session/convert/4", json={"access_token": access_token}, headers=headers, timeout=TIMEOUT_STANDARD
		).json()
		session_id = response.get("session_id")
		if response.get("success") and session_id:
			success = True
		else:
			success = False
		if success:
			response = requests.get(
				("https://api.themoviedb.org/3/account"), params={"session_id": session_id}, headers=headers, timeout=TIMEOUT_STANDARD
			).json()
			username, account_session_id = response.get("username"), response.get("id")
			if not account_session_id:
				success = False
		if success:
			set_setting("tmdb.token", access_token)
			set_setting("tmdb.account_id", account_id)
			set_setting("tmdb.username", username)
			set_setting("tmdb.session_id", session_id)
			set_setting("tmdb.account_session_id", str(account_session_id))
			return True
		return False

	def revoke(self):
		import requests

		# Best-effort remote delete of the *user's* access token (the v4 endpoint; the v3 path 404s).
		# Wrapped so a network/JSON error can't abort the local cleanup below.
		access_token = get_setting("finder.tmdb.token")
		if access_token and access_token != "empty_setting":
			headers = {"accept": "application/json", "content-type": "application/json", "Authorization": "Bearer %s" % self.read_access_token}
			try:
				requests.delete(
					"https://api.themoviedb.org/4/auth/access_token", json={"access_token": access_token}, headers=headers, timeout=TIMEOUT_STANDARD
				)
			except Exception:
				pass
		# Always clear local auth — the user's intent is to disconnect locally (re-auth / switch account).
		set_setting("tmdb.token", "empty_setting")
		set_setting("tmdb.account_id", "empty_setting")
		set_setting("tmdb.username", "empty_setting")
		set_setting("tmdb.session_id", "empty_setting")
		set_setting("tmdb.account_session_id", "empty_setting")
		tmdb_lists_cache.clear_all()
		return notification("Success! Auth Revoked")

	def get_user_lists(self):
		def fetch_page(page_no):
			result, http_status = self.request_data(url % (self.base_url, account_id, page_no), include_status=True)
			status_code = result.get("status_code", 0) if isinstance(result, dict) else 0
			if http_status == 401 or status_code in (3, 7, 10, 14, 16, 17, 30, 31, 32, 33, 35):
				raise TMDbListFetchError("TMDb authorization failed. Reauthorize TMDb in Finder Settings.", http_status, status_code)
			if http_status == 403 or status_code in (36, 38, 39, 45):
				raise TMDbListFetchError("TMDb denied access to your lists. Check your account authorization.", http_status, status_code)
			if http_status == 429:
				raise TMDbListFetchError("TMDb request limit reached. Please try again later.", http_status, status_code)
			if http_status >= 500 or not http_status:
				raise TMDbListFetchError("Unable to load TMDb lists. Please try again later.", http_status, status_code)
			if http_status >= 400 or not isinstance(result, dict) or result.get("success") is False or not isinstance(result.get("results"), list):
				raise TMDbListFetchError("TMDb returned an unexpected lists response. Please try again.", http_status, status_code)
			pages = result.get("total_pages", 1)
			if not isinstance(pages, int) or isinstance(pages, bool) or pages < 0:
				raise TMDbListFetchError("TMDb returned invalid list pagination. Please try again.", http_status, status_code)
			return result["results"], pages

		def _process_multi(page_no):
			try:
				page_results[page_no] = fetch_page(page_no)[0]
			except TMDbListFetchError as error:
				errors.append(error)

		def _process(dummy):
			first_page, total_pages = fetch_page(1)
			page_results[1] = first_page
			if total_pages > 1:
				threads = TaskPool().tasks(_process_multi, range(2, total_pages + 1), max_threads())
				[i.join() for i in threads]
			if errors:
				raise errors[0]
			return [item for page_no in sorted(page_results) for item in page_results[page_no]]

		account_id = get_setting("finder.tmdb.account_id")
		token = get_setting("finder.tmdb.token")
		if account_id in (None, "", "empty_setting") or token in (None, "", "empty_setting"):
			notification("Authorize TMDb in Finder Settings to access your lists.")
			from modules.auth_recovery import queue_reauthentication
			queue_reauthentication("tmdb")
			return None
		url = "%s/account/%s/lists?page=%s"
		page_results, errors = {}, []
		try:
			return tmdb_lists_cache_object(_process, "get_user_lists", "dummy")
		except TMDbListFetchError as error:
			# Log numeric diagnostics only: never account IDs, URLs, tokens or raw responses.
			logger("Finder TMDb Lists", "Fetch failed: HTTP %s, TMDb code %s" % (error.http_status, error.status_code))
			notification(str(error))
			if error.http_status == 401 or error.status_code in (3, 14, 16, 17, 30, 33, 35):
				from modules.auth_recovery import queue_reauthentication
				queue_reauthentication("tmdb")
			return None

	def get_watchfavrecs_list_details(self, list_id, media_type):
		def _process_multi(page_no):
			try:
				results_extend(
					[
						dict(i, **{"original_order": c})
						for c, i in enumerate(
							self.request_data(url % (self.base_url, account_id, media_type, list_id, page_no))["results"], (page_no * 20) - 20
						)
					]
				)
			except:
				pass

		def _process(dummy):
			result = self.request_data(url % (self.base_url, account_id, media_type, list_id, 1))
			results_extend([dict(i, **{"original_order": c}) for c, i in enumerate(result["results"])])
			total_pages = result["total_pages"]
			if list_id == "recommendations":
				total_pages = 2
			if total_pages > 1:
				threads = TaskPool().tasks(_process_multi, range(2, total_pages + 1), max_threads())
				[i.join() for i in threads]
			return results

		account_id = get_setting("finder.tmdb.account_id")
		string = "get_watchfavrecs_list_details_%s_%s" % (list_id, media_type)
		url = "%s/account/%s/%s/%s?page=%s"
		if list_id == "recommendations":
			url += "&language=en-US&region=US"
		results = []
		results_extend = results.extend
		return tmdb_lists_cache_object(_process, string, "dummy")

	def get_list_details(self, list_id):
		def _process_multi(page_no):
			try:
				results_extend(
					[
						dict(i, **{"original_order": c})
						for c, i in enumerate(self.request_data(url % (self.base_url, list_id, page_no))["results"], (page_no * 20) - 20)
					]
				)
			except:
				pass

		def _process(dummy):
			result = self.request_data(url % (self.base_url, list_id, 1))
			results_extend([dict(i, **{"original_order": c}) for c, i in enumerate(result["results"])])
			total_pages = result["total_pages"]
			if total_pages > 1:
				threads = TaskPool().tasks(_process_multi, range(2, total_pages + 1), max_threads())
				[i.join() for i in threads]
			return results

		string = "get_list_details_%s" % (list_id)
		url = "%s/list/%s?page=%s"
		results = []
		results_extend = results.extend
		return tmdb_lists_cache_object(_process, string, "dummy")

	def add_remove_from_list(self, list_id, items, action):
		url = "%s/list/%s/items" % (self.base_url, list_id)
		return self.request_data(url, data=items, method=action)

	def add_remove_from_watchfavs(self, media_type, media_id, list_type, status):
		if list_type == "favorites":
			list_type = "favorite"
		account_session_id = get_setting("tmdb.account_session_id")
		session_id = get_setting("tmdb.session_id")
		if "empty_setting" in [account_session_id, session_id]:
			notification("Please Re-Authenticate you TMDB account")
			return {"success": False}
		url = "%s/account/%s/%s" % (self.base_url_v3, account_session_id, list_type)
		return self.request_data(
			url, params={"session_id": session_id}, data={"media_type": media_type, "media_id": str(media_id), list_type: status}, method="post"
		)

	def make_list(self, list_name):
		url = "%s/list" % self.base_url
		return self.request_data(url, data={"description": "", "name": list_name, "iso_3166_1": "US", "iso_639_1": "en", "public": True}, method="post")

	def delete_list(self, list_id):
		url = "%s/list/%s" % (self.base_url, list_id)
		return self.request_data(url, method="delete")

	def rename_list(self, list_id, new_name):
		data = {"description": "", "name": new_name, "iso_3166_1": "US", "iso_639_1": "en", "public": True}
		url = "%s/list/%s" % (self.base_url, list_id)
		return self.request_data(url, data=data, method="put")

	def clear_list(self, list_id):
		url = "%s/list/%s/clear" % (self.base_url, list_id)
		return self.request_data(url)

	def item_status(self, list_id, media_type, media_id):
		url = "%s/list/%s/item_status" % (self.base_url, list_id)
		return self.request_data(url, params={"media_type": media_type, "media_id": int(media_id)})

	def request_data(self, url, params=None, data=None, method="get", include_status=False):
		headers = {"accept": "application/json", "content-type": "application/json", "Authorization": "Bearer %s" % get_setting("finder.tmdb.token")}
		http_status = 0
		try:
			response = session.request(method, url, params=params, json=data, headers=headers, timeout=90)
			http_status = response.status_code
			result = response.json()
		except Exception:
			result = None
		if http_status == 401 and "/auth/" not in url:
			from modules.auth_recovery import queue_reauthentication
			queue_reauthentication("tmdb")
		return (result, http_status) if include_status else result


tmdb_list_api = TMDbListAPI()
