# -*- coding: utf-8 -*-
import sys

from modules.router import routing, sys_exit_check


# First-run onboarding is owned exclusively by service.py / PrimaryTrackerStartup.
# Normal menu and widget plugin invocations must never present Welcome or race
# the service while a skin transition is in progress.


routing(sys)
if sys_exit_check():
	sys.exit(1)
