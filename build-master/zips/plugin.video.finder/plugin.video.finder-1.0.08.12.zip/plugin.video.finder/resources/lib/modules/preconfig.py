# -*- coding: utf-8 -*-

import xbmc
import xbmcgui

from caches.settings_cache import get_setting, set_setting
from modules.kodi_utils import get_property


_PRESETS = {
    "punchplay_collection": {
        "watched_indicators": "2",
        "primary_tracker_selected": "2",
        "quick_add_target": "punchplay_collection",
        "quick_add_label": "PunchPlay Collection",
    },
    "punchplay_watchlist": {
        "watched_indicators": "2",
        "primary_tracker_selected": "2",
        "quick_add_target": "punchplay_watchlist",
        "quick_add_label": "PunchPlay Watchlist",
    },
    "tmdb_watchlist": {
        "watched_indicators": "0",
        "primary_tracker_selected": "0",
        "quick_add_target": "tmdb_watchlist",
        "quick_add_label": "TMDb Watchlist",
    },
    "trakt_collection": {
        "watched_indicators": "1",
        "primary_tracker_selected": "1",
        "quick_add_target": "trakt_collection",
        "quick_add_label": "Trakt Collection",
    },
    "trakt_watchlist": {
        "watched_indicators": "1",
        "primary_tracker_selected": "1",
        "quick_add_target": "trakt_watchlist",
        "quick_add_label": "Trakt Watchlist",
    },
}


def apply(params):
    preset = params.get("preset", "")
    config = _PRESETS.get(preset)
    if not config:
        xbmc.log("###Finder###: Pre-Config unknown preset: %s" % preset, xbmc.LOGERROR)
        return

    try:
        # Write all four Finder settings before touching the skin.  ReloadSkin is
        # intentionally owned by this function so the XML cannot interrupt a
        # partially completed configuration.
        set_setting("watched_indicators", config["watched_indicators"])
        set_setting("primary_tracker_selected", config["primary_tracker_selected"])
        set_setting("context_menu.quick_add_target", config["quick_add_target"])
        set_setting("context_menu.quick_add_target_label", config["quick_add_label"])
        xbmc.executebuiltin("Skin.SetString(FinderHomePreset,%s)" % preset)

        verified = (
            get_setting("watched_indicators", "") == config["watched_indicators"]
            and get_setting("primary_tracker_selected", "") == config["primary_tracker_selected"]
            and get_setting("finder.context_menu.quick_add_target", "") == config["quick_add_target"]
            and get_setting("finder.context_menu.quick_add_target_label", "") == config["quick_add_label"]
        )
        xbmc.log(
            "###Finder###: Pre-Config applied: %s | watched=%s | tracker=%s | quick_add=%s | verified=%s"
            % (
                preset,
                config["watched_indicators"],
                config["primary_tracker_selected"],
                config["quick_add_target"],
                verified,
            ),
            xbmc.LOGINFO,
        )
        if not verified:
            xbmc.log("###Finder###: Pre-Config verification failed: %s" % preset, xbmc.LOGERROR)
            return

        # Keep the Finder Skin's legacy setup gate in sync with Finder's
        # verified preset. Home.xml still guards its legacy 1158 selector with
        # Finder.InitialSetupComplete; without this, 1158 can resurface after
        # the successful first-run authorization/reload even though 1159 has
        # already completed the configuration.
        xbmc.executebuiltin("Skin.SetBool(Finder.InitialSetupComplete)")

        # Mark this pre-config as awaiting its post-authorization rebuild.
        # The startup service consumes the flag only after the selected tracker
        # is confirmed ready, preventing ReloadSkin on ordinary Kodi startups.
        xbmcgui.Window(10000).setProperty("finder.first_run_preconfig_pending", "true")
        if get_setting("first_run_setup_pending", "false") != "true":
            # Manual Pre-Config changes still apply immediately. First-run setup
            # defers this reload until the selected tracker is fully authorized.
            xbmc.executebuiltin("ReloadSkin()")
    except Exception as exc:
        xbmc.log("###Finder###: Pre-Config failed for %s: %s" % (preset, exc), xbmc.LOGERROR)
