# -*- coding: utf-8 -*-
"""Queue one service-specific recovery question after an explicit auth rejection."""
from time import time

SERVICES = {
	"tmdb": ("TMDb", "tmdblist_api.authenticate"),
	"trakt": ("Trakt", "trakt.trakt_authenticate"),
	"punchplay": ("PunchPlay", "punchplay.punchplay_authenticate"),
	"rd": ("Real-Debrid", "real_debrid.authenticate"),
	"pm": ("Premiumize", "premiumize.authenticate"),
	"ad": ("AllDebrid", "alldebrid.authenticate"),
	"tb": ("TorBox", "torbox.authenticate"),
	"easynews": ("Easynews", None),
}
PREFIX = "finder.auth_recovery."
COOLDOWN = 300


def _declined(service):
	from caches.settings_cache import get_setting
	return get_setting("auth_recovery_declined_" + service) == "true"


def _set_declined(service, declined):
	from caches.settings_cache import set_setting
	set_setting("auth_recovery_declined_" + service, "true" if declined else "false")


def queue_reauthentication(service):
	from modules import kodi_utils
	if service not in SERVICES or _declined(service) or kodi_utils.get_property(PREFIX + "active") == "true":
		return False
	try:
		last_prompt = float(kodi_utils.get_property(PREFIX + service + ".last") or 0)
	except ValueError:
		last_prompt = 0
	if time() - last_prompt < COOLDOWN:
		return False
	kodi_utils.set_property(PREFIX + service + ".pending", "true")
	return True


def dispatch_pending_reauthentication():
	from modules import kodi_utils
	# Use the existing service loop: no polling worker per failed API request.
	if kodi_utils.get_property(PREFIX + "active") == "true" or kodi_utils.get_property("finder.pause_services") == "true":
		return
	if kodi_utils.kodi_player().isPlaying() or kodi_utils.get_window_id() not in (10000, 10001, 10002, 10003, 10005, 10025):
		return
	import xbmcgui
	if xbmcgui.getCurrentWindowDialogId() != 9999:
		return
	for service in SERVICES:
		key = PREFIX + service + ".pending"
		if kodi_utils.get_property(key) != "true":
			continue
		kodi_utils.clear_property(key)
		if _declined(service):
			continue
		try:
			last_prompt = float(kodi_utils.get_property(PREFIX + service + ".last") or 0)
		except ValueError:
			last_prompt = 0
		if time() - last_prompt < COOLDOWN:
			continue
		kodi_utils.set_property(PREFIX + service + ".last", str(time()))
		kodi_utils.set_property(PREFIX + "active", "true")
		try:
			kodi_utils.execute_builtin("RunPlugin(plugin://plugin.video.finder/?mode=service_reauthenticate_choice&service=%s)" % service)
		except Exception:
			kodi_utils.clear_property(PREFIX + "active")
		return


def prompt_reauthentication(service, initial=False):
	from modules import kodi_utils
	try:
		if service not in SERVICES:
			return False
		label, mode = SERVICES[service]
		answer = kodi_utils.confirm_dialog(
			heading="%s Authorization" % label,
			text=("Would you like to authorize %s?" % label) if initial else ("%s could not accept your authorization. Would you like to reauthorize %s?" % (label, label)),
			ok_label="Yes", cancel_label="No", default_control=11,
		)
		if answer is not True:
			_set_declined(service, True)
			return False
		_set_declined(service, False)
		if service == "easynews":
			kodi_utils.open_settings()
		else:
			kodi_utils.execute_builtin("RunPlugin(plugin://plugin.video.finder/?mode=%s)" % mode)
		return True
	finally:
		kodi_utils.clear_property(PREFIX + "active")
