# -*- coding: utf-8 -*-
"""Finder interface mode selection and first-run skin handoff.

Finder owns first-run sequencing. skin.finder may be present in the repository,
but it is installed/activated only after the user selects the integrated mode.
"""
from time import sleep, time

import xbmc
import xbmcaddon
import xbmcgui
from xbmcgui import Dialog

from caches.settings_cache import get_setting, set_setting
from modules.kodi_utils import logger, set_property

SETTING_ID = "interface_mode"
INTEGRATED = "integrated"
STANDALONE = "standalone"
SKIN_ID = "skin.finder"


def finder_skin_active():
    try:
        return xbmc.getSkinDir() == SKIN_ID
    except Exception:
        return False


def finder_skin_installed():
    try:
        xbmcaddon.Addon(SKIN_ID)
        return True
    except Exception:
        return False


def _wait_for_skin_installed(timeout=60):
    deadline = time() + timeout
    while time() < deadline:
        if finder_skin_installed():
            return True
        sleep(0.25)
    return False


def _activate_finder_skin():
    """Install Finder Skin on demand and hand activation back to Kodi.

    Kodi performs LoadSkin asynchronously.  Do not poll xbmc.getSkinDir() from
    this same Python invocation: Test 4A proved that value can remain stale even
    after Kodi has already unloaded the old skin and loaded skin.finder.
    """
    installed = finder_skin_installed()
    active = finder_skin_active()
    logger("Finder", "TEST 4C: integrated skin state installed=%s active=%s" % (installed, active))

    if not installed:
        install = Dialog().yesno(
            "Finder - Finder Skin",
            "Finder Skin is not currently installed.\n\nWould you like to install and activate Finder Skin?",
        )
        if not install:
            logger("Finder", "TEST 4C: Finder Skin installation declined; integrated setup deferred")
            return False

        Dialog().notification(
            "Setting Up Finder Skin",
            "Installing Finder Skin. Please stand by...",
            xbmcgui.NOTIFICATION_INFO,
            5000,
        )
        logger("Finder", "TEST 4C: requesting InstallAddon(skin.finder)")
        xbmc.executebuiltin("InstallAddon(%s)" % SKIN_ID, True)
        if not _wait_for_skin_installed():
            logger("Finder", "TEST 4C: Finder Skin installation timed out")
            Dialog().ok("Finder - Finder Skin", "Finder Skin could not be installed.\n\nFinder setup will be deferred.")
            return False
        logger("Finder", "TEST 4C: Finder Skin installation verified")

    if not finder_skin_active():
        # Commit the user's choice BEFORE changing skins.  The skin switch can
        # tear down windows and start widget plugin calls immediately; those
        # calls must see an integrated first-run already in progress.
        set_setting(SETTING_ID, INTEGRATED)
        set_setting("first_run_setup_pending", "true")
        set_setting("first_run_stage", "activating_skin")
        Dialog().notification(
            "Setting Up Finder Skin",
            "Activating Finder Skin. Please stand by...",
            xbmcgui.NOTIFICATION_INFO,
            5000,
        )
        logger("Finder", "TEST 4C: requesting LoadSkin(skin.finder); activation handoff committed")
        xbmc.executebuiltin("LoadSkin(%s)" % SKIN_ID)
        # Test 4A showed Kodi completed the actual switch in about half a second.
        # Give the GUI time to settle, but do not turn elapsed time into failure.
        sleep(1.5)
    else:
        set_setting(SETTING_ID, INTEGRATED)
        set_setting("first_run_setup_pending", "true")

    set_setting("first_run_stage", "preconfig")
    logger("Finder", "TEST 4C: activation handoff complete; proceeding directly to Pre-Config")
    return True


def _choose():
    dialog = Dialog()
    options = [
        "Finder + Finder Skin",
        "Finder Standalone",
    ]
    choice = dialog.select("Welcome to Finder", options)
    if choice < 0:
        return None
    return INTEGRATED if choice == 0 else STANDALONE


def ensure_mode():
    """Run Finder's first-use choice once, then return the stored mode."""
    current = get_setting(SETTING_ID, "empty_setting")
    if current in (INTEGRATED, STANDALONE):
        return current

    # Preserve the repository/add-ons location beneath the modal Welcome dialog.
    # After authorization and the final skin rebuild Finder restores this path,
    # leaving navigation/back-out under the user's control.
    try:
        return_window = xbmcgui.getCurrentWindowId()
        return_path = xbmc.getInfoLabel("Container.FolderPath")
        if return_path.startswith("addons://"):
            set_setting("first_run_return_window", str(return_window))
            set_setting("first_run_return_path", return_path)
            logger("Finder", "First-run: saved Add-ons return context: %s | %s" % (return_window, return_path))
    except Exception as exc:
        logger("Finder", "First-run: could not save Add-ons return context: %s" % exc)

    logger("Finder", "FIRST-RUN ARCHITECTURE TEST 4C | presenting Welcome to Finder")
    choice = _choose()
    if choice is None:
        logger("Finder", "Interface selection cancelled; startup deferred")
        return None

    logger("Finder", "TEST 4C: interface choice selected: %s" % choice)

    if choice == INTEGRATED:
        # Persist the first-run handoff before changing skins. preconfig.apply
        # runs in a separate plugin invocation and must know not to reload yet.
        set_property("finder.first_run_interface_setup", "true")
        set_setting("first_run_setup_pending", "true")
        if not _activate_finder_skin():
            return None
        set_setting(SETTING_ID, INTEGRATED)
        logger("Finder", "TEST 4C: opening Finder Skin Pre-Config without repeating Welcome")
        xbmc.executebuiltin("ActivateWindow(1159)")
        return INTEGRATED

    set_setting(SETTING_ID, STANDALONE)
    logger("Finder", "Interface mode selected: standalone")
    return STANDALONE


def setup():
    """Tools entry: change the saved interface mode later."""
    current = get_setting(SETTING_ID, "empty_setting")
    current_label = {
        INTEGRATED: "Finder + Finder Skin",
        STANDALONE: "Finder Standalone",
    }.get(current, "Not selected")

    choice = Dialog().select(
        "Finder Interface Setup",
        [
            "Finder + Finder Skin",
            "Finder Standalone",
        ],
    )
    if choice < 0:
        return

    selected = INTEGRATED if choice == 0 else STANDALONE
    if selected == INTEGRATED:
        if not _activate_finder_skin():
            logger("Finder", "Interface Setup could not activate Finder Skin")
            return
        set_setting(SETTING_ID, selected)
        logger("Finder", "Interface mode changed: %s -> %s" % (current_label, selected))
        xbmc.executebuiltin("ActivateWindow(1159)")
        return

    set_setting(SETTING_ID, selected)
    logger("Finder", "Interface mode changed: %s -> %s" % (current_label, selected))
