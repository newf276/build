"""Finder services used by the adapted TMDb ExtendedInfo windows."""
import json
import threading
from urllib.parse import urlencode

import xbmc

from caches.main_cache import main_cache
from modules import kodi_utils, settings, watched_status


def media_kind(kind):
    return "tvshow" if kind == "tv" else kind


def play(tmdb_id, kind, season=None, episode=None, title=""):
    if kind in ("tv", "season"):
        params = {"tmdb_id": str(tmdb_id), "mode": "build_season_list"}
        if kind == "season":
            params.update(mode="build_episode_list", season=str(season))
        xbmc.executebuiltin("Dialog.Close(all,true)")
        kodi_utils.activate_window(params)
        return
    params = {"mode": "playback.%s" % settings.playback_key(),
              "tmdb_id": str(tmdb_id), "media_type": kind,
              settings.playback_key(): settings.playback_key()}
    if kind == "episode":
        params.update(season=str(season), episode=str(episode))
    xbmc.executebuiltin("Dialog.Close(all,true)")
    xbmc.executebuiltin("RunPlugin(%s)" % kodi_utils.build_url(params))


def options(tmdb_id, kind, season=None, episode=None, title=""):
    from indexers.dialogs import options_menu_choice
    params = {"tmdb_id": str(tmdb_id), "content": media_kind(kind),
              "is_external": "true", "from_extras": "true"}
    if season is not None:
        params["season"] = str(season)
    if episode is not None:
        params["episode"] = str(episode)
    return options_menu_choice(params)


def trailer(tmdb_id, kind, season=None, episode=None):
    # Use Finder's established trailer selection and playback route.
    params = {"mode": "play_trailer_choice", "tmdb_id": str(tmdb_id),
              "media_type": "movie" if kind == "movie" else "tvshow"}
    from indexers.dialogs import play_trailer_choice
    return play_trailer_choice(params)


def sync():
    """Refresh the selected tracker; never change the user's tracker selection."""
    tracker = settings.watched_indicators()
    kodi_utils.show_busy_dialog()
    try:
        if tracker == 1:
            from apis.trakt_api import trakt_sync_activities
            trakt_sync_activities(force_update=True)
        elif tracker == 2:
            from caches.punchplay_cache import rebuild_from_server
            if not rebuild_from_server(silent=False):
                return False
        watched_provider.reset()
        kodi_utils.notification("Watched status refreshed")
        return True
    except Exception as exc:
        kodi_utils.logger("Finder ExtendedInfo sync", str(exc), "error")
        kodi_utils.notification("Tracker sync failed; check the log")
        return False
    finally:
        kodi_utils.hide_busy_dialog()


class WatchedProvider:
    def __init__(self):
        self.lock = threading.RLock()
        self.reset()

    def reset(self):
        with self.lock:
            self.movies = None
            self.episodes = {}

    def is_movie_watched(self, tmdb_id):
        with self.lock:
            if self.movies is None:
                self.movies = watched_status.watched_info_movie()
            return bool(watched_status.get_watched_status_movie(self.movies, str(tmdb_id)))

    def episode_rows(self, tmdb_id):
        with self.lock:
            key = str(tmdb_id)
            if key not in self.episodes:
                self.episodes[key] = set(watched_status.watched_info_episode(key))
            return self.episodes[key]

    def is_episode_watched(self, tmdb_id, season, episode):
        return (int(season), int(episode)) in self.episode_rows(tmdb_id)

    def get_episode_watched_count(self, tmdb_id):
        return sum(1 for season, episode in self.episode_rows(tmdb_id) if season > 0)

    def get_season_watched_count(self, tmdb_id, season):
        return sum(1 for s, episode in self.episode_rows(tmdb_id) if s == int(season))


watched_provider = WatchedProvider()


class TVMetaCache:
    def get_tv_meta_from_db(self, tmdb_id):
        return main_cache.get("finder_extended_tv_total_%s" % tmdb_id) or 0

    def set_tv_meta_to_db(self, tmdb_id, count):
        main_cache.set("finder_extended_tv_total_%s" % tmdb_id, count, expiration=24)


tv_meta_cache = TVMetaCache()


def tmdb_data(endpoint, params=None):
    from apis.tmdb_api import session
    args = dict(params or {})
    args.setdefault("language", "en-US")
    args.setdefault("include_image_language", "en,null")
    args.setdefault("include_video_language", "en,null")
    key = "finder_extended_tmdb_" + endpoint + "_" + urlencode(sorted(args.items()))
    cached = main_cache.get(key)
    if cached is not None:
        return cached
    args["api_key"] = settings.tmdb_api_key()
    try:
        response = session.get("https://api.themoviedb.org/3/" + endpoint,
                               params=args, timeout=10)
        response.raise_for_status()
        result = response.json()
        if not isinstance(result, dict) or result.get("success") is False:
            return {}
        main_cache.set(key, result, expiration=24)
        if endpoint.startswith("tv/") and "number_of_episodes" in result:
            tv_meta_cache.set_tv_meta_to_db(endpoint.split("/")[1], result["number_of_episodes"])
        return result
    except Exception as exc:
        # Do not log full URLs containing the user's API key.
        kodi_utils.logger("Finder ExtendedInfo", "Metadata request failed: %s (%s)" % (endpoint, type(exc).__name__), "error")
        return {}


_library = {}


def library(kind):
    """Read each Kodi library once per ExtendedInfo navigation session."""
    if kind in _library:
        return _library[kind]
    movie = kind == "movie"
    props = ["uniqueid", "playcount"] if movie else ["uniqueid", "watchedepisodes", "episode"]
    query = {"jsonrpc": "2.0", "id": 1,
             "method": "VideoLibrary.GetMovies" if movie else "VideoLibrary.GetTVShows",
             "params": {"properties": props}}
    try:
        data = json.loads(xbmc.executeJSONRPC(json.dumps(query)))
        result = {}
        for row in data.get("result", {}).get("movies" if movie else "tvshows", []):
            tmdb_id = row.get("uniqueid", {}).get("tmdb")
            if not tmdb_id:
                continue
            if movie:
                result[str(tmdb_id)] = {"dbid": row["movieid"], "playcount": row.get("playcount", 0)}
            else:
                watched, total = row.get("watchedepisodes", 0), row.get("episode", 0)
                result[str(tmdb_id)] = {"dbid": row["tvshowid"], "watched": watched,
                                        "unwatched": max(0, total - watched),
                                        "playcount": int(total > 0 and watched >= total)}
        _library[kind] = result
    except Exception:
        _library[kind] = {}
    return _library[kind]


def begin_session():
    watched_provider.reset()
    _library.clear()
