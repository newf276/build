from windows.extras.text_media import ShowTextMedia

__all__ = ["ShowTextMedia"]
