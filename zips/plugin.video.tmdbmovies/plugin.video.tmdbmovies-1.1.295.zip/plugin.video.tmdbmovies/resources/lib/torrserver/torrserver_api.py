import requests
from requests.auth import HTTPBasicAuth
from json import dumps
try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote
import xbmc
import os
import hashlib
import base64
import re


def log(msg):
    try:
        from resources.lib.scraper import log as scraper_log
        scraper_log(msg)
    except:
        xbmc.log("[TorrServer API] %s" % msg)


def extract_hash_from_magnet(magnet):
    try:
        match = re.search(r'btih:([a-fA-F0-9]{40})', magnet)
        if match:
            return match.group(1).lower()
        match = re.search(r'btih:([A-Za-z2-7]{32})', magnet)
        if match:
            decoded = base64.b32decode(match.group(1).upper())
            return decoded.hex()
    except:
        pass
    return None


def _normalize_response(data):
    if not data or not isinstance(data, dict):
        return data
    mappings = {
        'Hash': 'hash', 'Stat': 'stat', 'FileStats': 'file_stats',
        'Title': 'title', 'Poster': 'poster',
        'DownloadSpeed': 'download_speed', 'UploadSpeed': 'upload_speed',
        'ActivePeers': 'active_peers', 'TotalPeers': 'total_peers',
    }
    for pascal, lower in mappings.items():
        if pascal in data and lower not in data:
            data[lower] = data[pascal]
    file_stats = data.get('file_stats')
    if file_stats and isinstance(file_stats, list):
        for fs in file_stats:
            if isinstance(fs, dict):
                fs_map = {
                    'Id': 'id', 'Path': 'path', 'Length': 'length',
                    'PreloadedBytes': 'preloaded_bytes',
                    'PreloadSize': 'preload_size',
                }
                for p, l in fs_map.items():
                    if p in fs and l not in fs:
                        fs[l] = fs[p]
    return data


class TorrServer(object):
    def __init__(self, host, port, username, password, ssl_enabled=False):
        self._base_url = "{}://{}:{}".format(
            "https" if ssl_enabled else "http", host, port
        )
        self._username = username
        self._password = password
        self._auth = HTTPBasicAuth(self._username, self._password)
        self._session = requests.Session()
        self._info_cache = {}
        self._cache_time = {}

    def log(self, msg):
        log("### [TorrServer API]: %s" % msg)

    def list_torrents(self):
        try:
            payload = {"action": "list"}
            res = self._post("/torrents",
                             data=dumps(payload),
                             headers={'Content-Type': 'application/json'})
            if res.status_code == 200:
                data = res.json()
                if isinstance(data, list):
                    return [_normalize_response(item) for item in data
                            if isinstance(item, dict)]
                return []
            return []
        except Exception as e:
            self.log("list_torrents error: %s" % str(e))
            return []

    def _wp(self):
        import xbmcgui
        return xbmcgui.Window(10000)

    def _get_tracked(self):
        try:
            v = self._wp().getProperty('tmdbmovies.torrserver_tracked')
            return v or ''
        except:
            return ''

    def _set_tracked(self, val):
        try:
            self._wp().setProperty('tmdbmovies.torrserver_tracked', val)
        except:
            pass

    def _get_current_hash(self):
        try:
            v = self._wp().getProperty('tmdbmovies.torrserver_current_hash')
            return v or ''
        except:
            return ''

    def _set_current_hash(self, val):
        try:
            self._wp().setProperty('tmdbmovies.torrserver_current_hash', val)
        except:
            pass

    def cleanup_tracked_hashes(self, addon=None):
        try:
            saved = self._get_tracked()
            if not saved:
                return 0
            hashes = [h.strip() for h in saved.split('|') if h.strip()]
            removed = 0
            for h in hashes:
                try:
                    if self.remove_torrent(h):
                        self.log("Cleanup: removed %s" % h[:16])
                        removed += 1
                    else:
                        self.log("Cleanup: failed to remove %s (may not exist)" % h[:16])
                except:
                    pass
            self._set_tracked('')
            self._set_current_hash('')
            if removed:
                self.log("Cleanup complet: %d torrent(e) sterse" % removed)
            return removed
        except Exception as e:
            self.log("cleanup_tracked error: %s" % str(e))
            return 0

    def save_hash_to_settings(self, addon=None, info_hash=None):
        try:
            self._set_current_hash(info_hash)
            existing = self._get_tracked()
            hashes = [h.strip() for h in existing.split('|') if h.strip()]
            if info_hash not in hashes:
                hashes.append(info_hash)
            hashes = hashes[-5:]
            self._set_tracked('|'.join(hashes))
            self.log("Hash saved to settings: %s (total tracked: %d)" % (
                info_hash[:16], len(hashes)))
        except Exception as e:
            self.log("save_hash error: %s" % str(e))

    def cleanup_current(self, addon=None):
        try:
            current = self._get_current_hash()
            if current:
                self.remove_torrent(current)
                self.log("Cleanup current: %s" % current[:16])
                self._set_current_hash('')
                existing = self._get_tracked()
                hashes = [h.strip() for h in existing.split('|')
                          if h.strip() and h.strip() != current]
                self._set_tracked('|'.join(hashes))
        except Exception as e:
            self.log("cleanup_current error: %s" % str(e))

    def verify_stream(self, info_hash, file_path, file_id, timeout=12):
        url = self.get_stream_url(info_hash, file_path, file_id)
        try:
            self.log("Verify stream: bytes 0-65535...")
            res = self._session.get(
                url, stream=True, timeout=timeout,
                headers={'Range': 'bytes=0-65535'},
                auth=self._auth)
            if res.status_code in (200, 206):
                data = res.raw.read(4096)
                res.close()
                if data and len(data) > 0:
                    self.log("Stream VERIFIED: %d bytes" % len(data))
                    return True
                return False
            res.close()
            return False
        except requests.exceptions.Timeout:
            self.log("Stream verify: TIMEOUT")
            return False
        except Exception as e:
            self.log("Stream verify: %s" % str(e)[:80])
            return False

    def _try_torrent_cache(self, info_hash):
        cache_urls = [
            "https://itorrents.org/torrent/%s.torrent" % info_hash.upper(),
            "http://bt.t-ru.org/dl/%s" % info_hash.lower(),
        ]
        for url in cache_urls:
            try:
                res = self._session.get(url, timeout=4, verify=False)
                if res.status_code == 200 and len(res.content) > 200:
                    if res.content[:1] == b'd':
                        self.log("Cache HIT: %d bytes" % len(res.content))
                        return res.content
            except:
                continue
        return None

    def add_magnet(self, magnet, title="", poster="", torrent_data_b64=""):
        try:
            payload = {
                "action": "add",
                "link": magnet,
                "title": title,
                "poster": poster,
                "save_to_db": False,
            }
            if torrent_data_b64:
                payload["data"] = torrent_data_b64
            res = self._post("/torrents",
                             data=dumps(payload),
                             headers={'Content-Type': 'application/json'})
            if res.status_code == 200:
                result = _normalize_response(res.json())
                h = result.get("hash")
                self.log("add_magnet OK: %s" % h)
                return h
            else:
                self.log("add_magnet EROARE: HTTP %s" % res.status_code)
                return None
        except Exception as e:
            self.log("add_magnet EXCEPTIE: %s" % str(e))
            return None

    def add_magnet_fast(self, magnet, title="", poster=""):
        info_hash = extract_hash_from_magnet(magnet)
        # Magnetul are propriul tracker (&tr=, ex. announce cu passkey pe trackere
        # private)? Atunci SARIM cache-urile publice (itorrents.org etc.) - copia
        # de acolo are announce inlocuit/gol => TorrServer nu primeste peers (private
        # = zero DHT) => metadata nu ajunge niciodata. Trimitem magnetul direct.
        has_own_tracker = ('&tr=' in magnet) or ('?tr=' in magnet)
        if info_hash and not has_own_tracker:
            cached = self._try_torrent_cache(info_hash)
            if cached:
                b64 = base64.b64encode(cached).decode('ascii')
                result = self._upload_multipart_raw(cached, info_hash, title, poster)
                if result:
                    return result
                result = self._add_with_data_hash_only(info_hash, b64, title, poster)
                if result:
                    return result
                result = self.add_magnet(magnet, title, poster, b64)
                if result:
                    return result
        return self.add_magnet(magnet, title, poster)

    def _upload_multipart_raw(self, raw_data, name="torrent", title="", poster=""):
        try:
            if not isinstance(name, str) or '.' not in name:
                name = "%s.torrent" % name
            files = {'file': (name, raw_data, 'application/x-bittorrent')}
            form_data = {'title': title, 'poster': poster, 'save': 'false'}
            res = self._session.post(
                self._base_url + '/torrent/upload',
                files=files, data=form_data, auth=self._auth, timeout=30)
            if res.status_code == 200:
                try:
                    result = _normalize_response(res.json())
                    h = result.get('hash')
                    if h:
                        self.log("Upload OK: %s" % h)
                        return h
                except:
                    pass
            return None
        except:
            return None

    def _add_with_data_hash_only(self, info_hash, torrent_b64, title, poster):
        try:
            payload = {
                "action": "add", "link": info_hash,
                "title": title, "poster": poster,
                "data": torrent_b64, "save_to_db": False,
            }
            res = self._post("/torrents", data=dumps(payload),
                             headers={'Content-Type': 'application/json'})
            if res.status_code == 200:
                result = _normalize_response(res.json())
                return result.get("hash")
            return None
        except:
            return None

    def get_torrent_info_api(self, info_hash):
        try:
            payload = {"action": "get", "hash": info_hash}
            res = self._post("/torrents", data=dumps(payload),
                             headers={'Content-Type': 'application/json'})
            if res.status_code == 200:
                return _normalize_response(res.json())
        except:
            pass
        return None

    def get_torrent_info(self, info_hash):
        try:
            import time as _time
            now = _time.time()
            cache_key = "s_%s" % info_hash
            if cache_key in self._info_cache:
                if now - self._cache_time.get(cache_key, 0) < 0.5:
                    return self._info_cache[cache_key]
            res = self._get("/stream", params={"link": info_hash, "stat": "true"})
            if res.status_code == 200:
                data = _normalize_response(res.json())
                self._info_cache[cache_key] = data
                self._cache_time[cache_key] = now
                return data
        except:
            pass
        return None

    def get_torrent_file_info(self, link, file_index=1):
        try:
            res = self._get("/stream",
                            params={"link": link, "index": file_index, "stat": "true"})
            if res.status_code == 200:
                return _normalize_response(res.json())
        except:
            pass
        return None

    def preload_torrent(self, link, file_id=1, title=""):
        try:
            return self._get("/stream", params={
                "link": link, "index": file_id, "title": title,
                "stat": "true", "preload": "true"
            })
        except:
            return None

    def get_stream_url(self, link, path, file_id):
        return "%s/stream/%s?link=%s&index=%s&play" % (
            self._base_url, quote(path, safe='/'), link, file_id)

    def remove_torrent(self, info_hash):
        try:
            for key in list(self._info_cache.keys()):
                if info_hash in key:
                    del self._info_cache[key]
                    self._cache_time.pop(key, None)
            return self._post(
                "/torrents", data=dumps({"action": "rem", "hash": info_hash}),
                headers={'Content-Type': 'application/json'}
            ).status_code == 200
        except:
            return False

    def _post(self, url, **kwargs):
        return self._request("post", url, **kwargs)

    def _get(self, url, **kwargs):
        return self._request("get", url, **kwargs)

    def _request(self, method, url, **kwargs):
        return self._session.request(
            method, self._base_url + url, auth=self._auth, **kwargs)
