# -*- coding: utf-8 -*-
"""
Watched Status Provider abstraction layer.
Dispatching intre Trakt si MDBList in functie de setarea watched_status_provider.
"""

import os
import threading
import xbmc
import xbmcvfs

from resources.lib.config import ADDON, ADDON_PATH, MDBLIST_API_URL

def _get_provider_raw():
    try:
        idx = int(ADDON.getSetting('watched_status_provider') or '0')
    except:
        idx = 0
    return ('trakt', 'mdblist', 'simkl', 'punchplay')[idx] if idx <= 3 else 'trakt'

def clear_cache():
    """No-op pastrat pentru compatibilitate (nu mai exista cache de invalidat)."""
    pass

def _invalidate_fast_cache():
    """Invalideaza listele din fast cache (RAM) dupa o schimbare de watched status.

    Doar LISTELE: metadatele (titluri/ploturi/sezoane) nu se schimba cind marchezi
    un episod vazut, iar pastrarea lor face refresh-ul de Up Next instant in loc
    de re-constructie completa din TMDb (rotita de ~5s la revenirea din player).
    """
    try:
        from resources.lib.cache import clear_list_fast_cache
        clear_list_fast_cache()
    except:
        pass

def _on_home_widget():
    try:
        return 'tmdbmovies' not in xbmc.getInfoLabel('Container.PluginName')
    except:
        return True

def widget_refresh():
    try:
        xbmc.executebuiltin('UpdateLibrary(video,special://skin/foo)')
    except:
        pass

def refresh_ui():
    try:
        if _on_home_widget():
            widget_refresh()
        else:
            xbmc.executebuiltin('Container.Refresh')
    except:
        pass

def browse_command(url):
    try:
        if _on_home_widget():
            return 'ActivateWindow(Videos,%s,return)' % url
    except:
        pass
    return 'Container.Update(%s)' % url

_WATCHED_MARK_PROVIDERS = ('trakt', 'mdblist', 'simkl', 'punchplay')

# Culorile providerilor vin din config (sursa unica de adevar); PUNCHPLAY_COLOR
# rămâne în config pentru compatibilitate cu importurile existente.
from resources.lib.config import PROVIDER_COLORS as _CFG_PROVIDER_COLORS, PROVIDER_ICONS as _CFG_PROVIDER_ICONS, provider_title as _cfg_provider_title

_WATCHED_MARK_COLORS = {p: _CFG_PROVIDER_COLORS[p] for p in _WATCHED_MARK_PROVIDERS}

_WATCHED_MARK_LABELS = {
    'trakt': _cfg_provider_title('trakt'),
    'mdblist': _cfg_provider_title('mdblist'),
    'simkl': _cfg_provider_title('simkl'),
    'punchplay': _cfg_provider_title('punchplay'),
}

_WATCHED_MARK_TOGGLES = {
    'trakt': 'watched_mark_trakt',
    'mdblist': 'watched_mark_mdblist',
    'simkl': 'watched_mark_simkl',
    'punchplay': 'watched_mark_punchplay',
}


def _connected_mark_providers():
    connected = []
    try:
        from resources.lib import trakt_api
        if trakt_api.get_trakt_token():
            connected.append('trakt')
    except Exception:
        pass
    try:
        from resources.lib import mdblist
        if mdblist.is_authenticated():
            connected.append('mdblist')
    except Exception:
        pass
    try:
        from resources.lib import simkl
        if simkl.is_authenticated():
            connected.append('simkl')
    except Exception:
        pass
    try:
        from resources.lib import punchplay
        if punchplay.is_authenticated():
            connected.append('punchplay')
    except Exception:
        pass
    return connected


def _mark_targets():
    try:
        mode = ADDON.getSetting('watched_mark_mode') or '0'
    except Exception:
        mode = '0'
    if mode not in ('1', '2'):
        return None
    connected = _connected_mark_providers()
    if mode == '1':
        targets = list(connected)
    else:
        targets = []
        for prov in connected:
            try:
                if ADDON.getSetting(_WATCHED_MARK_TOGGLES[prov]) == 'true':
                    targets.append(prov)
            except Exception:
                pass
    prov = _get_provider_raw()
    if prov in connected and prov not in targets:
        targets.append(prov)
    return [p for p in _WATCHED_MARK_PROVIDERS if p in targets]


_PROVIDER_LABELS = {'trakt': 'Trakt', 'mdblist': 'MDBList', 'simkl': 'Simkl', 'punchplay': 'PunchPlay'}
_PROVIDER_COLORS = {'trakt': 'pink', 'mdblist': 'lightskyblue', 'simkl': 'mediumpurple', 'punchplay': 'FFFF6600'}


def _run_provider_auth(prov):
    try:
        if prov == 'trakt':
            from resources.lib.trakt_api import trakt_auth
            trakt_auth()
        elif prov == 'mdblist':
            from resources.lib.mdblist_api import mdblist_auth
            mdblist_auth()
        elif prov == 'simkl':
            from resources.lib.simkl_api import simkl_auth
            simkl_auth()
        elif prov == 'punchplay':
            from resources.lib.punchplay_api import punchplay_auth
            punchplay_auth()
        else:
            return
    except Exception:
        pass


def ensure_active_provider(notify=True, interactive=True):
    try:
        prov = _get_provider_raw()
    except Exception:
        return False
    try:
        connected = _connected_mark_providers()
    except Exception:
        return False
    if prov in connected:
        return False
    fallback = next((p for p in _WATCHED_MARK_PROVIDERS if p in connected), None)
    if interactive:
        try:
            import xbmcgui
            dead_lbl = _PROVIDER_LABELS.get(prov, prov)
            dead_clr = _PROVIDER_COLORS.get(prov, 'yellow')
            options = []
            if fallback:
                new_lbl = _PROVIDER_LABELS.get(fallback, fallback)
                new_clr = _PROVIDER_COLORS.get(fallback, 'yellow')
                options.append(f'Switch to [B][COLOR {new_clr}]{new_lbl}[/COLOR][/B]')
            options.append(f'Reconnect [B][COLOR {dead_clr}]{dead_lbl}[/COLOR][/B] (QR)')
            choice = xbmcgui.Dialog().contextmenu(options)
            if choice < 0:
                return False
            if fallback and choice == 0:
                pass
            else:
                _run_provider_auth(prov)
                try:
                    reconnected = prov in _connected_mark_providers()
                except Exception:
                    reconnected = False
                if reconnected:
                    try:
                        ADDON.setSetting('watched_status_provider', str(_WATCHED_MARK_PROVIDERS.index(prov)))
                    except Exception:
                        return False
                    try:
                        _invalidate_fast_cache()
                    except Exception:
                        pass
                    if notify:
                        try:
                            xbmcgui.Dialog().notification('[B][COLOR FFFDBD01]Watched Provider[/COLOR][/B]',
                                                          f'Reconnected [B][COLOR {dead_clr}]{dead_lbl}[/COLOR][/B]',
                                                          os.path.join(ADDON_PATH, 'icon.png'), 5000, False)
                        except Exception:
                            pass
                    return True
                if notify:
                    try:
                        xbmcgui.Dialog().notification('[B][COLOR FFFDBD01]Watched Provider[/COLOR][/B]',
                                                      f'Still disconnected [B][COLOR {dead_clr}]{dead_lbl}[/COLOR][/B]',
                                                      os.path.join(ADDON_PATH, 'icon.png'), 5000, False)
                    except Exception:
                        pass
                return False
        except Exception:
            pass
    if fallback is None:
        fallback = 'trakt'
    try:
        ADDON.setSetting('watched_status_provider', str(_WATCHED_MARK_PROVIDERS.index(fallback)))
    except Exception:
        return False
    try:
        _invalidate_fast_cache()
    except Exception:
        pass
    if notify:
        try:
            import xbmcgui
            dead_lbl = _PROVIDER_LABELS.get(prov, prov)
            dead_clr = _PROVIDER_COLORS.get(prov, 'yellow')
            new_lbl = _PROVIDER_LABELS.get(fallback, fallback)
            new_clr = _PROVIDER_COLORS.get(fallback, 'yellow')
            if fallback in connected:
                msg = f'[B][COLOR {dead_clr}]{dead_lbl}[/COLOR][/B] disconnected, switched to [B][COLOR {new_clr}]{new_lbl}[/COLOR][/B]'
            else:
                msg = f'[B][COLOR {dead_clr}]{dead_lbl}[/COLOR][/B] disconnected, no provider connected'
            xbmcgui.Dialog().notification('[B][COLOR FFFDBD01]Watched Provider[/COLOR][/B]', msg, os.path.join(ADDON_PATH, 'icon.png'), 5000, False)
        except Exception:
            pass
    return True


def _split_colored(word, provs):
    n = len(provs)
    base, extra = divmod(len(word), n)
    out = ''
    pos = 0
    for i, p in enumerate(provs):
        ln = base + (1 if i < extra else 0)
        out += '[COLOR %s]%s[/COLOR]' % (_WATCHED_MARK_COLORS[p], word[pos:pos + ln])
        pos += ln
    return out


def mark_menu_label(is_watched):
    targets = _mark_targets()
    if targets is None:
        return None
    ordered = [p for p in _WATCHED_MARK_PROVIDERS if p in targets]
    if not ordered:
        return None
    if is_watched:
        return '[B][COLOR FFE41B17]Mark [/COLOR]%s[/B]' % _split_colored('Unwatched', ordered)
    return '[B][COLOR FF6AFB92]Mark [/COLOR]%s[/B]' % _split_colored('Watched', ordered)


def _fanout_mark(watched, tmdb_id, content_type, season, episode, providers, notify, sync_provider, do_refresh):
    targets = [p for p in _WATCHED_MARK_PROVIDERS if p in (providers or [])]
    if not targets:
        return []
    done = []
    lock = threading.Lock()

    def _one(prov):
        try:
            if watched:
                if prov == 'trakt':
                    from resources.lib.trakt_sync import mark_as_watched_internal
                    mark_as_watched_internal(tmdb_id, content_type, season, episode, notify=False, sync_trakt=sync_provider, refresh_ui=False)
                elif prov == 'mdblist':
                    from resources.lib.mdblist_sync import mark_as_watched_internal
                    mark_as_watched_internal(tmdb_id, content_type, season, episode, notify=False, sync_mdblist=sync_provider, refresh_ui=False)
                elif prov == 'simkl':
                    from resources.lib.simkl_sync import mark_as_watched_internal
                    mark_as_watched_internal(tmdb_id, content_type, season, episode, notify=False, sync_simkl=sync_provider, refresh_ui=False)
                else:
                    from resources.lib.punchplay_sync import mark_as_watched_internal
                    mark_as_watched_internal(tmdb_id, content_type, season, episode, notify=False, sync_punchplay=sync_provider, refresh_ui=False)
            else:
                if prov == 'trakt':
                    from resources.lib.trakt_sync import mark_as_unwatched_internal
                    mark_as_unwatched_internal(tmdb_id, content_type, season, episode, notify=False, sync_trakt=sync_provider, refresh_ui=False)
                elif prov == 'mdblist':
                    from resources.lib.mdblist_sync import mark_as_unwatched_internal
                    mark_as_unwatched_internal(tmdb_id, content_type, season, episode, notify=False, sync_mdblist=sync_provider, refresh_ui=False)
                elif prov == 'simkl':
                    from resources.lib.simkl_sync import mark_as_unwatched_internal
                    mark_as_unwatched_internal(tmdb_id, content_type, season, episode, notify=False, sync_simkl=sync_provider, refresh_ui=False)
                else:
                    from resources.lib.punchplay_sync import mark_as_unwatched_internal
                    mark_as_unwatched_internal(tmdb_id, content_type, season, episode, notify=False, sync_punchplay=sync_provider, refresh_ui=False)
            with lock:
                done.append(prov)
        except Exception:
            pass

    workers = [threading.Thread(target=_one, args=(p,), daemon=True) for p in targets]
    for t in workers:
        t.start()
    for t in workers:
        t.join(30)
    _refresh_tmdb_up_next(tmdb_id)
    _verify_tmdb_upnext_heal(tmdb_id)
    _invalidate_fast_cache()
    ordered_done = [p for p in _WATCHED_MARK_PROVIDERS if p in done]
    if notify:
        import xbmcgui
        _icon = os.path.join(ADDON_PATH, 'icon.png')
        if ordered_done:
            _names = ' + '.join(_WATCHED_MARK_LABELS[p] for p in ordered_done)
            if watched:
                _lbl = '[B]Mark %s[/B]' % _split_colored('Watched', ordered_done)
            else:
                _lbl = '[B]Mark %s[/B]' % _split_colored('Unwatched', ordered_done)
            xbmcgui.Dialog().notification('[B][COLOR yellow]All Providers[/COLOR][/B]', '%s on %s' % (_lbl, _names), _icon, 5000, False)
        else:
            xbmcgui.Dialog().notification('[B][COLOR yellow]All Providers[/COLOR][/B]', 'No provider updated', _icon, 5000, False)
    if do_refresh:
        refresh_ui()
    return ordered_done


def mark_watched_on_providers(tmdb_id, content_type, season=None, episode=None, providers=None, notify=True, sync_provider=True, do_refresh=True):
    return _fanout_mark(True, tmdb_id, content_type, season, episode, providers, notify, sync_provider, do_refresh)


def mark_unwatched_on_providers(tmdb_id, content_type, season=None, episode=None, providers=None, notify=True, sync_provider=True, do_refresh=True):
    return _fanout_mark(False, tmdb_id, content_type, season, episode, providers, notify, sync_provider, do_refresh)

def get_provider():
    return _get_provider_raw()

def is_trakt():
    return _get_provider_raw() == 'trakt'

def is_mdblist():
    return _get_provider_raw() == 'mdblist'

def is_simkl():
    return _get_provider_raw() == 'simkl'

def is_punchplay():
    return _get_provider_raw() == 'punchplay'

def get_label():
    return ('Trakt', 'MDBList', 'Simkl', 'PunchPlay')[('trakt', 'mdblist', 'simkl', 'punchplay').index(_get_provider_raw())]

def get_color():
    return _CFG_PROVIDER_COLORS.get(_get_provider_raw(), 'white')

def get_icon():
    return _CFG_PROVIDER_ICONS.get(_get_provider_raw()) or os.path.join(ADDON_PATH, 'resources', 'media', 'tmdb.png')

def get_status_setting():
    return {'trakt': 'trakt_status', 'mdblist': 'mdblist_status', 'simkl': 'simkl_status', 'punchplay': 'punchplay_status'}[_get_provider_raw()]

def get_access_token_setting():
    return {'trakt': 'trakt_access_token', 'mdblist': 'mdblist_access_token', 'simkl': 'simkl_access_token', 'punchplay': 'punchplay_access_token'}[_get_provider_raw()]

def get_refresh_token_setting():
    return {'trakt': 'trakt_refresh_token', 'mdblist': 'mdblist_refresh_token', 'simkl': 'simkl_access_token', 'punchplay': 'punchplay_refresh_token'}[_get_provider_raw()]

def get_source_module():
    prov = _get_provider_raw()
    if prov == 'punchplay':
        return __import__('resources.lib.punchplay_sync', fromlist=['punchplay_sync'])
    if prov == 'simkl':
        return __import__('resources.lib.simkl_sync', fromlist=['simkl_sync'])
    if prov == 'mdblist':
        return __import__('resources.lib.mdblist_sync', fromlist=['mdblist_sync'])
    return __import__('resources.lib.trakt_sync', fromlist=['trakt_sync'])

def dispatch_mark_watched(tmdb_id, content_type, season=None, episode=None, notify=True, sync_provider=True, do_refresh=True, async_tmdb=False, skip_library_hack=False):
    targets = _mark_targets()
    prov = _get_provider_raw()
    if targets is None or targets == [prov]:
        if prov == 'trakt':
            from resources.lib.trakt_sync import mark_as_watched_internal
            mark_as_watched_internal(tmdb_id, content_type, season, episode, notify=notify, sync_trakt=sync_provider, refresh_ui=do_refresh, skip_library_hack=skip_library_hack)
        elif prov == 'mdblist':
            from resources.lib.mdblist_sync import mark_as_watched_internal
            mark_as_watched_internal(tmdb_id, content_type, season, episode, notify=notify, sync_mdblist=sync_provider, refresh_ui=do_refresh)
        elif prov == 'simkl':
            from resources.lib.simkl_sync import mark_as_watched_internal
            mark_as_watched_internal(tmdb_id, content_type, season, episode, notify=notify, sync_simkl=sync_provider, refresh_ui=do_refresh)
        else:
            from resources.lib.punchplay_sync import mark_as_watched_internal
            mark_as_watched_internal(tmdb_id, content_type, season, episode, notify=notify, sync_punchplay=sync_provider, refresh_ui=do_refresh)
        _refresh_tmdb_up_next(tmdb_id)
        _verify_tmdb_upnext_heal(tmdb_id)
        # Randul TMDB Up Next (sursa listei "TMDb UP Next") trebuie rescris INTOTDEAUNA
        # in acest flux, nu async: async lasa lista TMDB cu episodul vechi daca UI-ul
        # s-a randat inaintea thread-ului (fara refresh ulterior).
        _upnext_ui_sync(preserve_binge=(not do_refresh))
        _invalidate_fast_cache()
        if do_refresh: refresh_ui()
        return
    if not targets:
        return
    mark_watched_on_providers(tmdb_id, content_type, season, episode, providers=targets, notify=notify, sync_provider=sync_provider, do_refresh=do_refresh)

def dispatch_mark_unwatched(tmdb_id, content_type, season=None, episode=None, sync_provider=True, do_refresh=True):
    targets = _mark_targets()
    prov = _get_provider_raw()
    if targets is None or targets == [prov]:
        if prov == 'trakt':
            from resources.lib.trakt_sync import mark_as_unwatched_internal
            mark_as_unwatched_internal(tmdb_id, content_type, season, episode, sync_trakt=sync_provider, refresh_ui=do_refresh)
        elif prov == 'mdblist':
            from resources.lib.mdblist_sync import mark_as_unwatched_internal
            mark_as_unwatched_internal(tmdb_id, content_type, season, episode, sync_mdblist=sync_provider, refresh_ui=do_refresh)
        elif prov == 'simkl':
            from resources.lib.simkl_sync import mark_as_unwatched_internal
            mark_as_unwatched_internal(tmdb_id, content_type, season, episode, sync_simkl=sync_provider, refresh_ui=do_refresh)
        else:
            from resources.lib.punchplay_sync import mark_as_unwatched_internal
            mark_as_unwatched_internal(tmdb_id, content_type, season, episode, sync_punchplay=sync_provider, refresh_ui=do_refresh)
        _refresh_tmdb_up_next(tmdb_id)
        _verify_tmdb_upnext_heal(tmdb_id)
        _upnext_ui_sync(preserve_binge=True)
        _invalidate_fast_cache()
        if do_refresh: refresh_ui()
        return
    if not targets:
        return
    mark_unwatched_on_providers(tmdb_id, content_type, season, episode, providers=targets, notify=True, sync_provider=sync_provider, do_refresh=do_refresh)

def dispatch_scrobble(action, tmdb_id, content_type, season, episode, progress, duration_seconds=0, position_seconds=0, watched=None, watched_threshold=None):
    prov = _get_provider_raw()
    if prov == 'trakt':
        from resources.lib.trakt_api import send_trakt_scrobble
        send_trakt_scrobble(action, tmdb_id, content_type, season, episode, progress)
    elif prov == 'mdblist':
        from resources.lib.mdblist_api import MDBListAPI
        api = MDBListAPI()
        if action == 'stop' and (progress or 0) <= 0:
            api.scrobble_clear(content_type, tmdb_id, season, episode, silent_404=True)
        elif action == 'start' or action == 'scrobble':
            api.scrobble_start(content_type, tmdb_id, progress, season, episode)
        elif action == 'pause':
            api.scrobble_pause(content_type, tmdb_id, progress, season, episode)
        elif action == 'stop':
            api.scrobble_stop(content_type, tmdb_id, progress, season, episode)
            _invalidate_fast_cache()
    elif prov == 'simkl':
        from resources.lib.simkl_api import SIMKLAPI
        api = SIMKLAPI()
        if action == 'start' or action == 'scrobble':
            api.scrobble_start(content_type, tmdb_id, progress, season, episode)
        elif action == 'pause':
            api.scrobble_pause(content_type, tmdb_id, progress, season, episode)
        elif action == 'stop':
            api.scrobble_stop(content_type, tmdb_id, progress, season, episode)
            _invalidate_fast_cache()
    else:
        from resources.lib.punchplay_api import PunchplayAPI, _pp_enqueue
        api = PunchplayAPI()
        if not api.is_authenticated():
            return
        _key = (str(tmdb_id), season, episode)
        if action == 'start':
            _pp_enqueue('start', lambda: api.scrobble_start(content_type, tmdb_id, progress, season, episode))
        elif action == 'scrobble':
            _pp_enqueue('progress', lambda: api.scrobble_progress(content_type, tmdb_id, progress, season, episode, duration_seconds=duration_seconds, position_seconds=position_seconds), coalesce_key=_key)
        elif action == 'pause':
            _pp_enqueue('pause', lambda: api.scrobble_pause(content_type, tmdb_id, progress, season, episode, duration_seconds=duration_seconds, position_seconds=position_seconds))
        elif action == 'resume':
            _pp_enqueue('resume', lambda: api.scrobble_resume(content_type, tmdb_id, progress, season, episode, duration_seconds=duration_seconds, position_seconds=position_seconds))
        elif action == 'stop':
            _pp_enqueue('stop', lambda: api.scrobble_stop(content_type, tmdb_id, progress, season, episode, duration_seconds=duration_seconds, position_seconds=position_seconds, watched=watched, watched_threshold=watched_threshold))
            _invalidate_fast_cache()

def _kodi_delete_resume_bookmark(tmdb_id, content_type, season=None, episode=None):
    try:
        content_type = 'tv' if content_type in ('tv', 'episode') else 'movie'
        import glob
        import sqlite3
        db_dir = xbmcvfs.translatePath('special://userdata/Database/')
        dbs = glob.glob(os.path.join(db_dir, 'MyVideos*.db'))
        if not dbs:
            return
        db_path = max(dbs, key=os.path.getmtime)
        conn = sqlite3.connect(db_path, timeout=2)
        cur = conn.cursor()
        params = ['%mode=sources%', '%%tmdb_id=%s%%' % tmdb_id, '%%type=%s%%' % content_type]
        query = ("DELETE FROM bookmark WHERE type=1 AND idFile IN (SELECT idFile FROM files "
                 "WHERE strFilename LIKE ? AND strFilename LIKE ? AND strFilename LIKE ?")
        if content_type == 'tv' and season is not None and episode is not None:
            params += ['%%season=%s%%' % season, '%%episode=%s%%' % episode]
            query += " AND strFilename LIKE ? AND strFilename LIKE ?"
        query += ")"
        cur.execute(query, params)
        conn.commit()
        xbmc.log(f"[TMDb Movies] [RESUME] Bookmark Kodi sters: {cur.rowcount} rand(uri)", xbmc.LOGINFO)
        conn.close()
    except Exception as e:
        xbmc.log(f"[TMDb Movies] [RESUME] Bookmark Kodi stergere error: {e}", xbmc.LOGERROR)

def dispatch_remove_progress(tmdb_id, content_type='movie', season=None, episode=None):
    """Elimina resume-ul (toate serverele autorizate + tabela locala) si refresheaza."""
    # 1. Server MDBList (daca e autorizat) - 404 = sesiune inexistenta, nu e eroare
    try:
        from resources.lib.mdblist_api import MDBListAPI
        _api = MDBListAPI()
        if _api.is_authenticated():
            _api.scrobble_clear(content_type, tmdb_id, season, episode, silent_404=True)
    except Exception:
        pass
    # 1b. Server Simkl (daca e autorizat)
    try:
        from resources.lib.simkl_api import SIMKLAPI
        _api = SIMKLAPI()
        if _api.is_authenticated():
            _api.playback_remove(content_type, tmdb_id, season, episode)
    except Exception:
        pass
    # 1c. Server PunchPlay (daca e autorizat)
    try:
        from resources.lib.punchplay_api import PunchplayAPI
        _api = PunchplayAPI()
        if _api.is_authenticated():
            _api.playback_remove(content_type, tmdb_id, season, episode)
    except Exception:
        pass
    # 2. Server Trakt + stergere locala + clear fast cache + Container.Refresh
    from resources.lib.trakt_api import remove_from_progress
    remove_from_progress(tmdb_id, content_type, season, episode)
    # 3. Bookmark Kodi (dialogul nativ de resume nu mai trebuie sa apara la click)
    _kodi_delete_resume_bookmark(tmdb_id, content_type, season, episode)
    # 4. Refresh widget-uri de pe Home (UpdateLibrary) — Container.Refresh din
    #    remove_from_progress doar reimprospateaza containerul activ, nu widget-urile.
    _invalidate_fast_cache()
    refresh_ui()

def get_watched_counts_map(tmdb_ids):
    """Count-uri pe mai multe seriale, dintr-o singura conexiune (per provider activ).

    None = providerul nu are varianta bulk / citirea a esuat -> apelantul foloseste
    numararea per serial (comportamentul de dinainte).
    """
    try:
        prov = _get_provider_raw()
        if prov == 'punchplay':
            from resources.lib.punchplay_sync import get_watched_counts_map as _m
        elif prov == 'mdblist':
            from resources.lib.mdblist_sync import get_watched_counts_map as _m
        elif prov == 'simkl':
            from resources.lib.simkl_sync import get_watched_counts_map as _m
        else:
            return None
        return _m(tmdb_ids)
    except:
        return None


def is_movie_watched(tmdb_id):
    return get_source_module().is_movie_watched(tmdb_id)

def is_episode_watched(tmdb_id, season, episode):
    return get_source_module().is_episode_watched(tmdb_id, season, episode)

def get_episode_watched_count(tmdb_id):
    """Numar de episoade vizionate pentru un serial (provider-aware, int)."""
    prov = _get_provider_raw()
    if prov == 'trakt':
        from resources.lib.trakt_sync import get_episode_watched_count as _chk
        return _chk(tmdb_id)
    elif prov == 'mdblist':
        from resources.lib.mdblist_sync import get_watched_episodes_count as _chk
        return _chk(tmdb_id)
    elif prov == 'simkl':
        from resources.lib.simkl_sync import get_watched_episodes_count as _chk
        return _chk(tmdb_id)
    else:
        from resources.lib.punchplay_sync import get_watched_episodes_count as _chk
        return _chk(tmdb_id)

def get_watched_episodes_set(tmdb_id):
    prov = _get_provider_raw()
    tbl = {'trakt': 'trakt_watched_episodes', 'mdblist': 'mdblist_watched_episodes', 'simkl': 'simkl_watched_episodes', 'punchplay': 'punchplay_watched_episodes'}[prov]
    res = {'set': set(), 'last': None, 'last_at': ''}
    try:
        mod = get_source_module()
        conn = mod.get_connection()
        cur = conn.cursor()
        cur.execute(f"SELECT season, episode, last_watched_at FROM {tbl} WHERE tmdb_id=?", (str(tmdb_id),))
        rows = cur.fetchall()
        conn.close()
        max_at = None
        for r in rows:
            s, e, at = r[0], r[1], r[2]
            if not s or not e:
                continue
            res['set'].add((int(s), int(e)))
            if at:
                if max_at is None or at > max_at[1]:
                    max_at = ((int(s), int(e)), at)
        if max_at:
            res['last'] = max_at[0]
            res['last_at'] = max_at[1]
    except Exception:
        pass
    return res

def get_watched_episodes_set_batch(tmdb_ids):
    prov = _get_provider_raw()
    tbl = {'trakt': 'trakt_watched_episodes', 'mdblist': 'mdblist_watched_episodes', 'simkl': 'simkl_watched_episodes', 'punchplay': 'punchplay_watched_episodes'}[prov]
    result = {}
    ids = [str(x) for x in (tmdb_ids or []) if x]
    if not ids:
        return result
    for tid in ids:
        result[tid] = {'set': set(), 'last': None, 'last_at': ''}
    try:
        mod = get_source_module()
        conn = mod.get_connection()
        cur = conn.cursor()
        chunk_size = 400
        for i in range(0, len(ids), chunk_size):
            chunk = ids[i:i + chunk_size]
            placeholders = ','.join(['?'] * len(chunk))
            cur.execute(f"SELECT tmdb_id, season, episode, last_watched_at FROM {tbl} WHERE tmdb_id IN ({placeholders})", chunk)
            for row in cur.fetchall():
                tid, s, e, at = str(row[0]), row[1], row[2], row[3]
                if tid not in result:
                    continue
                if not s or not e:
                    continue
                result[tid]['set'].add((int(s), int(e)))
                if at:
                    cur_last = result[tid]['last_at']
                    if not cur_last or at > cur_last:
                        result[tid]['last'] = (int(s), int(e))
                        result[tid]['last_at'] = at
        conn.close()
    except Exception:
        pass
    return result

def _refresh_tmdb_up_next(tmdb_id):
    """Recalculeaza randul TMDB Up Next dupa mark watched/unwatched (daca TMDb e conectat)."""
    try:
        from resources.lib.config import TMDB_V4_TOKEN_FILE
        if os.path.exists(TMDB_V4_TOKEN_FILE):
            from resources.lib.trakt_sync import refresh_next_episode_tmdb
            refresh_next_episode_tmdb(tmdb_id)
    except Exception:
        pass


def _verify_tmdb_upnext_heal(tmdb_id):
    """Verifica ca rindul TMDB Up Next pentru tmdb_id corespunde deja vizionate
    locale ale providerului activ; daca nu (ex: rescrierea a esuat tranzitoriu in
    urma cu 0.2-3s), re-run refresh_next_episode_tmdb. Rulata sincron, cu 3
    re-verificari la 500ms — rindul TMDb provine dintr-un SQLite separat.
    """
    try:
        from resources.lib.config import TMDB_V4_TOKEN_FILE
        if not os.path.exists(TMDB_V4_TOKEN_FILE):
            return
        import time as _t
        for _i in range(3):
            _t.sleep(0.5)
            try:
                from resources.lib import trakt_sync as _ts
                pconn = _ts.get_connection()
                pcur = pconn.cursor()
                pcur.execute("SELECT season, episode FROM tmdb_next_episodes WHERE tmdb_id=?", (str(tmdb_id),))
                row = pcur.fetchone()
                pconn.close()
            except Exception:
                return
            if row is None or row[0] is None or row[1] is None:
                return
            try:
                pseason, pep = int(row[0]), int(row[1])
            except Exception:
                return
            # Referinta = rindul providerului activ (aceeasi sursa ca listele
            # Up Next dinamice). Daca exista si difera de rindul TMDB, oferim
            # prilejul de heal (TMDB scris de alt thread poate ramine in urma).
            ref = None
            try:
                mod = get_source_module()
                prov = _get_provider_raw()
                p_tbl = {'trakt': 'trakt_next_episodes', 'mdblist': 'mdblist_next_episodes',
                         'simkl': 'simkl_next_episodes', 'punchplay': 'punchplay_next_episodes'}[prov]
                mconn = mod.get_connection()
                mcur = mconn.cursor()
                mcur.execute("SELECT season, episode FROM %s WHERE tmdb_id=?" % p_tbl, (str(tmdb_id),))
                mrow = mcur.fetchone()
                mconn.close()
                if mrow and mrow[0] is not None and mrow[1] is not None:
                    ref = (int(mrow[0]), int(mrow[1]))
            except Exception:
                ref = None
            w = get_watched_episodes_set(tmdb_id)
            wset = w.get('set') or set()
            tmdb_pair = (pseason, pep)
            tmdb_is_ok = tmdb_pair not in wset
            ref_is_ok = (ref is None) or (ref not in wset)
            same = (ref is None) or (ref == tmdb_pair)
            if tmdb_is_ok and ref_is_ok and same:
                return  # totul consistent
            # Rindul TMDB e in urma (expus un episod vazut sau diferit de provider).
            try:
                from resources.lib.trakt_sync import refresh_next_episode_tmdb
                refresh_next_episode_tmdb(tmdb_id)
            except Exception:
                pass
            return
    except Exception:
        pass


def _upnext_ui_sync(preserve_binge=True):
    """Dupa rescrierea randurilor Up Next (provider + TMDB): invalideaza listele din
    fast cache si da Container.Refresh, ca AMBELE liste Up Next (colorata dinamica
    si TMDB) sa arate noul episod la urmatoarea randare.

    preserve_binge=True pastreaza comportamentul din player: nu suprascriem un
    dialog binge/autoplay deschis si nu dam refresh daca listele s-au reimprospatat
    chiar acum (evitam randarile in paralel care lasau pagina goala).
    """
    import time as _time
    try:
        from resources.lib.cache import clear_list_fast_cache
        clear_list_fast_cache()
    except Exception:
        pass
    try:
        import xbmcgui
        try:
            _binge_since = float(xbmcgui.Window(10000).getProperty('tmdbmovies.binge_open') or 0)
        except Exception:
            _binge_since = 0.0
        if preserve_binge and _binge_since > 0 and (_time.time() - _binge_since) < 120:
            return
        try:
            _last = float(xbmcgui.Window(10000).getProperty('tmdbmovies.last_upnext_refresh') or 0)
        except Exception:
            _last = 0.0
        if _time.time() - _last < 1.5:
            return
        refresh_ui()
        xbmcgui.Window(10000).setProperty('tmdbmovies.last_upnext_refresh', str(_time.time()))
    except Exception:
        pass

def get_season_watched_count(tmdb_id, season):
    """Numar de episoade vizionate dintr-un sezon (provider-aware, int)."""
    prov = _get_provider_raw()
    if prov == 'trakt':
        from resources.lib.trakt_sync import get_episode_watched_count as _chk
        return _chk(tmdb_id, season)
    elif prov == 'mdblist':
        from resources.lib.mdblist_sync import get_watched_season_episodes_count as _chk
        return _chk(tmdb_id, season)
    elif prov == 'simkl':
        from resources.lib.simkl_sync import get_watched_season_episodes_count as _chk
        return _chk(tmdb_id, season)
    else:
        from resources.lib.punchplay_sync import get_watched_season_episodes_count as _chk
        return _chk(tmdb_id, season)

def sync_full_library(silent=False, force=False):
    if not silent:
        try:
            ensure_active_provider()
        except:
            pass
    prov = _get_provider_raw()
    from resources.lib.trakt_sync import sync_full_library as _trakt_sync
    from resources.lib.mdblist_sync import sync_full_library as _mdblist_sync
    from resources.lib.simkl_sync import sync_full_library as _simkl_sync
    from resources.lib.punchplay_sync import sync_full_library as _punchplay_sync

    order = [prov] + [p for p in ('trakt', 'mdblist', 'simkl', 'punchplay') if p != prov]
    for p in order:
        try:
            if p == 'trakt':
                _trakt_sync(silent=silent, force=force)
            elif p == 'mdblist':
                _mdblist_sync(silent=silent, force=force)
            elif p == 'simkl':
                _simkl_sync(silent=silent, force=force)
            else:
                _punchplay_sync(silent=silent, force=force)
        except Exception as e:
            xbmc.log(f'[{p.upper()} SYNC] secondary sync error: {e}', xbmc.LOGERROR)

def get_watched_counts(tmdb_id, content_type, season=None):
    """Provider-aware watched count: {watched: int, total: int}"""
    if content_type == 'movie':
        return 1 if is_movie_watched(tmdb_id) else 0
    prov = _get_provider_raw()
    if prov == 'trakt':
        from resources.lib import trakt_api
        if content_type == 'season' and season is not None:
            return trakt_api.get_watched_counts(tmdb_id, 'season', season)
        else:
            return trakt_api.get_watched_counts(tmdb_id, 'tv')
    elif prov == 'mdblist':
        from resources.lib.mdblist_sync import get_watched_episodes_count, get_watched_season_episodes_count
        if content_type == 'season' and season is not None:
            return get_watched_season_episodes_count(tmdb_id, season)
        else:
            return get_watched_episodes_count(tmdb_id)
    elif prov == 'simkl':
        from resources.lib.simkl_sync import get_watched_episodes_count, get_watched_season_episodes_count
        if content_type == 'season' and season is not None:
            return get_watched_season_episodes_count(tmdb_id, season)
        else:
            return get_watched_episodes_count(tmdb_id)
    else:
        from resources.lib.punchplay_sync import get_watched_episodes_count, get_watched_season_episodes_count
        if content_type == 'season' and season is not None:
            return get_watched_season_episodes_count(tmdb_id, season)
        else:
            return get_watched_episodes_count(tmdb_id)
