import xbmcaddon

FILE = 'colors.json'
COLORS = ['white', 'dodgerblue','yellow', 'red', 'green']

class Colors:
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.setting = self.addon.getSetting
        self.file = FILE
        self.colors = COLORS
        self.color1 = self.get_color('color1')
        self.color2 = self.get_color('color2')
        self.color3 = self.get_color('color3')
        self.color4 = self.get_color('color4')
    
    def get_color(self, color: str) -> str:
        color_index = int(self.setting(color))
        return COLORS[color_index]
    
    def color_text1(self, string: str) -> str:
        if '[B]' in string or '[/B]' in string:
            return f'{string}'
        else:
            return f'[B]{string}[/B]'
    
    def color_text2(self, string: str) -> str:
        if '[B]' in string or '[/B]' in string:
            return f'{string}'
        else:
            return f'{string}[/B]'

    def color_text3(self, string: str) -> str:
        if '[B]' in string or '[/B]' in string:
            return f'{string}'
        else:
            return f'[B]{string}[/B]'

    def color_text4(self, string: str) -> str:
        if '[B]' in string or '[/B]' in string:
            return f'{string}'
        else:
            return f'[B]{string}[/B]'
        
colors = Colors()
