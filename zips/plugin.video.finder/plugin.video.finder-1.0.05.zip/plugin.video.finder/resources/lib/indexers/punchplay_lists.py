# -*- coding: utf-8 -*-
import sys
from modules import settings
from modules import kodi_utils
from apis.punchplay_api import punchplay_get_lists, punchplay_list_items

def get_my_lists(params):
    handle=int(sys.argv[1]); rows=[]
    for item in punchplay_get_lists():
        if item.get('isWatchlist'): continue
        lid=item.get('id')
        if not lid: continue
        name=item.get('name') or 'PunchPlay List'
        url=kodi_utils.build_url({'mode':'punchplay.list.open_list','list_id':lid,'list_name':name})
        li=kodi_utils.make_listitem(); li.setLabel(name); icon=kodi_utils.get_icon('punchplay'); li.setArt({'icon':icon,'poster':icon,'thumb':icon,'fanart':kodi_utils.get_addon_fanart()})
        rows.append((url,li,True))
    kodi_utils.add_items(handle,rows); kodi_utils.set_content(handle,''); kodi_utils.set_category(handle,'PunchPlay My Lists'); kodi_utils.end_directory(handle)

def open_list(params):
    handle=int(sys.argv[1]); lid=params.get('list_id'); name=params.get('list_name','PunchPlay List')
    kodi_utils.add_dir(handle,{'mode':'build_movie_list','action':'punchplay_user_list','list_id':lid,'category_name':name+' - Movies'},'Movies','punchplay')
    kodi_utils.add_dir(handle,{'mode':'build_tvshow_list','action':'punchplay_user_list','list_id':lid,'category_name':name+' - TV Shows'},'TV Shows','punchplay')
    kodi_utils.set_content(handle,''); kodi_utils.set_category(handle,name); kodi_utils.end_directory(handle)
