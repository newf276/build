# -*- coding: utf-8 -*-
import json
from urllib.parse import quote_plus, unquote

from caches.main_cache import main_cache
from caches.settings_cache import get_setting
from indexers.easynews import search_easynews_image
from indexers.people import person_search
from modules.kodi_utils import build_url, close_all_dialog, execute_builtin, current_skin, external, get_infolabel, get_window_id, kodi_dialog, kodi_refresh, notification, select_dialog

# from modules.kodi_utils import logger


def _sync_integrated_skin_history(search_name):
	"""Update Finder Skin's five visible Recent Searches at submit time.

	The skin previously shifted SearchHistory.* from SearchResults window onload.
	That coupled visible history to provider/window lifecycle, so an aborted or
	zero-result refresh could leave Recent Searches stale.  Keep this separate
	from Finder's normal cached histories and only mirror into the skin when the
	integrated Search Results window is being used.
	"""
	try:
		if current_skin() != "skin.finder" or get_setting("interface_mode", "standalone") != "integrated":
			return
		current = [get_infolabel("Skin.String(SearchHistory.%d)" % i) for i in range(1, 6)]
		if current and current[0] == search_name:
			execute_builtin("Skin.SetString(SearchHistoryCount,1)")
			return
		# De-duplicate the submitted term while preserving newest-first order.
		history = [item for item in current if item and item != search_name]
		history.insert(0, search_name)
		history = history[:5]
		for index in range(1, 6):
			value = history[index - 1] if index <= len(history) else ""
			execute_builtin("Skin.SetString(SearchHistory.%d,%s)" % (index, value))
		execute_builtin("Skin.SetString(SearchHistoryCount,1)")
	except Exception:
		# Search must never fail merely because the optional skin history mirror did.
		return


def get_key_id(params):
	close_all_dialog()
	params_key_id = params.get("key_id", None)
	key_id = params_key_id or kodi_dialog().input("")
	if not key_id:
		return
	key_id = unquote(key_id)
	media_type = params.get("media_type", "")
	search_type = params.get("search_type", "media_title")
	string = None
	if search_type == "media_title":
		if media_type == "movie":
			url_params, string = {"mode": "build_movie_list", "action": "tmdb_movies_search"}, "movie_queries"
		elif media_type == "tv_show":
			url_params, string = {"mode": "build_tvshow_list", "action": "tmdb_tv_search", "is_anime_list": "false"}, "tvshow_queries"
		elif media_type == "anime":
			url_params, string = {"mode": "build_tvshow_list", "action": "tmdb_tv_search", "is_anime_list": "true"}, "anime_queries"
		else:
			url_params, string = {"mode": "build_tvshow_list", "action": "tmdb_tv_search"}, "tvshow_anime_queries"  # media_type=tvshow_anime
	elif search_type == "people":
		string = "people_queries"
	elif search_type == "tmdb_keyword":
		url_params, string = {"mode": "navigator.keyword_results", "media_type": media_type}, "keyword_tmdb_%s_queries" % media_type
	elif search_type == "easynews_video":
		url_params, string = {"mode": "easynews.search_easynews"}, "easynews_video_queries"
	elif search_type == "easynews_image":
		url_params, string = {"mode": "easynews.search_easynews_image"}, "easynews_image_queries"
	elif search_type == "trakt_lists":
		url_params, string = {"mode": "trakt.list.search_trakt_lists"}, "trakt_list_queries"
	if string:
		add_to_search(key_id, string)
	if search_type == "people":
		return person_search(key_id)
	if search_type == "easynews_image":
		return search_easynews_image(key_id)
	url_params.update({"query": key_id, "key_id": key_id, "name": "Search Results for %s" % key_id})
	if search_type == "media_title":
		_sync_integrated_skin_history(key_id)
		execute_builtin("Skin.SetString(SearchInput,%s)" % key_id)
		execute_builtin("Skin.SetString(SearchInputEncoded,%s)" % quote_plus(key_id))
		execute_builtin("Skin.SetString(SearchInputTraktEncoded,%s)" % quote_plus(key_id))
		# Window 1121 may already be active when starting a new search.
		# ActivateWindow alone does not rebuild its directory providers in that case.
		execute_builtin("ActivateWindow(1121,return)", True)
		return execute_builtin("Container.Refresh")
	return execute_builtin(("ActivateWindow(Videos,%s,return)" if external() else "Container.Update(%s)") % build_url(url_params))


def add_to_search(search_name, search_list):
	try:
		result = []
		cache = main_cache.get(search_list)
		if cache:
			result = cache
		if search_name in result:
			result.remove(search_name)
		result.insert(0, search_name)
		result = result[:50]
		main_cache.set(search_list, result, expiration=8760)
	except:
		return


def remove_from_search(params):
	try:
		result = main_cache.get(params["setting_id"])
		result.remove(params.get("key_id"))
		main_cache.set(params["setting_id"], result, expiration=8760)
		notification("Success", 2500)
		kodi_refresh()
	except:
		return


def clear_search():
	clear_history_list = [
		("Clear Movie Search History", "movie_queries"),
		("Clear TV Show Search History", "tvshow_queries"),
		("Clear Anime Search History", "anime_queries"),
		("Clear TV Show & Anime Search History", "tvshow_anime_queries"),
		("Clear People Search History", "people_queries"),
		("Clear Keywords Movie Search History", "keyword_tmdb_movie_queries"),
		("Clear Keywords TV Show Search History", "keyword_tmdb_tvshow_queries"),
		("Clear Easynews Video Search History", "easynews_video_queries"),
		("Clear Easynews Image Search History", "easynews_image_queries"),
		("Clear Trakt List Search History", "trakt_list_queries"),
	]
	try:
		list_items = [{"line1": item[0]} for item in clear_history_list]
		kwargs = {"items": json.dumps(list_items), "narrow_window": "true"}
		setting_id = select_dialog([item[1] for item in clear_history_list], **kwargs)
		if setting_id == None:
			return
		clear_all(setting_id)
	except:
		return


def clear_all(setting_id, refresh="false"):
	main_cache.set(setting_id, "", expiration=365)
	notification("Success", 2500)
	if refresh == "true":
		kodi_refresh()


def clear_all_history(refresh="false"):
	"""Clear every Finder search-history cache without opening a selection dialog.

	Used by the integrated Finder Skin search window. Standalone Finder continues
	to use clear_search(), which preserves the existing per-category chooser.
	"""
	history_ids = (
		"movie_queries",
		"tvshow_queries",
		"anime_queries",
		"tvshow_anime_queries",
		"people_queries",
		"keyword_tmdb_movie_queries",
		"keyword_tmdb_tvshow_queries",
		"easynews_video_queries",
		"easynews_image_queries",
		"trakt_list_queries",
	)
	for setting_id in history_ids:
		main_cache.set(setting_id, "", expiration=365)
	notification("Search history cleared", 2000)
	if refresh == "true":
		kodi_refresh()
