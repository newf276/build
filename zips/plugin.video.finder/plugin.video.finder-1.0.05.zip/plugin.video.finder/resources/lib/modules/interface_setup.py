# -*- coding: utf-8 -*-
"""Finder interface mode selection.

Finder owns the decision and presentation trigger. skin.finder remains optional;
its custom windows are touched only when it is the active Kodi skin.
"""
import xbmc
from xbmcgui import Dialog

from caches.settings_cache import get_setting, set_setting
from modules.kodi_utils import logger

SETTING_ID = "interface_mode"
INTEGRATED = "integrated"
STANDALONE = "standalone"
SKIN_ID = "skin.finder"


def finder_skin_active():
    try:
        return xbmc.getSkinDir() == SKIN_ID
    except Exception:
        return False


def _choose():
    dialog = Dialog()
    options = [
        "Finder + Finder Skin",
        "Finder Standalone",
    ]
    choice = dialog.select("Welcome to Finder", options)
    if choice < 0:
        return None
    return INTEGRATED if choice == 0 else STANDALONE


def ensure_mode():
    """Run the first-use choice once, then return the stored mode.

    Returns None when the user cancels the first-use dialog.
    """
    current = get_setting(SETTING_ID, "empty_setting")
    if current in (INTEGRATED, STANDALONE):
        return current

    choice = _choose()
    if choice is None:
        logger("Finder", "Interface selection cancelled; startup deferred")
        return None

    set_setting(SETTING_ID, choice)
    logger("Finder", "Interface mode selected: %s" % choice)

    if choice == INTEGRATED:
        if not finder_skin_active():
            set_setting(SETTING_ID, STANDALONE)
            dialog = Dialog()
            dialog.ok(
                "Finder - Finder Skin",
                "Finder Skin is not the active Kodi skin.\n\n"
                "Finder will continue in Standalone mode."
            )
            logger("Finder", "Finder Skin was not active; fell back to standalone mode")
            return STANDALONE
        # The Pre-Config selector is owned by the active Finder Skin; Finder
        # owns the decision to open it. Never execute this for standalone mode.
        xbmc.executebuiltin("ActivateWindow(1159)")

    return choice


def setup():
    """Tools entry: change the saved interface mode later."""
    current = get_setting(SETTING_ID, "empty_setting")
    current_label = {
        INTEGRATED: "Finder + Finder Skin",
        STANDALONE: "Finder Standalone",
    }.get(current, "Not selected")

    choice = Dialog().select(
        "Finder Interface Setup",
        [
            "Finder + Finder Skin",
            "Finder Standalone",
        ],
    )
    if choice < 0:
        return

    selected = INTEGRATED if choice == 0 else STANDALONE
    if selected == INTEGRATED and not finder_skin_active():
        Dialog().ok(
            "Finder - Finder Skin",
            "Finder Skin must be the active Kodi skin to use the integrated mode."
        )
        logger("Finder", "Interface Setup rejected integrated mode: Finder Skin not active")
        return

    set_setting(SETTING_ID, selected)
    logger("Finder", "Interface mode changed: %s -> %s" % (current_label, selected))
    if selected == INTEGRATED:
        xbmc.executebuiltin("ActivateWindow(1159)")
