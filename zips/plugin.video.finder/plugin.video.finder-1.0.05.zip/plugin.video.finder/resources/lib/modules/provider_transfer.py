# -*- coding: utf-8 -*-
"""Manual, additive Trakt <-> PunchPlay transfer.

This is deliberately NOT a background mirror.  A run reads both providers and
adds missing items to the other side; it never removes existing user data.
"""
import xbmcgui
from modules import kodi_utils, settings


def _pp_api():
    from apis import punchplay_api
    return punchplay_api


def _trakt_api():
    from apis import trakt_api
    return trakt_api


def _norm_id(value):
    try:
        return str(int(value)) if value not in (None, '', 'None') else ''
    except Exception:
        return str(value) if value not in (None, '') else ''


def _pp_kind(row):
    kind = str(row.get('kind') or row.get('type') or '').lower()
    return 'movie' if kind in ('movie', 'movies') else 'show'


def _pp_id(row):
    return _norm_id(row.get('tmdbId') or row.get('tmdb_id') or row.get('sourceId') or row.get('media_ids', {}).get('tmdb'))


def _trakt_id(row, key):
    obj = row.get(key) or {}
    return _norm_id((obj.get('ids') or {}).get('tmdb'))


def _trakt_payload(tmdb_id, kind):
    key = 'movies' if kind == 'movie' else 'shows'
    return {key: [{'ids': {'tmdb': int(tmdb_id)}}]}


def _pp_ctx(tmdb_id, kind, title=''):
    return {
        'tmdb_id': tmdb_id,
        'media_type': 'movie' if kind == 'movie' else 'tvshow',
        'media_type_raw': 'movie' if kind == 'movie' else 'tvshow',
        'title': title or str(tmdb_id),
    }


def _pp_write_ok(value):
    if isinstance(value, tuple) and len(value) >= 3:
        return bool(value[0])
    return bool(value)


def _choose_scope():
    labels = ['Watchlist', 'Collection', 'Personal Lists', 'All Three']
    values = ['watchlist', 'collection', 'personal', 'all']
    items = [{'line1': label} for label in labels]
    idx = kodi_utils.select_dialog(values, items=__import__('json').dumps(items), heading='Trakt ↔ PunchPlay Transfer')
    if idx is None:
        return None
    return idx


def _choose_direction():
    labels = ['Two-Way (Additive)', 'Trakt → PunchPlay', 'PunchPlay → Trakt']
    values = ['both', 'to_pp', 'to_trakt']
    items = [{'line1': labels[i]} for i in range(len(labels))]
    return kodi_utils.select_dialog(values, items=__import__('json').dumps(items), heading='Transfer Direction')


def _trakt_watchlist():
    api = _trakt_api()
    out = []
    for media_type, key in (('movie', 'movies'), ('show', 'shows')):
        try:
            rows = api.trakt_fetch_collection_watchlist('watchlist', media_type) or []
        except Exception as e:
            kodi_utils.logger('Provider Transfer', 'Trakt watchlist read failed: %s' % e)
            rows = []
        for row in rows:
            tid = _norm_id((row.get('media_ids') or {}).get('tmdb'))
            if tid:
                out.append((tid, media_type, row.get('title') or tid))
    return out


def _trakt_collection():
    api = _trakt_api()
    out = []
    for media_type in ('movie', 'show'):
        try:
            rows = api.trakt_fetch_collection_watchlist('collection', media_type) or []
        except Exception as e:
            kodi_utils.logger('Provider Transfer', 'Trakt collection read failed: %s' % e)
            rows = []
        for row in rows:
            tid = _norm_id((row.get('media_ids') or {}).get('tmdb'))
            if tid:
                out.append((tid, media_type, row.get('title') or tid))
    return out


def _pp_watchlist():
    api = _pp_api()
    out = []
    for kind in ('movie', 'tvshow'):
        try:
            rows = api.punchplay_watchlist(kind, 1) or []
        except Exception as e:
            kodi_utils.logger('Provider Transfer', 'PunchPlay watchlist read failed: %s' % e)
            rows = []
        for row in rows:
            tid = _pp_id(row)
            if tid:
                out.append((tid, 'movie' if kind == 'movie' else 'show', row.get('title') or tid))
    return out


def _pp_collection():
    api = _pp_api()
    out = []
    for kind in ('movie', 'tvshow'):
        try:
            rows = api.punchplay_collection(kind, 1) or []
        except Exception as e:
            kodi_utils.logger('Provider Transfer', 'PunchPlay collection read failed: %s' % e)
            rows = []
        for row in rows:
            tid = _pp_id(row)
            if tid:
                out.append((tid, 'movie' if kind == 'movie' else 'show', row.get('title') or tid))
    return out


def _trakt_lists():
    api = _trakt_api()
    lists = api.trakt_get_lists('my_lists') or []
    result = []
    for lst in lists:
        user = lst.get('user', {}).get('username') if isinstance(lst.get('user'), dict) else lst.get('username')
        user = user or lst.get('user') or api.get_trakt_username()
        slug = (lst.get('ids') or {}).get('slug') or lst.get('slug')
        name = lst.get('name') or slug or 'Trakt List'
        if not slug:
            continue
        try:
            rows = api.get_trakt_list_contents('my_lists', user, slug, True, sort_by='skip') or []
        except Exception as e:
            kodi_utils.logger('Provider Transfer', 'Trakt list read failed (%s): %s' % (name, e))
            rows = []
        items = []
        for row in rows:
            for key, kind in (('movie', 'movie'), ('show', 'show')):
                if key in row:
                    tid = _trakt_id(row, key)
                    if tid:
                        items.append((tid, kind, (row.get(key) or {}).get('title') or tid))
                    break
        result.append({'name': name, 'user': user, 'slug': slug, 'items': items})
    return result


def _pp_lists():
    api = _pp_api()
    result = []
    for lst in api.punchplay_get_lists() or []:
        if lst.get('isWatchlist') or not lst.get('id'):
            continue
        lid = str(lst.get('id'))
        name = lst.get('name') or 'PunchPlay List'
        try:
            rows = api.punchplay_list_items(lid, 'movie') or []
            rows += api.punchplay_list_items(lid, 'tvshow') or []
        except Exception as e:
            kodi_utils.logger('Provider Transfer', 'PunchPlay list read failed (%s): %s' % (name, e))
            rows = []
        items = []
        seen = set()
        for row in rows:
            tid = _pp_id(row)
            if not tid or tid in seen:
                continue
            seen.add(tid)
            items.append((tid, _pp_kind(row), row.get('title') or tid))
        result.append({'name': name, 'id': lid, 'items': items})
    return result


def _add_watchlist_to_pp(rows):
    api = _pp_api(); existing = {_norm_id(r[0]) for r in _pp_watchlist()}; added = failed = 0
    for tid, kind, title in rows:
        if tid in existing:
            continue
        ok = _pp_write_ok(api.punchplay_watchlist_add(_pp_ctx(tid, kind, title)))
        if ok:
            existing.add(tid); added += 1
        else:
            failed += 1
    return added, failed


def _add_watchlist_to_trakt(rows):
    api = _trakt_api(); existing = {_norm_id(r[0]) for r in _trakt_watchlist()}; added = failed = 0
    for tid, kind, _title in rows:
        if tid in existing:
            continue
        try:
            result = api.add_to_watchlist(_trakt_payload(tid, kind))
            ok = isinstance(result, dict) and (result.get('added') or {}).get('movies', 0) + (result.get('added') or {}).get('shows', 0) > 0
        except Exception:
            ok = False
        if ok:
            existing.add(tid); added += 1
        else:
            failed += 1
    return added, failed


def _add_collection_to_pp(rows):
    api = _pp_api(); existing = {_norm_id(r[0]) for r in _pp_collection()}; added = failed = 0
    for tid, kind, title in rows:
        if tid in existing:
            continue
        ok = _pp_write_ok(api.punchplay_collection_add(_pp_ctx(tid, kind, title)))
        if ok:
            existing.add(tid); added += 1
        else:
            failed += 1
    return added, failed


def _add_collection_to_trakt(rows):
    api = _trakt_api(); existing = {_norm_id(r[0]) for r in _trakt_collection()}; added = failed = 0
    for tid, kind, _title in rows:
        if tid in existing:
            continue
        try:
            result = api.add_to_collection(_trakt_payload(tid, kind))
            ok = isinstance(result, dict) and (result.get('added') or {}).get('movies', 0) + (result.get('added') or {}).get('shows', 0) > 0
        except Exception:
            ok = False
        if ok:
            existing.add(tid); added += 1
        else:
            failed += 1
    return added, failed


def _find_pp_list(lists, name):
    needle = (name or '').strip().casefold()
    return next((x for x in lists if (x.get('name') or '').strip().casefold() == needle), None)


def _find_trakt_list(lists, name):
    needle = (name or '').strip().casefold()
    return next((x for x in lists if (x.get('name') or '').strip().casefold() == needle), None)


def _create_pp_list(name):
    try:
        return _pp_api().punchplay_create_list(name)
    except Exception as e:
        kodi_utils.logger('Provider Transfer', 'PunchPlay list creation failed: %s' % e)
        return None


def _create_trakt_list(name):
    try:
        from apis.trakt_api.core import call_trakt
        return call_trakt('users/me/lists', data={'name': name[:500], 'privacy': 'private', 'allow_comments': False})
    except Exception as e:
        kodi_utils.logger('Provider Transfer', 'Trakt list creation failed: %s' % e)
        return None


def _add_personal_to_pp(trakt_lists):
    api = _pp_api(); pp_lists = _pp_lists(); added = failed = lists_created = 0
    for src in trakt_lists:
        dst = _find_pp_list(pp_lists, src['name'])
        if not dst:
            created = _create_pp_list(src['name'])
            if not isinstance(created, dict):
                failed += len(src['items']); continue
            lid = str(created.get('id') or created.get('list', {}).get('id') or '')
            if not lid:
                failed += len(src['items']); continue
            dst = {'id': lid, 'name': src['name'], 'items': []}; pp_lists.append(dst); lists_created += 1
        existing = {_norm_id(x[0]) for x in dst.get('items', [])}
        for tid, kind, title in src['items']:
            if tid in existing: continue
            ok = _pp_write_ok(api.punchplay_list_add(_pp_ctx(tid, kind, title), dst['id']))
            if ok: existing.add(tid); added += 1
            else: failed += 1
    return added, failed, lists_created


def _add_personal_to_trakt(pp_lists):
    api = _trakt_api(); tr_lists = _trakt_lists(); added = failed = lists_created = 0
    for src in pp_lists:
        dst = _find_trakt_list(tr_lists, src['name'])
        if not dst:
            created = _create_trakt_list(src['name'])
            if not isinstance(created, dict):
                failed += len(src['items']); continue
            ids = created.get('ids') or {}
            slug = ids.get('slug') or created.get('slug')
            user = (created.get('user') or {}).get('username') if isinstance(created.get('user'), dict) else None
            user = user or api.get_trakt_username()
            if not slug or not user:
                failed += len(src['items']); continue
            dst = {'name': src['name'], 'slug': slug, 'user': user, 'items': []}; tr_lists.append(dst); lists_created += 1
        existing = {_norm_id(x[0]) for x in dst.get('items', [])}
        for tid, kind, _title in src['items']:
            if tid in existing: continue
            try:
                result = api.add_to_list(dst['user'], dst['slug'], _trakt_payload(tid, kind))
                ok = isinstance(result, dict) and (result.get('added') or {}).get('movies', 0) + (result.get('added') or {}).get('shows', 0) > 0
            except Exception:
                ok = False
            if ok: existing.add(tid); added += 1
            else: failed += 1
    return added, failed, lists_created


def _run_one(scope, direction):
    summary = []
    if scope in ('watchlist', 'all'):
        tr = _trakt_watchlist(); pp = _pp_watchlist()
        if direction in ('both', 'to_pp'):
            a, f = _add_watchlist_to_pp(tr); summary.append('Watchlist Trakt → PunchPlay: +%d%s' % (a, (' (%d failed)' % f) if f else ''))
        if direction in ('both', 'to_trakt'):
            a, f = _add_watchlist_to_trakt(pp); summary.append('Watchlist PunchPlay → Trakt: +%d%s' % (a, (' (%d failed)' % f) if f else ''))
    if scope in ('collection', 'all'):
        tr = _trakt_collection(); pp = _pp_collection()
        if direction in ('both', 'to_pp'):
            a, f = _add_collection_to_pp(tr); summary.append('Collection Trakt → PunchPlay: +%d%s' % (a, (' (%d failed)' % f) if f else ''))
        if direction in ('both', 'to_trakt'):
            a, f = _add_collection_to_trakt(pp); summary.append('Collection PunchPlay → Trakt: +%d%s' % (a, (' (%d failed)' % f) if f else ''))
    if scope in ('personal', 'all'):
        tr = _trakt_lists(); pp = _pp_lists()
        if direction in ('both', 'to_pp'):
            a, f, c = _add_personal_to_pp(tr); summary.append('Personal Lists Trakt → PunchPlay: +%d, %d created%s' % (a, c, (' (%d failed)' % f) if f else ''))
        if direction in ('both', 'to_trakt'):
            a, f, c = _add_personal_to_trakt(pp); summary.append('Personal Lists PunchPlay → Trakt: +%d, %d created%s' % (a, c, (' (%d failed)' % f) if f else ''))
    return summary


def run(params=None):
    if not settings.trakt_user_active() and not settings.punchplay_user_active():
        return kodi_utils.notification('Authorize Trakt and/or PunchPlay first', 4000)
    if not settings.trakt_user_active():
        return kodi_utils.notification('Trakt is not authorized', 3500)
    if not settings.punchplay_user_active():
        return kodi_utils.notification('PunchPlay is not authorized', 3500)
    scope = _choose_scope()
    if scope is None: return
    direction = _choose_direction()
    if direction is None: return
    text = ('This is a one-time additive transfer. Existing items are never removed.\n\n'
            'The selected data will be read from both services and missing items added to the other service.')
    if not kodi_utils.confirm_dialog(heading='Trakt ↔ PunchPlay Transfer', text=text, ok_label='Start', cancel_label='Cancel'):
        return
    dialog = xbmcgui.DialogProgress()
    dialog.create('Finder', 'Transferring Trakt ↔ PunchPlay data...')
    try:
        summary = _run_one(scope, direction)
    except Exception as e:
        kodi_utils.logger('Provider Transfer', 'Transfer failed: %s' % e)
        dialog.close()
        return kodi_utils.notification('Transfer failed: %s' % e, 5000)
    dialog.close()
    msg = '\n'.join(summary) if summary else 'Nothing to transfer.'
    kodi_utils.notification('Transfer complete.\n%s' % msg, 7000)
    kodi_utils.refresh_after_action(refresh_when_internal=True)
