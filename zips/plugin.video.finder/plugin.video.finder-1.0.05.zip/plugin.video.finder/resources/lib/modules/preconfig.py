# -*- coding: utf-8 -*-

import xbmc

from caches.settings_cache import get_setting, set_setting


_PRESETS = {
    "punchplay_collection": {
        "watched_indicators": "2",
        "primary_tracker_selected": "2",
        "quick_add_target": "punchplay_collection",
        "quick_add_label": "PunchPlay Collection",
    },
    "punchplay_watchlist": {
        "watched_indicators": "2",
        "primary_tracker_selected": "2",
        "quick_add_target": "punchplay_collection",
        "quick_add_label": "PunchPlay Collection",
    },
    "tmdb_watchlist": {
        "watched_indicators": "0",
        "primary_tracker_selected": "0",
        "quick_add_target": "tmdb_watchlist",
        "quick_add_label": "TMDb Watchlist",
    },
    "trakt_collection": {
        "watched_indicators": "1",
        "primary_tracker_selected": "1",
        "quick_add_target": "trakt_collection",
        "quick_add_label": "Trakt Collection",
    },
    "trakt_watchlist": {
        "watched_indicators": "1",
        "primary_tracker_selected": "1",
        "quick_add_target": "trakt_collection",
        "quick_add_label": "Trakt Collection",
    },
}


def apply(params):
    preset = params.get("preset", "")
    config = _PRESETS.get(preset)
    if not config:
        xbmc.log("###Finder###: Pre-Config unknown preset: %s" % preset, xbmc.LOGERROR)
        return

    try:
        # Write all four Finder settings before touching the skin.  ReloadSkin is
        # intentionally owned by this function so the XML cannot interrupt a
        # partially completed configuration.
        set_setting("watched_indicators", config["watched_indicators"])
        set_setting("primary_tracker_selected", config["primary_tracker_selected"])
        set_setting("context_menu.quick_add_target", config["quick_add_target"])
        set_setting("context_menu.quick_add_target_label", config["quick_add_label"])
        xbmc.executebuiltin("Skin.SetString(FinderHomePreset,%s)" % preset)

        verified = (
            get_setting("watched_indicators", "") == config["watched_indicators"]
            and get_setting("primary_tracker_selected", "") == config["primary_tracker_selected"]
            and get_setting("finder.context_menu.quick_add_target", "") == config["quick_add_target"]
            and get_setting("finder.context_menu.quick_add_target_label", "") == config["quick_add_label"]
        )
        xbmc.log(
            "###Finder###: Pre-Config applied: %s | watched=%s | tracker=%s | quick_add=%s | verified=%s"
            % (
                preset,
                config["watched_indicators"],
                config["primary_tracker_selected"],
                config["quick_add_target"],
                verified,
            ),
            xbmc.LOGINFO,
        )
        if not verified:
            xbmc.log("###Finder###: Pre-Config verification failed: %s" % preset, xbmc.LOGERROR)
            return

        xbmc.executebuiltin("ReloadSkin()")
    except Exception as exc:
        xbmc.log("###Finder###: Pre-Config failed for %s: %s" % (preset, exc), xbmc.LOGERROR)
