# -*- coding: utf-8 -*-
"""Finder Skin MDbList ratings service.

Feeds the existing skin.finder Side Info / widget rating controls directly from
MDbList.  This replaces the old FENtastic-helper ratings dependency; no helper
addon is required.
"""
import datetime as dt
import json
import os
import sqlite3
from threading import Lock, Thread

import xbmc
import xbmcgui

from modules import kodi_utils


_API_URL = "https://mdblist.com/api/?apikey=%s&i=%s"
_EMPTY = {
    "metascore": "", "metascoreImage": "",
    "tomatoMeter": "", "tomatoImage": "",
    "tomatoUserMeter": "", "tomatoUserImage": "",
    "imdbRating": "", "imdbImage": "",
    "popularRating": "", "popularImage": "",
    "tmdbRating": "", "tmdbImage": "",
}


class MDbListRatingsCache:
    def __init__(self):
        profile = kodi_utils.translate_path(kodi_utils.addon_info("profile"))
        os.makedirs(profile, exist_ok=True)
        self.path = os.path.join(profile, "mdblist_ratings_cache.db")
        self.lock = Lock()
        with sqlite3.connect(self.path, timeout=30) as db:
            db.execute("CREATE TABLE IF NOT EXISTS ratings (imdb_id TEXT PRIMARY KEY, ratings TEXT, updated TEXT)")

    def get(self, imdb_id):
        try:
            with self.lock, sqlite3.connect(self.path, timeout=30) as db:
                row = db.execute("SELECT ratings, updated FROM ratings WHERE imdb_id=?", (imdb_id,)).fetchone()
            if not row:
                return None
            updated = dt.datetime.fromisoformat(row[1])
            if dt.datetime.now() - updated >= dt.timedelta(days=7):
                return None
            return json.loads(row[0])
        except Exception:
            return None

    def set(self, imdb_id, ratings):
        try:
            with self.lock, sqlite3.connect(self.path, timeout=30) as db:
                db.execute(
                    "INSERT OR REPLACE INTO ratings (imdb_id, ratings, updated) VALUES (?, ?, ?)",
                    (imdb_id, json.dumps(ratings), dt.datetime.now().isoformat()),
                )
        except Exception as exc:
            kodi_utils.logger("Finder", "MDbList ratings cache write failed: %s" % exc)


class FinderMDbListRatings:
    def __init__(self):
        self.cache = MDbListRatingsCache()
        self.session = kodi_utils.make_session("https://mdblist.com/")
        self.last_imdb_id = None
        self.pending_imdb_id = None
        self.lock = Lock()

    @staticmethod
    def _image(name):
        return "special://home/addons/skin.finder/resources/rating_images/%s" % name

    @staticmethod
    def _window():
        return xbmcgui.Window(xbmcgui.getCurrentWindowId())

    def _publish(self, data):
        win = self._window()
        for key, value in _EMPTY.items():
            win.setProperty("finder.%s" % key, str(data.get(key, value)))

    def _clear(self):
        self._publish({})

    def _fetch(self, api_key, imdb_id):
        cached = self.cache.get(imdb_id)
        if cached is not None:
            return cached
        try:
            response = self.session.get(_API_URL % (api_key, imdb_id), timeout=15)
            if response.status_code != 200:
                kodi_utils.logger("Finder", "MDbList ratings HTTP %s for %s" % (response.status_code, imdb_id))
                return {}
            payload = response.json()
            data = {}
            for rating in payload.get("ratings", []):
                source = rating.get("source")
                value = rating.get("value")
                popular = rating.get("popular")
                if source == "imdb" and value is not None:
                    data["imdbRating"] = str(value)
                    data["imdbImage"] = self._image("imdb.png")
                    if popular is not None:
                        data["popularRating"] = "#%s" % popular
                        if popular <= 10: icon = "purpleflame.png"
                        elif popular <= 33: icon = "pinkflame.png"
                        elif popular <= 66: icon = "redflame.png"
                        elif popular <= 100: icon = "blueflame.png"
                        else: icon = ""
                        data["popularImage"] = self._image(icon) if icon else ""
                elif source == "metacritic" and value is not None:
                    data["metascore"] = str(value)
                    data["metascoreImage"] = self._image("metacritic.png")
                elif source == "tomatoes" and value is not None:
                    data["tomatoMeter"] = str(value)
                    icon = "rtcertified.png" if value > 74 else "rtfresh.png" if value > 59 else "rtrotten.png"
                    data["tomatoImage"] = self._image(icon)
                elif source in ("tomatoesaudience", "popcorn") and value is not None:
                    data["tomatoUserMeter"] = str(value)
                    data["tomatoUserImage"] = self._image("popcorn.png" if value > 59 else "popcorn_spilt.png")
                elif source == "tmdb" and value is not None:
                    # MDbList currently returns TMDb on a 0-100 scale.
                    data["tmdbRating"] = str(round(float(value) / 10.0, 1))
                    data["tmdbImage"] = self._image("tmdb.png")
            self.cache.set(imdb_id, data)
            return data
        except Exception as exc:
            kodi_utils.logger("Finder", "MDbList ratings fetch failed for %s: %s" % (imdb_id, exc))
            return {}

    def _worker(self, api_key, imdb_id):
        try:
            result = self._fetch(api_key, imdb_id)
            # Do not paint a stale response if focus moved while the request ran.
            if xbmc.getInfoLabel("ListItem.IMDBNumber") == imdb_id:
                self._publish(result)
                self.last_imdb_id = imdb_id
        finally:
            with self.lock:
                if self.pending_imdb_id == imdb_id:
                    self.pending_imdb_id = None

    def run(self):
        kodi_utils.logger("Finder", "MDbList Ratings Service Starting")
        monitor = kodi_utils.kodi_monitor()
        while not monitor.abortRequested():
            if kodi_utils.current_skin() != "skin.finder":
                self._clear()
                self.last_imdb_id = None
                if monitor.waitForAbort(5): break
                continue
            api_key = xbmc.getInfoLabel("Skin.String(mdblist_api_key)")
            if not api_key:
                self._clear()
                self.last_imdb_id = None
                if monitor.waitForAbort(2): break
                continue
            if kodi_utils.get_property("finder.pause_services") == "true":
                if monitor.waitForAbort(2): break
                continue
            if not xbmc.getCondVisibility("Window.IsVisible(videos) | Window.IsVisible(home) | Window.IsVisible(1121)"):
                if monitor.waitForAbort(1): break
                continue
            if xbmc.getCondVisibility("Container.Scrolling"):
                if monitor.waitForAbort(0.2): break
                continue
            imdb_id = xbmc.getInfoLabel("ListItem.IMDBNumber")
            if not imdb_id or not imdb_id.startswith("tt"):
                if self.last_imdb_id is not None:
                    self._clear()
                    self.last_imdb_id = None
                if monitor.waitForAbort(0.2): break
                continue
            if imdb_id == self.last_imdb_id:
                if monitor.waitForAbort(0.2): break
                continue
            cached = self.cache.get(imdb_id)
            if cached is not None:
                self._publish(cached)
                self.last_imdb_id = imdb_id
                if monitor.waitForAbort(0.2): break
                continue
            with self.lock:
                if self.pending_imdb_id != imdb_id:
                    self.pending_imdb_id = imdb_id
                    Thread(target=self._worker, args=(api_key, imdb_id), daemon=True).start()
            if monitor.waitForAbort(0.2): break
        self._clear()
        kodi_utils.logger("Finder", "MDbList Ratings Service Finished")
