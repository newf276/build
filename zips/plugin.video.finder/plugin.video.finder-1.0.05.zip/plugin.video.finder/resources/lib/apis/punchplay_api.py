# -*- coding: utf-8 -*-
"""PunchPlay provider for Finder.

Phase 1: device OAuth, token refresh, account lists/shelves, and watchlist
Quick Add support. Finder deliberately keeps its own settings architecture.
"""
import json
import time
import uuid
from threading import Lock
import requests

# Persistent HTTP session matching the known-working TMDbMovies PunchPlay transport.
_PP_SESSION = requests.Session()
from apis._http import TIMEOUT_STANDARD, TIMEOUT_LONG
from caches.settings_cache import get_setting, set_setting
from modules import kodi_utils, settings
from modules.utils import copy2clip, launch_browser, make_qrcode

BASE_URL = 'https://punchplay.tv'
API_PREFIX = '/api/platform/v1'
CLIENT_SETTING = 'finder.punchplay.client'
TOKEN_SETTING = 'finder.punchplay.token'
REFRESH_SETTING = 'finder.punchplay.refresh'
EXPIRES_SETTING = 'finder.punchplay.expires'
USER_SETTING = 'finder.punchplay.user'
DEVICE_SETTING = 'finder.punchplay.device_id'
DEFAULT_SCOPES = ('profile:read playback:read playback:write history:read history:write '
                  'lists:read lists:write ratings:read ratings:write collection:read collection:write')
_REFRESH_LOCK = Lock()
_REFRESH_LOCK_STALE_SEC = 25
_REFRESH_WAIT_SEC = 20
_refresh_lock_path = None


def punchplay_client(): return get_setting(CLIENT_SETTING, '')
def punchplay_user_active():
    # The access token is the authoritative authenticated state.
    return _token() not in ('', '0', 'empty_setting', None)
def _token(): return get_setting(TOKEN_SETTING, '0')
def _refresh(): return get_setting(REFRESH_SETTING, '0')
def _device_id():
    value = get_setting(DEVICE_SETTING, '')
    if not value:
        value = str(uuid.uuid4())
        set_setting('punchplay.device_id', value)
    return value

def _url(path, query=None):
    url = BASE_URL.rstrip('/') + API_PREFIX + ('/' + path.lstrip('/') if path else '')
    if query:
        q = [(k, str(v)) for k, v in query.items() if v not in (None, '')]
        if q: url += '?' + '&'.join('%s=%s' % (k, requests.utils.quote(v, safe='')) for k, v in q)
    return url

def _headers(auth=True, include_content_type=True):
    h = {'Accept': 'application/json', 'User-Agent': 'TMDbMovies/1.0 (Kodi addon)'}
    if include_content_type:
        h['Content-Type'] = 'application/json'
    if auth and _token() not in ('', '0', 'empty_setting', None):
        h['Authorization'] = 'Bearer %s' % _token()
    return h

def _token_usable(token):
    return token not in (None, '0', '', 'empty_setting')

def _reload_token_cache():
    try:
        from caches.settings_cache import reload_auth_from_db
        reload_auth_from_db('punchplay.token', 'punchplay.refresh', 'punchplay.expires')
    except Exception:
        # Older Finder cache modules may not expose the RedLight helper.
        try:
            from caches.settings_cache import settings_cache
            settings_cache.set_memory_cache('punchplay.token', settings_cache.get('punchplay.token'))
            settings_cache.set_memory_cache('punchplay.refresh', settings_cache.get('punchplay.refresh'))
            settings_cache.set_memory_cache('punchplay.expires', settings_cache.get('punchplay.expires'))
        except Exception:
            pass

def _expires_at():
    raw = get_setting(EXPIRES_SETTING, '0')
    try: return float(raw or 0)
    except (TypeError, ValueError): return 0.0

def _token_fresh():
    if not _token_usable(_token()): return False
    expires = _expires_at()
    # Legacy rows with no expiry remain usable until a 401 forces refresh.
    if expires <= 0: return True
    return time.time() < expires

def _refresh_lockfile():
    global _refresh_lock_path
    if not _refresh_lock_path:
        _refresh_lock_path = '%s/punchplay_refresh.lock' % kodi_utils.addon_profile()
    return _refresh_lock_path

def _try_acquire_refresh_lockfile():
    import os
    path = _refresh_lockfile()
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        try: os.write(fd, str(time.time()).encode('utf-8'))
        finally: os.close(fd)
        return True
    except OSError:
        try:
            if (time.time() - os.path.getmtime(path)) >= _REFRESH_LOCK_STALE_SEC:
                os.remove(path)
                return _try_acquire_refresh_lockfile()
        except Exception:
            pass
        return False

def _release_refresh_lockfile():
    import os
    try: os.remove(_refresh_lockfile())
    except Exception: pass

def _save_tokens(payload, require_refresh=False):
    access = payload.get('access_token') if isinstance(payload, dict) else None
    refresh = payload.get('refresh_token') if isinstance(payload, dict) else None
    if not access: return False
    if require_refresh and not refresh: return False
    set_setting('punchplay.token', access)
    if refresh: set_setting('punchplay.refresh', refresh)
    expires_in = int(payload.get('expires_in') or 3600)
    set_setting('punchplay.expires', str(int(time.time()) + max(60, expires_in) - 60))
    try:
        from caches.settings_cache import settings_cache
        settings_cache.set_memory_cache('punchplay.token', access)
        if refresh: settings_cache.set_memory_cache('punchplay.refresh', refresh)
        settings_cache.set_memory_cache('punchplay.expires', str(int(time.time()) + max(60, expires_in) - 60))
    except Exception:
        pass
    kodi_utils.logger('PunchPlay', 'access token saved; refresh=%s' % ('yes' if refresh else 'no'))
    return True

def _refresh_access_token():
    # Match the known-working RedLight implementation: the PunchPlay refresh
    # request is bound to the configured Client ID and the refresh token.
    client_id = punchplay_client()
    refresh = _refresh()
    if not client_id or not _token_usable(refresh): return False
    try:
        resp = requests.post(
            _url('/auth/refresh'),
            data=json.dumps({'client_id': client_id, 'refresh_token': refresh}),
            headers=_headers(False), timeout=TIMEOUT_STANDARD)
        if resp.status_code != 200:
            detail, request_id = '', ''
            try:
                body = resp.json() or {}
                if isinstance(body, dict):
                    detail = body.get('message') or body.get('error') or ''
                    request_id = body.get('request_id') or ''
            except Exception:
                pass
            kodi_utils.logger('PunchPlay', 'refresh failed: HTTP %s%s%s' % (
                resp.status_code,
                (': %s' % detail) if detail else '',
                (' request_id=%s' % request_id) if request_id else ''))
            return False
        payload = resp.json() or {}
        if not payload.get('refresh_token'):
            kodi_utils.logger('PunchPlay', 'refresh failed: missing rotated refresh_token')
            return False
        ok = _save_tokens(payload, require_refresh=True)
        if ok: kodi_utils.logger('PunchPlay', 'access token refreshed')
        return ok
    except Exception as e:
        kodi_utils.logger('PunchPlay', 'refresh failed: %s' % e)
        return False

def _ensure_access_token(failed_token=None):
    # Protect both threads and separate Kodi Python invokers. PunchPlay rotates
    # refresh tokens, so two simultaneous refresh calls can invalidate each other.
    if failed_token is None and _token_fresh(): return True
    with _REFRESH_LOCK:
        _reload_token_cache()
        current = _token()
        if failed_token and _token_usable(current) and current != failed_token:
            return True
        if failed_token is None and _token_fresh():
            return True
        deadline = time.time() + _REFRESH_WAIT_SEC
        owned = _try_acquire_refresh_lockfile()
        while not owned and time.time() < deadline:
            kodi_utils.sleep(200)
            _reload_token_cache()
            current = _token()
            if failed_token and _token_usable(current) and current != failed_token:
                return True
            if failed_token is None and _token_fresh():
                return True
            owned = _try_acquire_refresh_lockfile()
        if not owned:
            _reload_token_cache()
            current = _token()
            return bool(failed_token and _token_usable(current) and current != failed_token) or _token_fresh()
        try:
            _reload_token_cache()
            current = _token()
            if failed_token and _token_usable(current) and current != failed_token:
                return True
            if failed_token is None and _token_fresh():
                return True
            return _refresh_access_token()
        finally:
            _release_refresh_lockfile()

def _refresh_token():
    return _ensure_access_token()

def _ensure_token():
    return _ensure_access_token()

def call_punchplay(path, method='get', data=None, query=None, retry=True, return_status=False):
    if punchplay_user_active():
        _ensure_access_token()
    try:
        # Match TMDbMovies' known-working PunchPlay transport exactly:
        # persistent Session + Session.request(), with explicit params/json.
        json_data = data or {} if method in ('post', 'patch') else None
        r = _PP_SESSION.request(
            method.upper(),
            _url(path),
            params=query,
            json=json_data,
            headers=_headers(include_content_type=(method != 'delete')),
            timeout=TIMEOUT_LONG)
        if r.status_code == 401 and retry:
            failed_token = _token()
            kodi_utils.logger('PunchPlay', 'HTTP 401 %s; attempting token refresh' % path)
            if _ensure_access_token(failed_token=failed_token):
                return call_punchplay(path, method=method, data=data, query=query, retry=False, return_status=return_status)
        if r.status_code >= 400:
            kodi_utils.logger('PunchPlay', 'HTTP %s %s%s' % (r.status_code, path, (' body=' + r.text[:300]) if r.text else ''))
            return (False, r.status_code, {}) if return_status else {}
        if r.status_code == 204 or not r.content:
            return (True, r.status_code, {}) if return_status else True
        try: body = r.json() or {}
        except Exception: body = {}
        return (True, r.status_code, body) if return_status else body
    except Exception as e:
        kodi_utils.logger('PunchPlay', '%s: %s' % (path, e))
        return (False, 0, {}) if return_status else {}

def _items(data):
    if isinstance(data, list): return data
    if not isinstance(data, dict): return []
    for key in ('items', 'results', 'data'):
        value = data.get(key)
        if isinstance(value, list): return value
        if isinstance(value, dict) and isinstance(value.get('items'), list): return value['items']
    return []

def _row(entry):
    tid = entry.get('tmdbId') or entry.get('tmdb_id') or entry.get('sourceId')
    if not tid: return None
    try: tid = int(tid)
    except: return None
    kind = str(entry.get('kind') or entry.get('type') or 'movie').lower()
    media_type = 'movie' if kind in ('movie', 'movies') else ('anime' if entry.get('isAnime') or kind == 'anime' else 'show')
    return {'media_ids': {'tmdb': tid}, 'type': media_type, 'title': entry.get('title', ''), 'order': entry.get('order', 0)}

def _status(status, media_kind):
    rows = []
    data = call_punchplay('/me/watch-status', query={'page': 1, 'pageSize': 200})
    for entry in _items(data):
        if str(entry.get('showStatus') or entry.get('status') or '').upper() != status: continue
        row = _row(entry)
        if row and (media_kind == 'movie' and row['type'] == 'movie' or media_kind != 'movie' and row['type'] in ('show','anime')): rows.append(row)
    return rows

def punchplay_watching(media_kind, page_no=1): return _status('WATCHING', media_kind)
def punchplay_plantowatch(media_kind, page_no=1): return _status('PLANNING', media_kind)
def punchplay_completed(media_kind, page_no=1): return _status('WATCHED', media_kind)
def punchplay_collection(media_kind, page_no=1):
    return [r for e in _items(call_punchplay('/me/collection', query={'limit': 200})) if (r := _row(e)) and ((media_kind == 'movie' and r['type']=='movie') or (media_kind != 'movie' and r['type'] in ('show','anime')))]
def _watchlist_id():
    for e in _items(call_punchplay('/me/lists')):
        if e.get('isWatchlist'):
            return e.get('id')
    return None
def punchplay_watchlist(media_kind, page_no=1):
    lid = _watchlist_id()
    if not lid: return punchplay_plantowatch(media_kind, page_no)
    detail = call_punchplay('/lists/%s' % lid)
    rows = []
    for e in _items(detail):
        r = _row(e)
        if r and ((media_kind == 'movie' and r['type']=='movie') or (media_kind != 'movie' and r['type'] in ('show','anime'))): rows.append(r)
    return rows

def punchplay_create_list(name, description=''):
    result = call_punchplay('/lists', 'post', {'name': str(name or 'PunchPlay List')[:100], 'description': str(description or '')[:500], 'isPublic': False}, return_status=True)
    if isinstance(result, tuple) and len(result) >= 3:
        return result[2] if result[0] else None
    return result if isinstance(result, dict) and result else None
def punchplay_get_lists(): return _items(call_punchplay('/me/lists'))
def punchplay_list_items(list_id, media_kind):
    detail = call_punchplay('/lists/%s' % list_id)
    rows = []
    for e in _items(detail):
        r = _row(e)
        if r and ((media_kind == 'movie' and r['type']=='movie') or (media_kind != 'movie' and r['type'] in ('show','anime'))): rows.append(r)
    return rows

def _ids(rows): return {str(r.get('media_ids', {}).get('tmdb')) for r in rows if r.get('media_ids', {}).get('tmdb')}

def _list_item_id(list_id, tmdb_id):
    detail = call_punchplay('/lists/%s' % list_id)
    for e in _items(detail):
        if str(e.get('tmdbId') or e.get('sourceId')) == str(tmdb_id):
            return e.get('id')
    return None

def _write_result(result):
    """Return True only when the HTTP write actually succeeded."""
    if isinstance(result, tuple) and len(result) >= 3:
        return bool(result[0])
    # Legacy callers may still receive a decoded success body.  An empty dict
    # is NOT success: call_punchplay uses {} for HTTP/network failures.
    return isinstance(result, dict) and not result.get('error') and bool(result)

def punchplay_list_add(ctx, list_id):
    result = call_punchplay('/lists/%s/items' % list_id, 'post', _payload(ctx), return_status=True)
    return _write_result(result)

def punchplay_list_remove(ctx, list_id):
    item_id = _list_item_id(list_id, ctx.get('tmdb_id'))
    if not item_id: return True
    result = call_punchplay('/lists/%s/items/%s' % (list_id, item_id), 'delete', return_status=True)
    return _write_result(result)

def _collection_item_id(tmdb_id):
    data = call_punchplay('/me/collection', query={'limit': 200})
    for entry in _items(data):
        if str(entry.get('tmdbId') or entry.get('tmdb_id') or entry.get('sourceId')) == str(tmdb_id):
            return entry.get('id')
    return None

def punchplay_collection_add(ctx):
    # Collection membership has its own item-write endpoint.  POSTing to the
    # collection GET endpoint (/me/collection) returns HTTP 405 on the current
    # PunchPlay Platform API.
    result = call_punchplay('/collection', 'post', _collection_payload(ctx), return_status=True)
    return _write_result(result)

def punchplay_collection_remove(ctx):
    item_id = _collection_item_id(ctx.get('tmdb_id'))
    if not item_id: return True
    result = call_punchplay('/collection/%s' % item_id, 'delete', return_status=True)
    return _write_result(result)

def punchplay_watchlist_ids(media_type, fields=None): return _ids(punchplay_watchlist(media_type, 1))
def _payload(ctx):
    return {'kind': 'movie' if ctx['media_type_raw']=='movie' else 'show', 'sourceId': int(ctx['tmdb_id']), 'title': ctx.get('title') or str(ctx['tmdb_id'])}

def _collection_payload(ctx):
    # Match the known-working PunchPlay collection contract used by
    # TMDbMovies: collection writes live at /collection and require format.
    payload = _payload(ctx)
    payload['format'] = 'digital'
    return payload
def punchplay_watchlist_member(ctx): return str(ctx['tmdb_id']) in punchplay_watchlist_ids(ctx['media_type'], {})
def punchplay_watchlist_add(ctx):
    lid = _watchlist_id()
    if not lid: return False
    result = call_punchplay('/lists/%s/items' % lid, 'post', _payload(ctx), return_status=True)
    return _write_result(result)
def punchplay_watchlist_remove(ctx):
    lid = _watchlist_id()
    if not lid: return False
    detail = call_punchplay('/lists/%s' % lid)
    for e in _items(detail):
        if str(e.get('tmdbId') or e.get('sourceId')) == str(ctx['tmdb_id']):
            item_id = e.get('id')
            if item_id:
                result = call_punchplay('/lists/%s/items/%s' % (lid, item_id), 'delete', return_status=True)
                return _write_result(result)
    return True

def _punchplay_title_year(media_type, tmdb_id, title=None, year=None):
    if title and year: return title, int(year)
    try:
        from modules import metadata
        from modules import metadata
        meta = metadata.tvshow_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), kodi_utils.get_datetime()) if media_type in ('tvshow','episode','season') else metadata.movie_meta('tmdb_id', tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(), kodi_utils.get_datetime())
        return meta.get('title') or title or str(tmdb_id), int(str(meta.get('year') or meta.get('premiered') or year or 0)[:4] or 0)
    except Exception:
        return title or str(tmdb_id), int(year or 0)

def _season_episode_inputs(tmdb_id, season, watched_at=None):
    """Build PunchPlay season-watch episode rows defensively."""
    watched_at = watched_at or time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime())
    try:
        from modules import metadata, settings
        from modules.utils import get_datetime, adjust_premiered_date
        meta = metadata.tvshow_meta(
            'tmdb_id', tmdb_id, settings.tmdb_api_key(), settings.mpaa_region(),
            get_datetime())
        ep_data = metadata.episodes_meta(int(season), meta) or []
        current_date = get_datetime()
        rows = []
        for item in ep_data:
            try:
                ep_num = int(item.get('episode'))
                if ep_num <= 0:
                    continue
                episode_date, _premiered = adjust_premiered_date(
                    item.get('premiered'), settings.date_offset())
                if episode_date and current_date < episode_date:
                    continue
                name = (item.get('title') or item.get('name') or
                        'Episode %s' % ep_num).strip()
                rows.append({
                    'episodeNumber': ep_num,
                    'name': name or 'Episode %s' % ep_num,
                    'watchedAt': watched_at
                })
            except Exception:
                continue
        return rows
    except Exception:
        return []

def punchplay_watched_status_mark(action, media_type, tmdb_id, tvdb_id=0, season=None, episode=None, title=None, year=None):
    if not punchplay_user_active():
        kodi_utils.logger('PunchPlay', 'SEASON DIAG: punchplay_user_active=False; token_state=%s' % ('empty' if _token() in ('', '0', 'empty_setting', None) else 'present'))
        return False
    if media_type == 'season':
        kodi_utils.logger('PunchPlay', 'SEASON DIAG: punchplay_user_active=True; entering season branch')
    try: tid = int(tmdb_id)
    except Exception: return False
    title, year = _punchplay_title_year(media_type, tid, title, year)
    watched_at = time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime())
    kind = 'movie' if media_type == 'movie' else 'show'
    if action == 'mark_as_watched':
        if media_type == 'movie':
            ok, status, body = call_punchplay('/title/%s/%s/history' % (kind, tid), 'post', {'title': title, 'year': year, 'watchedAt': watched_at}, return_status=True)
            if ok:
                # Keep Finder's concrete PunchPlay history-ID mirror current after
                # an ordinary Mark Watched.  Repair seeds the mirror; this small
                # incremental snapshot fetches only entries newer than the largest
                # history ID we already know, avoiding a later 100-page scan.
                try:
                    from caches.base_cache import connect_database, make_database
                    make_database('punchplay_db')
                    dbcon = connect_database('punchplay_db')
                    row = dbcon.execute(
                        "SELECT MAX(CAST(history_id AS INTEGER)) FROM history_entries"
                    ).fetchone()
                    after = int((row or [0])[0] or 0)
                    dbcon.close()
                    ok_s, status_s, snap = call_punchplay(
                        '/me/sync/snapshot', query={'resource': 'history', 'after': after, 'limit': 500}, return_status=True)
                    found = []
                    if ok_s and isinstance(snap, dict):
                        for item in snap.get('items') or []:
                            if not isinstance(item, dict):
                                continue
                            try:
                                item_type = str(item.get('type') or item.get('kind') or '').lower()
                                item_tid = item.get('tmdbId') or item.get('tmdb_id') or item.get('sourceId')
                                if item_type != 'movie' or int(item_tid) != tid:
                                    continue
                                hid = item.get('id') or item.get('historyId') or item.get('watchHistoryId')
                                if hid is not None and str(hid):
                                    found.append((str(hid), 'movie', str(tid), 0, 0,
                                                  str(item.get('watchedAt') or item.get('watched_at') or watched_at)))
                            except Exception:
                                continue
                    if found:
                        dbcon = connect_database('punchplay_db')
                        dbcon.executemany(
                            'INSERT OR REPLACE INTO history_entries VALUES (?, ?, ?, ?, ?, ?)', found)
                        dbcon.close()
                    kodi_utils.logger('PunchPlay',
                                      'mark watched history reconcile: media=movie tmdb=%s after=%s HTTP=%s matches=%s'
                                      % (tid, after, status_s, len(found)))
                except Exception as e:
                    # Mark Watched itself succeeded; reconciliation is an
                    # optimization only.  Existing unwatch history scan remains
                    # the safety fallback if the incremental mirror cannot update.
                    kodi_utils.logger('PunchPlay', 'mark watched history reconcile failed: %s' % e)
            return ok
        if media_type == 'episode' and season is not None and episode is not None:
            payload = {'episodes': [{'episodeNumber': int(episode), 'name': 'Episode %s' % int(episode), 'watchedAt': watched_at}], 'title': title, 'year': year, 'watchedAt': watched_at}
            ok, status, body = call_punchplay('/title/show/%s/season/%s/watch' % (tid, int(season)), 'post', payload, return_status=True)
            return ok
        if media_type == 'season' and season is not None:
            rows = _season_episode_inputs(tid, season, watched_at=watched_at)
            kodi_utils.logger('PunchPlay', 'SEASON DIAG: _season_episode_inputs returned %s row(s)' % len(rows))
            if not rows:
                kodi_utils.logger('PunchPlay', 'SEASON DIAG: returning False because episode rows are empty')
                return False
            ok, status, body = call_punchplay(
                '/title/show/%s/season/%s/watch' % (tid, int(season)),
                'post',
                {'episodes': rows, 'title': title, 'year': year, 'watchedAt': watched_at},
                return_status=True)
            return ok
        return False
    # Unwatch by concrete history-entry ID after traversing the complete
    # cursor-paginated PunchPlay history. This works for movies, individual
    # episodes, seasons, and (via the caller) complete shows.
    def _history_matches():
        # Fast path: Repair/full sync stores concrete PunchPlay history IDs in
        # Finder's local punchplay.db. Normal context actions use those IDs
        # instead of traversing the user's complete remote history.
        try:
            from caches.base_cache import connect_database
            dbcon = connect_database('punchplay_db')
            if media_type == 'movie':
                rows = dbcon.execute(
                    "SELECT history_id FROM history_entries WHERE db_type=? AND media_id=? AND season=0 AND episode=0",
                    ('movie', str(tid))).fetchall()
            elif media_type == 'episode':
                rows = dbcon.execute(
                    "SELECT history_id FROM history_entries WHERE db_type=? AND media_id=? AND season=? AND episode=?",
                    ('episode', str(tid), int(season), int(episode))).fetchall()
            elif media_type == 'season':
                rows = dbcon.execute(
                    "SELECT history_id FROM history_entries WHERE db_type=? AND media_id=? AND season=?",
                    ('episode', str(tid), int(season))).fetchall()
            else:
                rows = dbcon.execute(
                    "SELECT history_id FROM history_entries WHERE db_type=? AND media_id=?",
                    ('episode', str(tid))).fetchall()
            dbcon.close()
            local_ids = list(dict.fromkeys(str(r[0]) for r in rows if r and r[0] is not None))
            if local_ids:
                kodi_utils.logger('PunchPlay',
                                  'unwatch history lookup: local index media=%s tmdb=%s matches=%s'
                                  % (media_type, tid, len(local_ids)))
                return True, local_ids, 0
        except Exception as e:
            kodi_utils.logger('PunchPlay', 'unwatch local history index unavailable: %s' % e)

        # Safety fallback for a pre-1.0.18 database or incomplete local mirror.
        matches = []
        cursor = None
        seen_cursors = set()
        pages = 0
        for page in range(1, 101):
            query = {'limit': 100}
            if cursor:
                query['cursor'] = cursor
            ok_h, status_h, body_h = call_punchplay('/me/history', query=query, return_status=True)
            pages = page
            if not ok_h:
                kodi_utils.logger('PunchPlay', 'unwatch history read failed: page=%s HTTP=%s' % (page, status_h))
                return False, [], pages
            batch = _items(body_h)
            for item in batch:
                if not isinstance(item, dict):
                    continue
                try:
                    item_type = str(item.get('type') or item.get('kind') or '').lower()
                    if media_type == 'movie':
                        if item_type != 'movie':
                            continue
                        item_tid = item.get('tmdbId') or item.get('tmdb_id') or item.get('sourceId')
                        if int(item_tid) != tid:
                            continue
                    else:
                        if item_type not in ('episode', 'tv_episode'):
                            continue
                        item_tid = (item.get('showTmdbId') or item.get('show_tmdb_id') or
                                    item.get('tmdbId') or item.get('tmdb_id') or item.get('sourceId'))
                        if int(item_tid) != tid:
                            continue
                        item_season = int(item.get('season') or 0)
                        item_episode = int(item.get('episode') or 0)
                        if media_type == 'episode':
                            if item_season != int(season) or item_episode != int(episode):
                                continue
                        elif media_type == 'season':
                            if item_season != int(season):
                                continue
                    hid = item.get('id') or item.get('historyId') or item.get('watchHistoryId')
                    if hid is not None and str(hid):
                        matches.append(str(hid))
                except Exception:
                    continue
            next_cursor = None
            if isinstance(body_h, dict):
                next_cursor = body_h.get('nextCursor') or body_h.get('next_cursor')
            if next_cursor and str(next_cursor) not in seen_cursors:
                seen_cursors.add(str(next_cursor))
                cursor = str(next_cursor)
                continue
            break
        return True, list(dict.fromkeys(matches)), pages

    ok_h, history_ids, pages = _history_matches()
    kodi_utils.logger('PunchPlay',
                      'unwatch history scan: media=%s tmdb=%s season=%s episode=%s pages=%s matches=%s'
                      % (media_type, tid, season, episode, pages, len(history_ids)))
    if not ok_h:
        return False
    if not history_ids:
        return True
    ok_all = True
    deleted_ids = []
    for hid in history_ids:
        ok_d, status_d, body_d = call_punchplay('/watch-history/%s' % hid, 'delete', return_status=True)
        kodi_utils.logger('PunchPlay',
                          'unwatch history delete: id=%s HTTP=%s ok=%s' % (hid, status_d, ok_d))
        if ok_d or status_d == 404:
            deleted_ids.append(str(hid))
        else:
            ok_all = False
    if deleted_ids:
        try:
            from caches.base_cache import connect_database
            dbcon = connect_database('punchplay_db')
            dbcon.executemany('DELETE FROM history_entries WHERE history_id=?', [(i,) for i in deleted_ids])
            dbcon.close()
        except Exception as e:
            kodi_utils.logger('PunchPlay', 'local history index cleanup failed: %s' % e)
    return ok_all

def clear_database(dummy=None):
	from caches.punchplay_cache import clear_and_rebuild
	return clear_and_rebuild()

def punchplay_test_client_id():
    """Validate the configured Client ID against PunchPlay without starting OAuth."""
    client = punchplay_client()
    if not client:
        return False, 'PunchPlay Client ID Key is not set.'
    try:
        r = requests.post(
            _url('/auth/device/code'),
            json={'client_id': client, 'scope': DEFAULT_SCOPES},
            headers=_headers(False), timeout=TIMEOUT_STANDARD)
        body = {}
        try: body = r.json() or {}
        except Exception: pass
        if r.status_code == 200 and body.get('device_code'):
            return True, 'PunchPlay Client ID Key accepted.'
        detail = body.get('error_description') or body.get('message') or body.get('error') or (r.text or '').strip()
        kodi_utils.logger('PunchPlay', 'client probe HTTP %s: %s' % (r.status_code, detail or 'no response detail'))
        return False, 'PunchPlay Client ID Key rejected (HTTP %s).\n%s' % (r.status_code, detail or 'No details returned.')
    except Exception as e:
        kodi_utils.logger('PunchPlay', 'client probe exception: %s' % e)
        return False, 'Could not reach PunchPlay.\n%s' % e

def punchplay_test_client_id_dialog(dummy=''):
    ok, message = punchplay_test_client_id()
    return kodi_utils.ok_dialog('PunchPlay', message)

def punchplay_check_authentication_dialog(dummy=''):
    token = _token()
    if token in ('', '0', 'empty_setting', None):
        return kodi_utils.ok_dialog('PunchPlay', 'Finder does not currently have a PunchPlay access token. Please Authorize PunchPlay first.')
    try:
        if not _fresh():
            kodi_utils.logger('PunchPlay', 'settings check: access token expired; attempting refresh')
            if not _ensure_token():
                return kodi_utils.ok_dialog('PunchPlay', 'PunchPlay token is expired and could not be refreshed. Please Authorize PunchPlay again.')
        me = call_punchplay('/me', method='get') or {}
        if me:
            username = (me.get('username') or me.get('name') or
                        (me.get('user') or {}).get('username') or 'PunchPlay User') if isinstance(me, dict) else 'PunchPlay User'
            set_setting('punchplay.user', str(username))
            kodi_utils.logger('PunchPlay', 'authentication check: /me succeeded')
            return kodi_utils.ok_dialog('PunchPlay', 'PunchPlay authentication is active.\n\nAccount: %s' % username)
        kodi_utils.logger('PunchPlay', 'authentication check: /me returned no data')
        return kodi_utils.ok_dialog('PunchPlay', 'PunchPlay access token is present, but the account check returned no data. See the Kodi log for details.')
    except Exception as e:
        kodi_utils.logger('PunchPlay', 'authentication check: %s' % e)
        return kodi_utils.ok_dialog('PunchPlay', 'PunchPlay authentication check failed. See the Kodi log for details.')

def punchplay_authenticate(dummy=''):
    client = punchplay_client()
    if not client: return kodi_utils.ok_dialog('PunchPlay', 'Enter your PunchPlay Client ID Key in Finder settings first.')
    try:
        r = requests.post(_url('/auth/device/code'), data=json.dumps({'client_id': client, 'scope': DEFAULT_SCOPES}), headers=_headers(False), timeout=TIMEOUT_STANDARD)
        data = r.json() if r.status_code == 200 else {}
    except Exception as e:
        kodi_utils.logger('PunchPlay', 'device/code: %s' % e); data = {}
    if not data.get('device_code'):
        ok, message = punchplay_test_client_id()
        return kodi_utils.ok_dialog('PunchPlay', message)
    code, device = data.get('user_code',''), data.get('device_code')
    url = data.get('verification_uri_complete') or data.get('verification_url') or ('https://punchplay.tv/link?code=%s' % code)
    try: copy2clip(url)
    except: pass
    qr = make_qrcode(url) or ''
    progress = kodi_utils.progress_dialog('PunchPlay Authorize', qr)
    start, expires, interval = time.time(), int(data.get('expires_in') or 600), int(data.get('interval') or 5)
    content = 'Enter [B]%s[/B] at [B]%s[/B] or scan the QR code.' % (code, data.get('verification_url') or 'https://punchplay.tv/link')
    progress.update(content, 0)
    token = None
    try:
        while time.time() - start < expires and not progress.iscanceled():
            time.sleep(max(interval, 1))
            r = requests.post(_url('/auth/device/token'), data=json.dumps({'client_id': client, 'device_code': device, 'device_id': _device_id(), 'device_name': kodi_utils.get_infolabel('System.FriendlyName') or 'Kodi'}), headers=_headers(False), timeout=TIMEOUT_STANDARD)
            if r.status_code == 200 and (r.json() or {}).get('access_token'):
                token = r.json(); break
            progress.update(content, int(min(99, 100*(time.time()-start)/expires)))
    finally:
        try: progress.close()
        except: pass
    if not token or not _save_tokens(token): return kodi_utils.notification('PunchPlay Authorisation Failed', 3000)
    me = call_punchplay('/me') or {}
    username = (me.get('username') or me.get('name') or
                (me.get('user') or {}).get('username') or 'PunchPlay User') if isinstance(me, dict) else 'PunchPlay User'
    set_setting('punchplay.user', str(username))
    kodi_utils.logger('PunchPlay', 'post-auth /me result: %s' % ('authenticated' if me else 'unavailable; token retained'))
    kodi_utils.notification('PunchPlay Account Authorised', 3000)
    kodi_utils.container_refresh()
    return True

def punchplay_revoke_authentication(dummy=''):
    set_setting('punchplay.user', 'empty_setting'); set_setting('punchplay.token', '0'); set_setting('punchplay.refresh', '0'); set_setting('punchplay.expires', '0')
    kodi_utils.notification('PunchPlay Authorisation Reset', 3000); kodi_utils.container_refresh(); return True
