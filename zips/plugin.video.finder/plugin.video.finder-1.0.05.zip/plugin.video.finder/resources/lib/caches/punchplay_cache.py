# -*- coding: utf-8 -*-
"""PunchPlay watched-state database maintenance.

PunchPlay is a persistent watched-state provider, not a TTL cache. Its local
mirror therefore has its own maintenance path and can be rebuilt from the
PunchPlay history endpoint without touching the other Finder databases.
"""
import sqlite3

from caches.base_cache import connect_database
from modules import kodi_utils

logger = kodi_utils.logger


def _items(data):
	if isinstance(data, list):
		return data
	if not isinstance(data, dict):
		return []
	for key in ("items", "results", "data"):
		value = data.get(key)
		if isinstance(value, list):
			return value
		if isinstance(value, dict) and isinstance(value.get("items"), list):
			return value["items"]
	return []


def _history_page(page=1, cursor=None, limit=100):
	from apis.punchplay_api import call_punchplay
	# Match the production-compatible RedLight implementation: /me/history
	# uses cursor pagination with a limit of 100. Do not fall back to the
	# obsolete page/pageSize form, which currently returns HTTP 400.
	query = {"limit": limit}
	if cursor:
		query["cursor"] = cursor
	ok, status, body = call_punchplay("/me/history", query=query, return_status=True)
	if not ok or not (200 <= int(status or 0) < 300):
		return False, [], {}, status
	return True, _items(body), body if isinstance(body, dict) else {}, status


def _collect_history():
	items = []
	cursor = None
	seen_cursors = set()
	for page in range(1, 101):
		ok, batch, body, status = _history_page(page=page, cursor=cursor)
		if not ok:
			logger("PunchPlay DB", "history read failed HTTP %s" % status)
			return False, []
		items.extend([i for i in batch if isinstance(i, dict)])
		logger("PunchPlay DB", "history page=%s items=%s cursor=%s" % (page, len(batch), "yes" if cursor else "no"))
		if not body:
			break
		next_cursor = (body.get("nextCursor") or body.get("next_cursor") or
						body.get("cursor"))
		if next_cursor and str(next_cursor) not in seen_cursors:
			seen_cursors.add(str(next_cursor))
			cursor = str(next_cursor)
			continue
		if not batch or len(batch) < 100:
			break
		# Fallback for page-based history endpoints.
		cursor = None
	return True, items


def _parse_history(items):
	movies = {}
	episodes = {}
	history_entries = []
	for item in items:
		try:
			kind = str(item.get("type") or item.get("kind") or "").lower()
			watched_at = str(item.get("watchedAt") or item.get("watched_at") or "")
			title = str(item.get("title") or item.get("name") or "")
			if kind == "movie":
				tid_value = item.get("tmdbId") or item.get("tmdb_id") or item.get("sourceId")
				id_value = str(int(tid_value))
				movies[id_value] = ("movie", id_value, 0, 0, watched_at, title)
				hid = item.get("id") or item.get("historyId") or item.get("watchHistoryId")
				if hid is not None and str(hid):
					history_entries.append((str(hid), "movie", id_value, 0, 0, watched_at))
			elif kind in ("episode", "tv_episode"):
				id_value = item.get("showTmdbId") or item.get("show_tmdb_id") or item.get("tmdbId") or item.get("tmdb_id") or item.get("sourceId")
				s = int(item.get("season") or 0)
				e = int(item.get("episode") or 0)
				if int(id_value) <= 0 or s <= 0 or e <= 0:
					continue
				key = (str(int(id_value)), s, e)
				row = ("episode", key[0], s, e, watched_at, title)
				old = episodes.get(key)
				if old is None or watched_at >= old[4]:
					episodes[key] = row
				hid = item.get("id") or item.get("historyId") or item.get("watchHistoryId")
				if hid is not None and str(hid):
					history_entries.append((str(hid), "episode", key[0], s, e, watched_at))
		except Exception:
			continue
	return list(movies.values()), list(episodes.values()), history_entries


def rebuild_from_server(silent=False):
	"""Rebuild only Finder's PunchPlay watched mirror from PunchPlay history.

	The local database is never emptied unless a successful server history read
	completed first. This prevents an authentication/network failure from turning
	a temporary API problem into permanent local data loss.
	"""
	try:
		from apis.punchplay_api import punchplay_user_active
		if not punchplay_user_active():
			if not silent:
				kodi_utils.notification("PunchPlay is not authenticated", time=4000)
			return False
		ok, history = _collect_history()
		if not ok:
			if not silent:
				kodi_utils.notification("PunchPlay history could not be read", time=5000)
			return False
		movies, episodes, history_entries = _parse_history(history)
		from caches.base_cache import make_database
		make_database("punchplay_db")
		dbcon = connect_database("punchplay_db")
		try:
			dbcon.execute("BEGIN")
			dbcon.execute("DELETE FROM watched")
			dbcon.execute("DELETE FROM progress")
			dbcon.execute("DELETE FROM watched_status")
			dbcon.execute("DELETE FROM history_entries")
			rows = movies + episodes
			if rows:
				dbcon.executemany(
					"INSERT OR REPLACE INTO watched VALUES (?, ?, ?, ?, ?, ?)", rows
				)
			if history_entries:
				dbcon.executemany(
					"INSERT OR REPLACE INTO history_entries VALUES (?, ?, ?, ?, ?, ?)", history_entries
				)
			dbcon.execute("COMMIT")
		except Exception:
			try:
				dbcon.execute("ROLLBACK")
			except Exception:
				pass
			raise
		finally:
			dbcon.close()
		logger("PunchPlay DB", "Rebuilt from server history: %s movies, %s episodes, %s history IDs" % (len(movies), len(episodes), len(history_entries)))
		if not silent:
			kodi_utils.notification("PunchPlay database rebuilt: %s movies, %s episodes" % (len(movies), len(episodes)), time=5000)
		try:
			from modules.watched_status import refresh_after_action
			refresh_after_action(refresh_when_internal=True)
		except Exception:
			pass
		return True
	except sqlite3.Error as e:
		logger("PunchPlay DB rebuild error", str(e))
		if not silent:
			kodi_utils.notification("PunchPlay database rebuild failed", time=5000)
		return False
	except Exception as e:
		logger("PunchPlay DB rebuild error", str(e))
		if not silent:
			kodi_utils.notification("PunchPlay database rebuild failed", time=5000)
		return False


def clear_and_rebuild(silent=False):
	"""Provider-specific maintenance action: rebuild PunchPlay local state."""
	import xbmcgui
	window = xbmcgui.Window(10000)
	lock_key = "finder.punchplay.repair_running"
	if window.getProperty(lock_key) == "1":
		if not silent:
			kodi_utils.notification("PunchPlay watched database repair is already in progress", time=4000)
		return False
	if not silent and not kodi_utils.confirm_dialog():
		return False
	window.setProperty(lock_key, "1")
	try:
		if not silent:
			kodi_utils.notification("PunchPlay watched database repair in progress...", time=5000)
		return rebuild_from_server(silent=silent)
	finally:
		window.clearProperty(lock_key)
