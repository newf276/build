# -*- coding: utf-8 -*-
import sys

from modules.interface_setup import ensure_mode
from modules.router import routing, sys_exit_check


# Finder owns the interface choice. The Finder Skin remains optional and is
# never touched when Standalone mode is selected.
params = {}
try:
	from urllib.parse import parse_qsl
	params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))
except Exception:
	pass

mode = params.get("mode", "navigator.main")
if mode not in ("interface.setup",):
	if ensure_mode() is None:
		sys.exit(0)


routing(sys)
if sys_exit_check():
	sys.exit(1)
