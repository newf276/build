# Adapted from Angelitto's TMDbMovies 1.1.308 ExtendedInfo component.
# Finder-specific service integration: extended_info_adapter.py.
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import json
import requests
import sys
import os
import html
import threading
import random
import time
from urllib.parse import urlencode, quote
from datetime import datetime, date
from modules import kodi_utils, settings
from caches.main_cache import main_cache
from windows import extended_info_adapter as adapter
ADDON = xbmcaddon.Addon('plugin.video.finder')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
IMG_BASE = 'https://image.tmdb.org/t/p/w500'
BACKDROP_BASE = 'https://image.tmdb.org/t/p/w1280'
IMG_FULL = 'https://image.tmdb.org/t/p/w1280'
IMG_THUMB_SMALL = 'https://image.tmdb.org/t/p/w342'
XML_VIDEO_INFO = 'finder_extended_info.xml'
XML_ACTOR_INFO = 'finder_extended_actor.xml'
watched_provider = adapter.watched_provider
trakt_sync = adapter.tv_meta_cache

class ExtendedDialog(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self._closed = False
        super().__init__(*args)

    def close(self):
        self._closed = True
        super().close()

    def getControl(self, control_id):
        if self._closed:
            raise RuntimeError('ExtendedInfo window closed')
        return super().getControl(control_id)

    def setProperty(self, key, value):
        if not self._closed:
            return super().setProperty(key, value)
ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_LEFT = 1
ACTION_RIGHT = 2
ACTION_UP = 3
ACTION_DOWN = 4
ACTION_SELECT = 7
ACTION_MOUSE_LEFT_CLICK = 100
NAVIGATION_STACK = []

def log(msg):
    xbmc.log(f'[Finder ExtendedInfo] {msg}', level=xbmc.LOGINFO)

def action_play_dialog(tmdb_id, media_type, season=None, episode=None, title=''):
    return adapter.play(tmdb_id, media_type, season, episode, title)

def action_options_dialog(tmdb_id, media_type, season=None, episode=None, title=''):
    return adapter.options(tmdb_id, media_type, season, episode, title)

def action_refresh_trakt():
    return adapter.sync()

def get_tmdb_data(endpoint, params=None):
    return adapter.tmdb_data(endpoint, params)

def get_youtube_api_data(query):
    return []
_YT_IOS_UA = 'com.google.ios.youtube/20.20.7 (iPhone16,2; U; CPU iOS 18_5_0 like Mac OS X)'
_YT_SEARCH_CACHE = {}
_YT_SEARCH_TTL = 604800

def _yt_cache_get(query):
    try:
        hit = _YT_SEARCH_CACHE.get(query)
        if hit and time.time() - hit[0] < _YT_SEARCH_TTL:
            return hit[1]
    except:
        pass
    try:
        from caches.main_cache import main_cache
        data = main_cache.get('ytsearch_' + query)
        if data:
            try:
                _YT_SEARCH_CACHE[query] = (time.time(), data)
            except:
                pass
            return data
    except:
        pass
    return None

def _yt_cache_set(query, items):
    try:
        if len(_YT_SEARCH_CACHE) >= 64:
            _YT_SEARCH_CACHE.pop(next(iter(_YT_SEARCH_CACHE)))
        _YT_SEARCH_CACHE[query] = (time.time(), items)
    except:
        pass
    try:
        from caches.main_cache import main_cache
        main_cache.set('ytsearch_' + query, items, expiration=168)
    except:
        pass

def search_youtube_innertube(query, max_results=25):
    if not query:
        return []
    try:
        cpn = ''.join((random.choice('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_') for _ in range(16)))
        payload = {'context': {'client': {'clientName': 'IOS', 'clientVersion': '20.20.7', 'deviceMake': 'Apple', 'deviceModel': 'iPhone16,2', 'osName': 'iOS', 'osVersion': '18.5.0.22F76', 'platform': 'MOBILE', 'hl': 'en', 'gl': 'US'}}, 'cpn': cpn, 'query': query}
        headers = {'Origin': 'https://m.youtube.com', 'User-Agent': _YT_IOS_UA, 'X-YouTube-Client-Name': '5', 'X-YouTube-Client-Version': '20.20.7', 'Content-Type': 'application/json'}
        r = requests.post('https://www.youtube.com/youtubei/v1/search?prettyPrint=false', data=json.dumps(payload), headers=headers, timeout=15)
        body = r.json()
    except Exception as e:
        log(f'Innertube search error: {e}')
        return []
    out = []
    seen_ids = set()

    def push(info):
        vid = (info.get('id') or '').strip()
        if vid in seen_ids or not vid:
            return
        seen_ids.add(vid)
        info['id'] = vid
        info['title'] = (info.get('title') or '').strip()
        out.append(info)
        return len(out) >= max_results

    def walk(node, cur=None):
        if len(out) >= max_results:
            return True
        if isinstance(node, dict):
            vr = node.get('videoRenderer')
            if isinstance(vr, dict):
                runs = (vr.get('title') or {}).get('runs') or []
                t = ''.join((x.get('text', '') for x in runs)) if runs else (vr.get('title') or {}).get('simpleText') or ''
                if push({'id': vr.get('videoId') or '', 'title': t}):
                    return True
            cvm_title = ''
            try:
                vd = (node.get('compactVideoModel') or {}).get('compactVideoData', {}).get('videoData', {})
                if isinstance(vd, dict) and vd.get('dragAndDropUrl'):
                    durl = vd.get('dragAndDropUrl') or ''
                    vid = durl.split('watch?v=')[1].split('&')[0].split('#')[0] if 'watch?v=' in durl else ''
                    md = vd.get('metadata') or {}
                    vt = md.get('title') or ''
                    if isinstance(vt, dict):
                        runs = vt.get('runs') or []
                        vt = ''.join((x.get('text', '') for x in runs)) if runs else vt.get('simpleText') or ''
                    det = md.get('metadataDetails') or ''
                    if isinstance(det, dict):
                        runs = det.get('runs') or []
                        det = ''.join((x.get('text', '') for x in runs)) if runs else det.get('simpleText') or ''
                    views = ''
                    published = ''
                    if det and '·' in det:
                        views, published = [x.strip() for x in det.split('·', 1)]
                    th = vd.get('thumbnail') or {}
                    srcs = th.get('image', {}).get('sources') or []
                    thumb = srcs[0].get('url') if srcs else ''
                    cvm_title = vt if isinstance(vt, str) else ''
                    if push({'id': vid, 'title': vt, 'channel': md.get('byline') or '', 'views_text': det, 'views': views, 'published': published, 'duration': th.get('timestampText') or '', 'thumb': thumb}):
                        return True
            except Exception:
                pass
            try:
                vd = (node.get('videoWithContextData') or {}).get('videoData') or {}
                durl = vd.get('dragAndDropUrl') or ''
                vid = durl.split('watch?v=')[1].split('&')[0].split('#')[0] if 'watch?v=' in durl else ''
                if vid and len(vid) == 11:
                    t = ''
                    try:
                        t = vd['lockupMetadata']['lockupMetadataViewModel']['title']['content'] or ''
                    except Exception:
                        pass
                    ts = None
                    try:
                        ts = (vd.get('thumbnail') or {}).get('timestampText')
                    except Exception:
                        ts = None
                    if push({'id': vid, 'title': t, 'duration': ts or ''}):
                        return True
            except Exception:
                pass
            cvm = node.get('compactVideoModel')
            if isinstance(cvm, dict):
                try:
                    cur_title = cvm['compactVideoData']['videoData']['metadata']['title']
                except Exception:
                    cur_title = ''
            else:
                cur_title = (cur or {}).get('title', '')
            w = node.get('watchEndpoint')
            if isinstance(w, dict) and w.get('videoId'):
                if push({'id': w['videoId'], 'title': cur_title or ''}):
                    return True
            for v in node.values():
                if walk(v, cur):
                    return True
        elif isinstance(node, list):
            for v in node:
                if walk(v, cur):
                    return True
        return False
    try:
        contents = body['contents']['sectionListRenderer']['contents']
    except Exception:
        contents = None
    if contents is None:
        try:
            contents = body['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
        except Exception:
            contents = []
    try:
        for sec in contents:
            if walk(sec):
                break
    except Exception as e:
        log(f'Innertube search parse error: {e}')
    return out



def get_youtube_search_results(query, max_results=25):
    if not query:
        return []
    cached = _yt_cache_get(query)
    if cached is not None:
        return cached
    found = search_youtube_innertube(query, max_results)
    if found:
        log(f'Innertube search OK: {len(found)} videos.')
        items = [{'id': {'videoId': d.get('id')}, 'snippet': {'title': d.get('title', ''), 'channelTitle': d.get('channel', ''), 'thumbnails': {'high': {'url': d.get('thumb') or 'https://img.youtube.com/vi/' + d.get('id', '') + '/mqdefault.jpg'}}, 'publishedAt': ''}} for d in found]
        _yt_cache_set(query, items)
        return items
    items = get_youtube_api_data(query)
    if items:
        _yt_cache_set(query, items)
    return items



def format_money(val):
    if not val:
        return ''
    try:
        return f'{int(val):,}'
    except:
        return str(val)

def format_money_short(val):
    """Formateaza banii scurt: 1 Mil, 2 Bil (Fara zecimale)"""
    if not val:
        return ''
    try:
        val = float(val)
        if val >= 1000000000:
            return f'{val / 1000000000:.0f} Bil'
        elif val >= 1000000:
            return f'{val / 1000000:.0f} Mil'
        else:
            return f'{val:,.0f}'
    except:
        return str(val)

def format_date(date_str):
    if not date_str:
        return ''
    try:
        from windows.extended_info import _fmt_dmy
        return _fmt_dmy(date_str)
    except:
        return date_str

def format_date_short(date_str):
    if not date_str:
        return ''
    try:
        from windows.extended_info import _fmt_dmy
        return _fmt_dmy(date_str)
    except:
        return date_str

def calculate_age(birthday_str, deathday_str=None):
    if not birthday_str:
        return ''
    import time
    import xbmc
    try:
        parts = str(birthday_str).strip().split('-')
        if len(parts) != 3:
            return ''
        b_year = int(parts[0])
        b_month = int(parts[1])
        b_day = int(parts[2])
        if deathday_str and str(deathday_str).strip():
            d_parts = str(deathday_str).strip().split('-')
            if len(d_parts) == 3:
                now_year = int(d_parts[0])
                now_month = int(d_parts[1])
                now_day = int(d_parts[2])
            else:
                t = time.localtime()
                now_year, now_month, now_day = (t.tm_year, t.tm_mon, t.tm_mday)
        else:
            t = time.localtime()
            now_year, now_month, now_day = (t.tm_year, t.tm_mon, t.tm_mday)
        age = now_year - b_year
        if (now_month, now_day) < (b_month, b_day):
            age -= 1
        return str(age)
    except Exception as e:
        xbmc.log(f'[Finder ExtendedInfo] Manual Age Calc Error: {e}', level=xbmc.LOGINFO)
        return ''

def get_kodi_library_movies():
    return adapter.library('movie')

def get_kodi_library_tvshows():
    return adapter.library('tv')

def show_text_dialog(heading, text):
    dialog = xbmcgui.Dialog()
    dialog.textviewer(heading, text)

def control_exists(window, control_id):
    try:
        window.getControl(control_id)
        return True
    except:
        return False

def create_list_item_with_year(label, year_str, icon, media_type='video'):
    li = xbmcgui.ListItem(f'[B]{label}[/B]')
    li.setArt({'thumb': icon, 'poster': icon, 'icon': icon})
    if year_str:
        li.setProperty('Year', f'[B]{year_str}[/B]')
        li.setProperty('year', f'[B]{year_str}[/B]')
        li.setLabel2(f'[B]{year_str}[/B]')
        try:
            year_int = int(year_str)
            video_info = li.getVideoInfoTag()
            video_info.setYear(year_int)
        except:
            pass
    return li

class SlideShow(ExtendedDialog):

    def __init__(self, *args, **kwargs):
        super(SlideShow, self).__init__(*args)
        self.images = kwargs.get('images', [])
        self.index = kwargs.get('index', 0)
        self.list_id = 10001

    def onInit(self):
        try:
            ctl = self.getControl(self.list_id)
            items = []
            for img_url in self.images:
                li = xbmcgui.ListItem(path=img_url)
                li.setProperty('Original', img_url)
                items.append(li)
            ctl.addItems(items)
            ctl.selectItem(self.index)
            self.setFocusId(self.list_id)
        except Exception as e:
            log(f'SlideShow Init Error: {e}')
            self.close()

    def onAction(self, action):
        if action.getId() in [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK]:
            self.close()

def show_full_image(window, list_id):
    try:
        ctl = window.getControl(list_id)
        size = ctl.size()
        if size == 0:
            return
        images = []
        for i in range(size):
            url = ctl.getListItem(i).getProperty('image_url')
            if url:
                images.append(url)
        if not images:
            return
        idx = ctl.getSelectedPosition()
        if idx < 0:
            idx = 0
        ss = SlideShow('finder_extended_slideshow.xml', ADDON_PATH, 'Default', '1080i', images=images, index=idx)
        ss.doModal()
        del ss
    except Exception as e:
        log(f'ShowImage Error: {e}')

class SeasonInfo(ExtendedDialog):
    """Pagina pentru informatii despre un sezon"""

    def __init__(self, *args, **kwargs):
        super(SeasonInfo, self).__init__(*args)
        self.tv_id = kwargs.get('tv_id')
        self.season_num = kwargs.get('season_num')
        self.tv_name = kwargs.get('tv_name', '')
        self.title_text = self.tv_name
        self.meta = {}
        self.episodes = []
        self.go_back = False
        self.next_info = None
        self.poster_urls = []
        self.still_urls = []
        self.showing_text_dialog = False
        self.plot_text = ''
        bg_fallback = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'extendedinfo', 'texture.png')
        self.setProperty('fanart', bg_fallback)
        self.setProperty('movie.ImageFilter', bg_fallback)
        self.setProperty('ImageFilter', bg_fallback)

    def onInit(self):
        self.setProperty('type', 'Season')
        self.meta = get_tmdb_data(f'tv/{self.tv_id}/season/{self.season_num}', {'append_to_response': 'credits,images,videos', 'include_video_language': 'en,null'})
        if not self.meta or self.meta.get('success') == False:
            log(f'[SeasonInfo] Season {self.season_num} not found, falling back to TV show')
            self.close()
            try:
                from windows.extended_info import run_extended_info
                xbmc.sleep(100)
                run_extended_info(self.tv_id, 'tv', season=None, episode=None, tv_name=self.tv_name)
            except Exception as e:
                log(f'[SeasonInfo] Fallback error: {e}')
            return
        tv_meta = get_tmdb_data(f'tv/{self.tv_id}/content_ratings')
        self.tv_mpaa = ''
        if tv_meta and 'results' in tv_meta:
            for r in tv_meta['results']:
                if r['iso_3166_1'] == settings.mpaa_region():
                    self.tv_mpaa = r['rating']
                    break
        self.episodes = self.meta.get('episodes', [])
        self.update_ui()

    def load_youtube_async(self):
        if self._closed:
            return
        videos = [v for v in self.meta.get('videos', {}).get('results', []) if v.get('site') == 'YouTube' and v.get('key')]
        self.fill_video_list(1150, videos)
        if self._closed:
            return
        found = get_youtube_search_results(self.title_text + ' trailer', max_results=12)
        if self._closed:
            return
        official_keys = {v['key'] for v in videos}
        secondary = []
        for item in found:
            key = item.get('id', {}).get('videoId')
            if not key or key in official_keys:
                continue
            snippet = item.get('snippet', {})
            secondary.append({'name': html.unescape(snippet.get('title', 'Video')), 'key': key, 'type': 'Video', 'official': False, 'thumb': snippet.get('thumbnails', {}).get('high', {}).get('url', ''), 'published_at': snippet.get('publishedAt', '')})
        self.fill_video_list(350, secondary)

    def update_ui(self):
        season_name = (self.meta.get('name') if settings.use_season_name() else None) or f'Season {self.season_num}'
        self.plot_text = self.meta.get('overview', '') or f'Season {self.season_num} of {self.tv_name}'
        air_date = self.meta.get('air_date', '')
        air_date_formatted = format_date_short(air_date)
        year = air_date[:4] if air_date else ''
        poster = IMG_BASE + self.meta.get('poster_path', '') if self.meta.get('poster_path') else ''
        ep_count = len(self.episodes)
        if self.tv_name:
            full_title = f'{self.tv_name} - {season_name}'
        else:
            full_title = season_name
        self.title_text = self.tv_name if self.tv_name else season_name
        self.setProperty('movie.title', full_title)
        self.setProperty('movie.Title', full_title)
        self.setProperty('title', full_title)
        self.setProperty('movie.originaltitle', season_name)
        self.setProperty('movie.Premiered', air_date_formatted)
        self.setProperty('movie.release_date', air_date_formatted)
        self.setProperty('movie.ReleaseDate', air_date_formatted)
        self.setProperty('Premiered', air_date_formatted)
        self.setProperty('ReleaseDate', air_date_formatted)
        self.setProperty('Date', air_date_formatted)
        self.setProperty('movie.year', year)
        self.setProperty('movie.Year', year)
        self.setProperty('year', year)
        self.setProperty('Status', '')
        self.setProperty('movie.Status', '')
        if hasattr(self, 'tv_mpaa') and self.tv_mpaa:
            self.setProperty('movie.mpaa', self.tv_mpaa)
        self.setProperty('movie.Studio', air_date_formatted)
        self.setProperty('Studio', air_date_formatted)
        self.setProperty('TotalEpisodes', str(ep_count))
        self.setProperty('episode_count', str(ep_count))
        self.setProperty('movie.duration', '')
        self.setProperty('duration', '')
        self.setProperty('Tagline', f'{ep_count} Episodes')
        self.setProperty('movie.Tagline', f'{ep_count} Episodes')
        self.setProperty('movie.plot', self.plot_text)
        self.setProperty('movie.Plot', self.plot_text)
        self.setProperty('plot', self.plot_text)
        self.setProperty('movie.poster', poster)
        self.setProperty('poster', poster)
        if self.episodes and self.episodes[0].get('still_path'):
            fanart = BACKDROP_BASE + self.episodes[0]['still_path']
            self.setProperty('movie.fanart', fanart)
            self.setProperty('fanart', fanart)
        texture_path = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'extendedinfo', 'texture.png')
        self.setProperty('movie.ImageFilter', texture_path)
        self.setProperty('ImageFilter', texture_path)
        if self.episodes:
            avg_rating = sum((e.get('vote_average', 0) for e in self.episodes)) / len(self.episodes)
            self.setProperty('movie.rating', f'{avg_rating:.1f}')
            self.setProperty('movie.Rating', f'{avg_rating:.1f}')
        self.setProperty('PlayButtonLabel', 'Browse Episodes')
        self.fill_episode_list(2000, self.episodes)
        t = threading.Thread(target=self.load_youtube_async)
        t.daemon = True
        t.start()
        cast = self.meta.get('credits', {}).get('cast', [])[:20]
        self.fill_cast_list(1000, cast)
        posters = self.meta.get('images', {}).get('posters', [])
        self.poster_urls = [IMG_FULL + p['file_path'] for p in posters if p.get('file_path')]
        self.fill_image_list(1250, posters, 'poster')
        stills = []
        for ep in self.episodes:
            if ep.get('still_path'):
                stills.append({'file_path': ep['still_path']})
        self.still_urls = [BACKDROP_BASE + s['file_path'] for s in stills]
        self.fill_image_list(1350, stills, 'backdrop')
        try:
            self.setFocusId(8)
        except:
            pass

    def fill_episode_list(self, list_id, episodes):
        try:
            if not control_exists(self, list_id):
                return
            ctl = self.getControl(list_id)
            ctl.reset()
            items = []
            for idx, ep in enumerate(episodes):
                ep_num = ep.get('episode_number', 0)
                ep_name = ep.get('name', f'Episode {ep_num}')
                still = f"https://image.tmdb.org/t/p/w500{ep['still_path']}" if ep.get('still_path') else 'DefaultVideo.png'
                air_date = format_date_short(ep.get('air_date', ''))
                li = xbmcgui.ListItem(f'[B]{ep_name}[/B]')
                v_tag = li.getVideoInfoTag()
                try:
                    v_tag.setEpisode(int(ep_num))
                except:
                    pass
                v_tag.setTitle(ep_name)
                v_tag.setMediaType('episode')
                if air_date:
                    li.setProperty('release_date', f'[B]{air_date}[/B]')
                li.setArt({'thumb': still, 'icon': still, 'poster': still})
                li.setProperty('episode_number', str(ep_num))
                li.setProperty('media_type', 'episode')
                li.setProperty('DBTYPE', 'episode')
                li.setProperty('overview', ep.get('overview', ''))
                li.setProperty('rating', str(ep.get('vote_average', 0)))
                li.setProperty('Premiered', air_date)
                if watched_provider.is_episode_watched(self.tv_id, self.season_num, ep_num):
                    li.setProperty('PlayCount', '1')
                    li.setProperty('Overlay', 'Watched')
                    v_tag.setPlaycount(1)
                else:
                    li.setProperty('PlayCount', '0')
                items.append(li)
            ctl.addItems(items)
        except Exception as e:
            log(f'Error filling episode list: {e}')

    def fill_video_list(self, list_id, videos):
        try:
            if not control_exists(self, list_id):
                return
            ctl = self.getControl(list_id)
            ctl.reset()
            list_items = []
            for v in videos:
                label = v.get('name', 'Videos')
                v_type = v.get('type', 'Videos')
                is_off = v.get('official', False)
                official_str = 'Official' if is_off else 'Standard'
                date_str = v.get('published_at', '')[:4]
                label2 = f'{official_str} {v_type}'
                if date_str:
                    label2 += f' • {date_str}'
                key = v.get('key')
                if not key:
                    continue
                icon = v.get('thumb')
                if not icon:
                    icon = f'https://img.youtube.com/vi/{key}/mqdefault.jpg'
                li = xbmcgui.ListItem(label)
                li.setLabel2(label2)
                li.setArt({'thumb': icon, 'icon': icon})
                li.setProperty('youtube_id', key)
                list_items.append(li)
            ctl.addItems(list_items)
        except Exception as e:
            pass

    def fill_cast_list(self, list_id, cast):
        try:
            if not control_exists(self, list_id):
                return
            ctl = self.getControl(list_id)
            ctl.reset()
            items = []
            for c in cast:
                name = c.get('name', '')
                character = c.get('character', '')
                li = xbmcgui.ListItem(f'[B]{name}[/B]')
                if character:
                    formatted_char = f'[B][COLOR FFFF69B4]{character}[/COLOR][/B]'
                    li.setLabel2(formatted_char)
                    li.setProperty('character', formatted_char)
                    li.setProperty('role', formatted_char)
                icon = IMG_THUMB_SMALL + c['profile_path'] if c.get('profile_path') else 'DefaultActor.png'
                li.setArt({'thumb': icon, 'icon': icon})
                li.setProperty('id', str(c.get('id', '')))
                items.append(li)
            ctl.addItems(items)
        except Exception as e:
            pass

    def fill_image_list(self, list_id, images, img_type):
        try:
            if not control_exists(self, list_id):
                return
            ctl = self.getControl(list_id)
            ctl.reset()
            items = []
            base = IMG_FULL if img_type == 'poster' else BACKDROP_BASE
            for idx, img in enumerate(images):
                path = img.get('file_path', '')
                if not path:
                    continue
                url = base + path
                li = xbmcgui.ListItem()
                li.setArt({'thumb': url, 'icon': url})
                li.setProperty('image_url', url)
                items.append(li)
            ctl.addItems(items)
        except Exception as e:
            pass

    def onAction(self, action):
        if action.getId() in [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK]:
            self.go_back = True
            self.close()

    def onClick(self, controlId):
        if controlId == 8:
            action_play_dialog(self.tv_id, 'season', season=self.season_num, title=self.tv_name)
        elif controlId == 445:
            action_options_dialog(self.tv_id, 'season', season=self.season_num, title=self.tv_name)
        elif controlId == 447:
            if action_refresh_trakt():
                self.update_ui()
        elif controlId == 446:
            self.next_info = ('trailer_choice', None)
            self.close()
        elif controlId == 132:
            if self.plot_text and (not self.showing_text_dialog):
                self.showing_text_dialog = True
                show_text_dialog(f'Season {self.season_num}', self.plot_text)
                self.showing_text_dialog = False
        elif controlId == 2000:
            item = self.getControl(2000).getSelectedItem()
            if item:
                ep_num = item.getProperty('episode_number')
                self.next_info = ('episode', ep_num)
                self.close()
        elif controlId == 1150 or controlId == 350:
            item = self.getControl(controlId).getSelectedItem()
            yt_id = item.getProperty('youtube_id')
            if yt_id:
                self.next_info = ('youtube_play', yt_id)
                self.close()
        elif controlId == 1000:
            item = self.getControl(1000).getSelectedItem()
            if item and item.getProperty('id'):
                self.next_info = ('actor', item.getProperty('id'))
                self.close()
        elif controlId == 1250:
            show_full_image(self, 1250)
        elif controlId == 1350:
            show_full_image(self, 1350)

class EpisodeInfo(ExtendedDialog):
    """Pagina pentru informatii despre un episod"""

    def __init__(self, *args, **kwargs):
        super(EpisodeInfo, self).__init__(*args)
        self.tv_id = kwargs.get('tv_id')
        self.season_num = kwargs.get('season_num')
        self.episode_num = kwargs.get('episode_num')
        self.tv_name = kwargs.get('tv_name', '')
        self.meta = {}
        self.go_back = False
        self.next_info = None
        self.plot_text = ''
        self.showing_text_dialog = False
        self.still_urls = []

    def onInit(self):
        log(f'[EpisodeInfo] Opening S{self.season_num}E{self.episode_num} for TV ID {self.tv_id}')
        self.setProperty('type', 'Episode')
        try:
            self.meta = get_tmdb_data(f'tv/{self.tv_id}/season/{self.season_num}/episode/{self.episode_num}', {'append_to_response': 'credits,images,videos', 'include_video_language': 'en,null'})
            if not self.meta or self.meta.get('success') == False:
                log(f'[EpisodeInfo] Episode S{self.season_num}E{self.episode_num} not found, falling back to TV show')
                self.close()
                try:
                    from windows.extended_info import run_extended_info
                    xbmc.sleep(100)
                    run_extended_info(self.tv_id, 'tv', season=None, episode=None, tv_name=self.tv_name)
                except Exception as e:
                    log(f'[EpisodeInfo] Fallback error: {e}')
                return
            self.update_ui()
        except Exception as e:
            log(f'[EpisodeInfo] Error in onInit: {e}')
            self.close()

    def update_ui(self):
        try:
            ep_name = self.meta.get('name', f'Episode {self.episode_num}')
            self.plot_text = self.meta.get('overview', 'No overview available.')
            air_date = self.meta.get('air_date', '')
            air_date_formatted = format_date_short(air_date)
            if not air_date_formatted:
                air_date_formatted = air_date[:4] if air_date else ''
            rating = self.meta.get('vote_average', 0)
            still = BACKDROP_BASE + self.meta.get('still_path', '') if self.meta.get('still_path') else ''
            season_str = f'S{int(self.season_num):02d}'
            episode_str = f'E{int(self.episode_num):02d}'
            if self.tv_name:
                title = f'{self.tv_name} - {season_str}{episode_str} - {ep_name}'
            else:
                title = f'{season_str}{episode_str} - {ep_name}'
            full_title = title
            self.setProperty('movie.title', title)
            self.setProperty('movie.Title', title)
            self.setProperty('title', title)
            self.setProperty('movie.originaltitle', ep_name)
            if rating:
                self.setProperty('movie.rating', f'{rating:.1f}')
                self.setProperty('movie.Rating', f'{rating:.1f}')
            self.setProperty('release_date', air_date_formatted)
            self.setProperty('movie.release_date', air_date_formatted)
            self.setProperty('movie.Premiered', air_date_formatted)
            self.setProperty('Premiered', air_date_formatted)
            self.setProperty('year', air_date_formatted)
            self.setProperty('movie.year', air_date_formatted)
            self.setProperty('movie.Year', air_date_formatted)
            self.setProperty('movie.plot', self.plot_text)
            self.setProperty('movie.Plot', self.plot_text)
            self.setProperty('plot', self.plot_text)
            if still:
                self.setProperty('movie.poster', still)
                self.setProperty('movie.fanart', still)
                self.setProperty('fanart', still)
            texture_path = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'extendedinfo', 'texture.png')
            self.setProperty('movie.ImageFilter', texture_path)
            self.setProperty('ImageFilter', texture_path)
            self.setProperty('PlayButtonLabel', 'Play')
            guest_stars = self.meta.get('guest_stars', [])
            regular_cast = self.meta.get('credits', {}).get('cast', [])
            all_cast = guest_stars + regular_cast
            self.fill_cast_list(1000, all_cast[:30])
            stills = self.meta.get('images', {}).get('stills', [])
            self.still_urls = [IMG_FULL + s['file_path'] for s in stills if s.get('file_path')]
            self.fill_image_list(1350, stills)
            try:
                self.setFocusId(8)
            except:
                pass
        except Exception as e:
            log(f'[EpisodeInfo] Error in update_ui: {e}')

    def fill_cast_list(self, list_id, cast):
        try:
            if not control_exists(self, list_id):
                return
            ctl = self.getControl(list_id)
            ctl.reset()
            items = []
            for c in cast:
                name = c.get('name', '')
                character = c.get('character', '')
                li = xbmcgui.ListItem(f'[B]{name}[/B]')
                if character:
                    formatted_char = f'[B][COLOR FFFF69B4]{character}[/COLOR][/B]'
                    li.setLabel2(formatted_char)
                    li.setProperty('character', formatted_char)
                    li.setProperty('role', formatted_char)
                icon = IMG_THUMB_SMALL + c['profile_path'] if c.get('profile_path') else 'DefaultActor.png'
                li.setArt({'thumb': icon, 'icon': icon})
                li.setProperty('id', str(c.get('id', '')))
                items.append(li)
            ctl.addItems(items)
        except:
            pass

    def fill_image_list(self, list_id, images):
        try:
            if not control_exists(self, list_id):
                return
            ctl = self.getControl(list_id)
            ctl.reset()
            items = []
            for idx, img in enumerate(images):
                path = img.get('file_path', '')
                if not path:
                    continue
                url = BACKDROP_BASE + path
                li = xbmcgui.ListItem()
                li.setArt({'thumb': url, 'icon': url})
                li.setProperty('image_url', url)
                items.append(li)
            ctl.addItems(items)
        except:
            pass

    def onAction(self, action):
        if action.getId() in [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK]:
            self.go_back = True
            self.close()

    def onClick(self, controlId):
        if controlId == 8:
            display_title = f'{self.tv_name} S{int(self.season_num):02d}E{int(self.episode_num):02d}'
            action_play_dialog(self.tv_id, 'episode', season=self.season_num, episode=self.episode_num, title=display_title)
        elif controlId == 445:
            action_options_dialog(self.tv_id, 'episode', season=self.season_num, episode=self.episode_num, title=self.tv_name)
        elif controlId == 447:
            if action_refresh_trakt():
                self.update_ui()
        elif controlId == 446:
            self.next_info = ('trailer_choice', None)
            self.close()
        elif controlId == 132:
            if self.plot_text and (not self.showing_text_dialog):
                self.showing_text_dialog = True
                show_text_dialog('Overview', self.plot_text)
                self.showing_text_dialog = False
        elif controlId == 1000:
            item = self.getControl(1000).getSelectedItem()
            if item and item.getProperty('id'):
                self.next_info = ('actor', item.getProperty('id'))
                self.close()
        elif controlId == 1350:
            show_full_image(self, 1350)

class ExtendedInfo(ExtendedDialog):

    def __init__(self, *args, **kwargs):
        super(ExtendedInfo, self).__init__(*args)
        self.tmdb_id = kwargs.get('tmdb_id')
        self.media_type = kwargs.get('media_type', 'movie')
        self.meta = {}
        self.plot_text = ''
        self.title_text = ''
        self.showing_text_dialog = False
        self.go_back = False
        self.next_info = None
        self.kodi_movies = {}
        self.kodi_tvshows = {}
        bg_fallback = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'extendedinfo', 'texture.png')
        self.setProperty('movie.fanart', bg_fallback)
        self.setProperty('fanart', bg_fallback)
        self.setProperty('ImageColor', 'FF000000')
        self.setProperty('ImageFilter', bg_fallback)
        self.setProperty('WindowColor', 'FF000000')
        self.setProperty('script.extendedinfo_running', 'True')

    def onInit(self):
        self.kodi_movies = get_kodi_library_movies()
        self.kodi_tvshows = get_kodi_library_tvshows()
        self.fetch_data()

    def fetch_data(self):
        append = 'credits,recommendations,similar,images,external_ids,release_dates,content_ratings,videos'
        endpoint = f'{self.media_type}/{self.tmdb_id}'
        all_langs = 'en,null'
        params = {'append_to_response': append, 'include_video_language': all_langs}
        data = get_tmdb_data(endpoint, params)
        if not data:
            self.close()
            return
        self.meta = data
        self.plot_text = self.meta.get('overview', '')
        self.title_text = self.meta.get('title') or self.meta.get('name', '')
        self.collection_items = []
        if self.media_type == 'movie' and self.meta.get('belongs_to_collection'):
            coll_id = self.meta['belongs_to_collection']['id']
            coll_data = get_tmdb_data(f'collection/{coll_id}')
            if coll_data:
                self.collection_items = coll_data.get('parts', [])
                self.collection_items.sort(key=lambda x: x.get('release_date', ''), reverse=False)
                coll_name = coll_data.get('name', '')
                coll_poster = IMG_BASE + coll_data.get('poster_path', '') if coll_data.get('poster_path') else ''
                coll_backdrop = BACKDROP_BASE + coll_data.get('backdrop_path', '') if coll_data.get('backdrop_path') else ''
                coll_overview = coll_data.get('overview', '')
                self.setProperty('movie.set.label', coll_name)
                self.setProperty('movie.set.id', str(coll_id))
                self.setProperty('movie.set.poster', coll_poster)
                self.setProperty('movie.set.thumb', coll_poster)
                self.setProperty('movie.set.fanart', coll_backdrop)
                self.setProperty('movie.set.overview', coll_overview)
        self.seasons_items = []
        if self.media_type == 'tv':
            seasons = self.meta.get('seasons', [])
            self.seasons_items = [s for s in seasons if s.get('season_number', 0) > 0 or settings.show_specials()]
            self.setProperty('TotalSeasons', str(self.meta.get('number_of_seasons', len(self.seasons_items))))
            self.setProperty('TotalEpisodes', str(self.meta.get('number_of_episodes', 0)))
        self.update_ui()
        try:
            self.setFocusId(8)
        except:
            pass

    def load_youtube_async(self):
        if self._closed:
            return
        videos = [v for v in self.meta.get('videos', {}).get('results', []) if v.get('site') == 'YouTube' and v.get('key')]
        self.fill_video_list(1150, videos)
        if self._closed:
            return
        found = get_youtube_search_results(self.title_text + ' trailer', max_results=12)
        if self._closed:
            return
        official_keys = {v['key'] for v in videos}
        secondary = []
        for item in found:
            key = item.get('id', {}).get('videoId')
            if not key or key in official_keys:
                continue
            snippet = item.get('snippet', {})
            secondary.append({'name': html.unescape(snippet.get('title', 'Video')), 'key': key, 'type': 'Video', 'official': False, 'thumb': snippet.get('thumbnails', {}).get('high', {}).get('url', ''), 'published_at': snippet.get('publishedAt', '')})
        self.fill_video_list(350, secondary)

    def update_ui(self):
        title = self.meta.get('title') or self.meta.get('name')
        plot = self.meta.get('overview', '')
        rating = str(round(self.meta.get('vote_average', 0), 1))
        votes = f"{self.meta.get('vote_count', 0):,}"
        raw_date = self.meta.get('release_date') or self.meta.get('first_air_date') or ''
        year = raw_date[:4]
        formatted_date = format_date(raw_date)
        raw_status = self.meta.get('status', '')
        status = raw_status
        status_map = {'released': 'Released', 'post production': 'Post production', 'in production': 'In production', 'ended': 'Ended', 'returning series': 'Continuing', 'planned': 'Planned', 'canceled': 'Canceled'}
        if raw_status.lower() in status_map:
            status = status_map[raw_status.lower()]
        duration = ''
        try:
            if self.media_type == 'movie':
                r = self.meta.get('runtime')
                if r:
                    r = int(r)
                    duration = f'{r // 60}h {r % 60}m'
            else:
                r = self.meta.get('episode_run_time', [])
                if r and r[0]:
                    duration = f'{int(r[0])} min'
        except:
            pass
        studio = ''
        if self.media_type == 'movie':
            if self.meta.get('production_companies'):
                studio = self.meta['production_companies'][0]['name']
        elif self.meta.get('networks'):
            studio = self.meta['networks'][0]['name']
        country_text = ''
        if self.media_type == 'movie':
            pcs = self.meta.get('production_countries', [])
            if pcs:
                names = [c['name'] for c in pcs if c.get('name')]
                country_text = ', '.join(names[:3])
        else:
            origins = self.meta.get('origin_country', [])
            if origins:
                country_text = ', '.join(origins[:3])
        mpaa = ''
        if self.media_type == 'movie':
            rels = self.meta.get('release_dates', {}).get('results', [])
            for r in rels:
                if r['iso_3166_1'] == settings.mpaa_region():
                    for c in r['release_dates']:
                        if c['certification']:
                            mpaa = c['certification']
                            break
        else:
            rels = self.meta.get('content_ratings', {}).get('results', [])
            for r in rels:
                if r['iso_3166_1'] == settings.mpaa_region():
                    mpaa = r['rating']
                    break
        poster = IMG_BASE + self.meta.get('poster_path', '') if self.meta.get('poster_path') else ''
        fanart = ''
        if self.meta.get('backdrop_path'):
            fanart = BACKDROP_BASE + self.meta.get('backdrop_path')
        logo = ''
        logos = [x['file_path'] for x in self.meta.get('images', {}).get('logos', []) if x.get('iso_639_1') == 'en']
        if logos:
            logo = IMG_BASE + logos[0]
        budget = format_money_short(self.meta.get('budget', 0))
        revenue = format_money_short(self.meta.get('revenue', 0))
        genres_list = [g['name'] for g in self.meta.get('genres', [])]
        genres_str = ' • '.join(genres_list)
        tagline = self.meta.get('tagline', '').strip()
        final_tagline = ''
        if tagline and genres_str:
            final_tagline = f'[COLOR yellow]{tagline}[/COLOR]   |   [COLOR FF00CED1]{genres_str}[/COLOR]'
        elif tagline:
            final_tagline = tagline
        elif genres_str:
            final_tagline = f'[COLOR FF00CED1]{genres_str}[/COLOR]'
        props = {'title': title, 'Title': title, 'originaltitle': self.meta.get('original_title') or self.meta.get('original_name', title), 'plot': plot, 'Plot': plot, 'TagLine': final_tagline, 'Tagline': final_tagline, 'rating': rating, 'Rating': rating, 'votes': votes, 'Votes': votes, 'year': year, 'Year': year, 'duration': duration, 'Duration': duration, 'studio': studio, 'Studio': studio, 'country': country_text, 'Country': country_text, 'mpaa': mpaa, 'MPAA': mpaa, 'poster': poster, 'Poster': poster, 'clearlogo': logo, 'logo': logo, 'Budget': budget, 'Revenue': revenue, 'Status': status, 'Premiered': formatted_date, 'Release_Date': formatted_date, 'ReleaseDate': formatted_date, 'dbid': '0', 'imdbnumber': self.meta.get('external_ids', {}).get('imdb_id', '')}
        texture_path = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'extendedinfo', 'texture.png')
        if fanart:
            props['fanart'] = fanart
            props['Fanart'] = fanart
        self.setProperty('movie.ImageFilter', texture_path)
        self.setProperty('ImageFilter', texture_path)
        btn_label = 'Play' if self.media_type == 'movie' else 'Browse'
        self.setProperty('PlayButtonLabel', btn_label)
        for k, v in props.items():
            self.setProperty(f'movie.{k}', str(v))
            self.setProperty(k, str(v))
        log(f'UPDATE_UI: Title={title}, Status={status}, Background={texture_path}')
        log(f'UPDATE_UI: Title={title}, Status={status}, Budget={budget}')

        def populate_lists_worker():
            if self.media_type == 'movie' and self.collection_items:
                self.fill_media_list(250, self.collection_items, 'movie')
            elif self.media_type == 'tv' and self.seasons_items:
                self.fill_season_list(250, self.seasons_items)
            cast = self.meta.get('credits', {}).get('cast', [])
            if self.media_type == 'tv':
                cast = cast[:20]
            self.fill_actor_list(1000, cast)
            recommendations = self.meta.get('recommendations', {}).get('results', [])
            if not recommendations:
                recommendations = self.meta.get('similar', {}).get('results', [])
            if recommendations:
                recommendations = self.sort_by_library_and_year(recommendations, self.media_type)
                self.fill_media_list(150, recommendations, self.media_type)
            posters = self.meta.get('images', {}).get('posters', [])
            self.fill_image_list(1250, posters, 'poster')
            backdrops = self.meta.get('images', {}).get('backdrops', [])
            self.fill_image_list(1350, backdrops, 'backdrop')
            self.load_youtube_async()
        t = threading.Thread(target=populate_lists_worker)
        t.daemon = True
        t.start()

    def sort_by_library_and_year(self, items, media_type):
        in_library = []
        not_in_library = []
        library = self.kodi_movies if media_type == 'movie' else self.kodi_tvshows
        for item in items:
            tmdb_id_str = str(item.get('id', ''))
            year_str = (item.get('release_date') or item.get('first_air_date') or '')[:4]
            try:
                year_int = int(year_str) if year_str else 0
            except:
                year_int = 0
            item['_year_int'] = year_int
            if tmdb_id_str in library:
                in_library.append(item)
            else:
                not_in_library.append(item)
        in_library.sort(key=lambda x: x['_year_int'], reverse=True)
        not_in_library.sort(key=lambda x: x['_year_int'], reverse=True)
        return in_library + not_in_library

    def fill_media_list(self, list_id, items, media_type):
        try:
            ctl = self.getControl(list_id)
            ctl.reset()
            list_items = []
            library = self.kodi_movies if media_type == 'movie' else self.kodi_tvshows
            media_type_tag = 'movie' if media_type == 'movie' else 'tvshow'
            for i in items:
                label = i.get('title') or i.get('name', '')
                icon = IMG_THUMB_SMALL + i['poster_path'] if i.get('poster_path') else 'DefaultVideo.png'
                year_str = (i.get('release_date') or i.get('first_air_date') or '')[:4]
                li = create_list_item_with_year(label, year_str, icon, media_type)
                tag = li.getVideoInfoTag()
                tag.setMediaType(media_type_tag)
                tag.setTitle(label)
                li.setProperty('id', str(i['id']))
                li.setProperty('media_type', media_type)
                tmdb_id_str = str(i['id'])
                playcount = 0
                if media_type == 'movie':
                    if watched_provider.is_movie_watched(tmdb_id_str):
                        playcount = 1
                elif media_type == 'tv':
                    tag.setTvShowTitle(label)
                    watched_eps = watched_provider.get_episode_watched_count(tmdb_id_str)
                    total_eps = trakt_sync.get_tv_meta_from_db(tmdb_id_str)
                    if total_eps == 0 and watched_eps > 0:
                        try:
                            data = get_tmdb_data('tv/' + tmdb_id_str)
                            if data:
                                total_eps = data.get('number_of_episodes', 0)
                                if total_eps:
                                    trakt_sync.set_tv_meta_to_db(tmdb_id_str, total_eps)
                        except:
                            pass
                    if total_eps > 0:
                        li.setProperty('WatchedEpisodes', str(watched_eps))
                        li.setProperty('UnWatchedEpisodes', str(max(0, total_eps - watched_eps)))
                    elif watched_eps > 0:
                        li.setProperty('WatchedEpisodes', str(watched_eps))
                        li.setProperty('UnWatchedEpisodes', '1')
                    if watched_eps > 0 and total_eps > 0 and (watched_eps >= total_eps):
                        playcount = 1
                if tmdb_id_str in library:
                    info = library[tmdb_id_str]
                    li.setProperty('DBID', str(info['dbid']))
                    if info.get('playcount', 0) > 0:
                        playcount = info['playcount']
                if playcount > 0:
                    li.setProperty('PlayCount', str(playcount))
                    tag.setPlaycount(playcount)
                list_items.append(li)
            ctl.addItems(list_items)
        except Exception as e:
            log(f'Error filling list {list_id}: {e}')

    def fill_season_list(self, list_id, seasons):
        try:
            _show_specials = settings.show_specials()
            ctl = self.getControl(list_id)
            ctl.reset()
            list_items = []
            for s in seasons:
                season_num = s.get('season_number', 0)
                if season_num == 0 and (not _show_specials):
                    continue
                ep_count = s.get('episode_count', 0)
                raw_label = (s.get('name') if settings.use_season_name() else None) or ('Specials' if season_num == 0 else f'Season {season_num}')
                label = f'[B]{raw_label}[/B]'
                icon = IMG_THUMB_SMALL + s['poster_path'] if s.get('poster_path') else 'DefaultVideo.png'
                li = xbmcgui.ListItem(label)
                li.setLabel2(f'[B]{ep_count} Episodes[/B]')
                li.setArt({'thumb': icon, 'poster': icon})
                li.setProperty('season_number', str(season_num))
                li.setProperty('id', str(self.tmdb_id))
                li.setProperty('media_type', 'season')
                tag = li.getVideoInfoTag()
                tag.setMediaType('season')
                tag.setTitle(raw_label)
                li.setProperty('DBTYPE', 'season')
                watched_eps = watched_provider.get_season_watched_count(self.tmdb_id, season_num)
                unwatched = max(0, ep_count - watched_eps)
                li.setProperty('WatchedEpisodes', str(watched_eps))
                li.setProperty('UnWatchedEpisodes', str(unwatched))
                li.setProperty('TotalEpisodes', str(ep_count))
                if ep_count > 0 and watched_eps >= ep_count:
                    li.setProperty('PlayCount', '1')
                    li.setProperty('Overlay', 'Watched')
                    tag.setPlaycount(1)
                else:
                    li.setProperty('PlayCount', '0')
                    tag.setPlaycount(0)
                list_items.append(li)
            ctl.addItems(list_items)
        except Exception as e:
            log(f'Error filling season list: {e}')

    def fill_actor_list(self, list_id, actors):
        try:
            ctl = self.getControl(list_id)
            ctl.reset()
            list_items = []
            for a in actors:
                name = a.get('name', '')
                character = a.get('character', '')
                li = xbmcgui.ListItem(f'[B]{name}[/B]')
                if character:
                    formatted_char = f'[B][COLOR FFFF69B4]{character}[/COLOR][/B]'
                    li.setLabel2(formatted_char)
                    li.setProperty('Character', formatted_char)
                    li.setProperty('character', formatted_char)
                icon = IMG_THUMB_SMALL + a['profile_path'] if a.get('profile_path') else 'DefaultActor.png'
                li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
                li.setProperty('id', str(a['id']))
                list_items.append(li)
            ctl.addItems(list_items)
        except:
            pass

    def fill_video_list(self, list_id, videos):
        try:
            if not control_exists(self, list_id):
                return
            ctl = self.getControl(list_id)
            ctl.reset()
            list_items = []
            for v in videos:
                label = v.get('name', 'Videos')
                v_type = v.get('type', 'Videos')
                is_off = v.get('official', False)
                official_str = 'Official' if is_off else 'Unofficial'
                date_str = v.get('published_at', '')[:4]
                label2 = f'{official_str} {v_type}'
                if date_str:
                    label2 += f' • {date_str}'
                key = v.get('key')
                if not key:
                    continue
                icon = v.get('thumb')
                if not icon:
                    icon = f'https://img.youtube.com/vi/{key}/mqdefault.jpg'
                li = xbmcgui.ListItem(label)
                li.setLabel2(label2)
                li.setArt({'thumb': icon, 'icon': icon})
                li.setProperty('youtube_id', key)
                list_items.append(li)
            ctl.addItems(list_items)
        except Exception as e:
            log(f'Error filling video list {list_id}: {e}')

    def fill_image_list(self, list_id, images, img_type):
        try:
            ctl = self.getControl(list_id)
            ctl.reset()
            list_items = []
            base = IMG_FULL if img_type == 'poster' else BACKDROP_BASE
            for idx, img in enumerate(images):
                path = img.get('file_path', '')
                if not path:
                    continue
                full_url = base + path
                li = xbmcgui.ListItem()
                li.setArt({'thumb': full_url, 'icon': full_url})
                li.setProperty('image_url', full_url)
                list_items.append(li)
            ctl.addItems(list_items)
        except:
            pass

    def get_selected_image_url(self, list_id):
        try:
            item = self.getControl(list_id).getSelectedItem()
            if item:
                return item.getProperty('image_url')
        except:
            pass
        return None

    def onAction(self, action):
        if action.getId() in [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK]:
            self.go_back = True
            self.close()

    def onClick(self, controlId):
        if controlId == 8:
            action_play_dialog(self.tmdb_id, self.media_type, title=self.title_text)
        elif controlId == 445:
            action_options_dialog(self.tmdb_id, self.media_type, title=self.title_text)
        elif controlId == 447:
            if action_refresh_trakt():
                self.update_ui()
        elif controlId == 446:
            self.next_info = ('trailer_choice', None)
            self.close()
        elif controlId == 132:
            if self.plot_text and (not self.showing_text_dialog):
                self.showing_text_dialog = True
                show_text_dialog(self.title_text, self.plot_text)
                self.showing_text_dialog = False
        elif controlId == 1000:
            item = self.getControl(1000).getSelectedItem()
            if item and item.getProperty('id'):
                self.next_info = ('actor', item.getProperty('id'))
                self.close()
        elif controlId in [150, 250]:
            item = self.getControl(controlId).getSelectedItem()
            if item:
                media_type = item.getProperty('media_type')
                item_id = item.getProperty('id')
                if media_type == 'season':
                    season_num = item.getProperty('season_number')
                    self.next_info = ('season', {'tv_id': self.tmdb_id, 'season_num': season_num, 'tv_name': self.title_text})
                    self.close()
                elif item_id:
                    self.next_info = ('media', {'id': item_id, 'type': media_type or 'movie'})
                    self.close()
        elif controlId == 1150 or controlId == 350:
            item = self.getControl(controlId).getSelectedItem()
            if item and item.getProperty('youtube_id'):
                self.next_info = ('youtube_play', item.getProperty('youtube_id'))
                self.close()
        elif controlId == 1250:
            show_full_image(self, 1250)
        elif controlId == 1350:
            show_full_image(self, 1350)

class ActorInfo(ExtendedDialog):

    def __init__(self, *args, **kwargs):
        super(ActorInfo, self).__init__(*args)
        self.actor_id = kwargs.get('actor_id')
        self.meta = {}
        self.actor_name = ''
        self.biography_text = ''
        self.showing_text_dialog = False
        self.go_back = False
        self.next_info = None
        self.kodi_movies = {}
        self.kodi_tvshows = {}
        bg_fallback = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'extendedinfo', 'texture.png')
        self.setProperty('fanart', bg_fallback)
        self.setProperty('actor.ImageFilter', bg_fallback)
        self.setProperty('ImageFilter', bg_fallback)

    def onInit(self):
        self.kodi_movies = get_kodi_library_movies()
        self.kodi_tvshows = get_kodi_library_tvshows()
        append = 'movie_credits,tv_credits,images,tagged_images,external_ids'
        data = get_tmdb_data(f'person/{self.actor_id}', {'append_to_response': append})
        if not data:
            self.close()
            return
        self.meta = data
        self.actor_name = self.meta.get('name', '')
        self.biography_text = self.meta.get('biography', '')
        birthday = self.meta.get('birthday', '')
        deathday = self.meta.get('deathday', '')
        place_of_birth = self.meta.get('place_of_birth', '')
        raw_aka = self.meta.get('also_known_as', [])
        clean_aka = []
        for name in raw_aka:
            is_readable = True
            for char in name:
                if ord(char) > 1000:
                    is_readable = False
                    break
            if is_readable:
                clean_aka.append(name)
        also_known_as_str = ', '.join(clean_aka[:5]) if clean_aka else ''
        thumb = IMG_BASE + self.meta.get('profile_path', '') if self.meta.get('profile_path') else ''
        age = calculate_age(birthday, deathday)
        birthday_formatted = format_date(birthday) if birthday else ''
        deathday_formatted = format_date(deathday) if deathday else ''
        final_birthday_str = birthday_formatted
        if final_birthday_str and age:
            if deathday:
                final_birthday_str = f'[B]{final_birthday_str}[/B]   [COLOR gray]Died at: [B][COLOR FFFDBD01]{age}[/COLOR][/B]'
            else:
                final_birthday_str = f'[B]{final_birthday_str}[/B]   [COLOR gray]Age: [B][COLOR FFFDBD01]{age}[/COLOR][/B]'
        if also_known_as_str:
            also_known_as_str = f'[B]{also_known_as_str}[/B]'
        if place_of_birth:
            place_of_birth = f'[B]{place_of_birth}[/B]'
        if final_birthday_str:
            final_birthday_str = f'{final_birthday_str}'
        if deathday_formatted:
            deathday_formatted = f'[B]{deathday_formatted}[/B]'
        movies = self.meta.get('movie_credits', {}).get('cast', [])
        tvshows = self.meta.get('tv_credits', {}).get('cast', [])
        total_movies_str = f'[B]{len(movies)}[/B]'
        self.setProperty('actor.title', self.actor_name)
        self.setProperty('actor.name', self.actor_name)
        self.setProperty('actor.AlsoKnownAs', also_known_as_str)
        self.setProperty('actor.Birthday', final_birthday_str)
        self.setProperty('actor.Age', '')
        self.setProperty('actor.PlaceOfBirth', place_of_birth)
        self.setProperty('actor.Deathday', deathday_formatted)
        self.setProperty('actor.Biography', self.biography_text)
        self.setProperty('actor.TotalMovies', total_movies_str)
        self.setProperty('actor.thumb', thumb)
        texture_path = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'extendedinfo', 'texture.png')
        self.setProperty('actor.ImageFilter', texture_path)
        self.setProperty('ImageFilter', texture_path)
        movies = self.sort_credits_by_library_and_year(movies, 'movie')
        tvshows = self.sort_credits_by_library_and_year(tvshows, 'tv')
        self.fill_credits(150, movies, 'movie')
        self.fill_credits(250, tvshows, 'tv')
        if control_exists(self, 350):
            t = threading.Thread(target=self.fill_actor_youtube_videos, args=(350, self.actor_name, movies[:15]))
            t.daemon = True
            t.start()
        actor_images = self.meta.get('images', {}).get('profiles', [])
        if control_exists(self, 450):
            self.fill_image_list(450, actor_images, 'profile')
        tagged_images = self.meta.get('tagged_images', {}).get('results', [])
        if control_exists(self, 750):
            self.fill_tagged_images(750, tagged_images)

    def sort_credits_by_library_and_year(self, items, media_type):
        in_library = []
        not_in_library = []
        library = self.kodi_movies if media_type == 'movie' else self.kodi_tvshows
        for item in items:
            tmdb_id_str = str(item.get('id', ''))
            year_str = (item.get('release_date') or item.get('first_air_date') or '')[:4]
            try:
                year_int = int(year_str) if year_str else 0
            except:
                year_int = 0
            item['_year_int'] = year_int
            if tmdb_id_str in library:
                in_library.append(item)
            else:
                not_in_library.append(item)
        in_library.sort(key=lambda x: x['_year_int'], reverse=True)
        not_in_library.sort(key=lambda x: x['_year_int'], reverse=True)
        return in_library + not_in_library

    def fill_credits(self, list_id, items, m_type):
        try:
            ctl = self.getControl(list_id)
            ctl.reset()
            l_items = []
            library = self.kodi_movies if m_type == 'movie' else self.kodi_tvshows
            db_type_str = 'movie' if m_type == 'movie' else 'tvshow'
            for i in items:
                label = i.get('title') or i.get('name', '')
                icon = IMG_THUMB_SMALL + i['poster_path'] if i.get('poster_path') else 'DefaultVideo.png'
                character = i.get('character', '')
                year_str = (i.get('release_date') or i.get('first_air_date') or '')[:4]
                li = create_list_item_with_year(label, year_str, icon, m_type)
                if character:
                    formatted_char = f'[B][COLOR FFFF69B4]{character}[/COLOR][/B]'
                    li.setProperty('Character', formatted_char)
                    li.setProperty('character', formatted_char)
                    li.setLabel2(formatted_char)
                tag = li.getVideoInfoTag()
                tag.setMediaType(db_type_str)
                tag.setTitle(label)
                li.setProperty('id', str(i['id']))
                li.setProperty('media_type', m_type)
                tmdb_id_str = str(i['id'])
                playcount = 0
                if m_type == 'movie':
                    if watched_provider.is_movie_watched(tmdb_id_str):
                        playcount = 1
                else:
                    tag.setTvShowTitle(label)
                    watched_eps = watched_provider.get_episode_watched_count(tmdb_id_str)
                    total_eps = trakt_sync.get_tv_meta_from_db(tmdb_id_str)
                    if total_eps == 0 and watched_eps > 0:
                        try:
                            data = get_tmdb_data('tv/' + tmdb_id_str)
                            if data:
                                total_eps = data.get('number_of_episodes', 0)
                                if total_eps:
                                    trakt_sync.set_tv_meta_to_db(tmdb_id_str, total_eps)
                        except:
                            pass
                    if total_eps > 0:
                        li.setProperty('WatchedEpisodes', str(watched_eps))
                        li.setProperty('UnWatchedEpisodes', str(max(0, total_eps - watched_eps)))
                    elif watched_eps > 0:
                        li.setProperty('WatchedEpisodes', str(watched_eps))
                        li.setProperty('UnWatchedEpisodes', '1')
                    if watched_eps > 0 and total_eps > 0 and (watched_eps >= total_eps):
                        playcount = 1
                if tmdb_id_str in library:
                    info = library[tmdb_id_str]
                    li.setProperty('DBID', str(info['dbid']))
                    if m_type == 'tv':
                        if info.get('watched', 0) > 0:
                            playcount = 1
                    elif info.get('playcount', 0) > 0:
                        playcount = 1
                if playcount > 0:
                    li.setProperty('PlayCount', '1')
                    tag.setPlaycount(1)
                else:
                    li.setProperty('PlayCount', '0')
                    tag.setPlaycount(0)
                l_items.append(li)
            ctl.addItems(l_items)
        except Exception as e:
            log(f'Error filling credits: {e}')

    def fill_actor_youtube_videos(self, list_id, actor_name, popular_movies):
        try:
            search_query = f'{actor_name} interview best moments'
            results = get_youtube_search_results(search_query)
            list_items = []
            if results:
                for item in results:
                    snippet = item.get('snippet', {})
                    video_id = item.get('id', {}).get('videoId')
                    if not video_id:
                        continue
                    raw_title = html.unescape(snippet.get('title', ''))
                    title = ''
                    for char in raw_title:
                        if ord(char) < 60000:
                            title += char
                    title_lower = title.lower()
                    v_type = 'Video'
                    if 'interview' in title_lower or 'talk' in title_lower:
                        v_type = 'Interview'
                    elif 'funny' in title_lower or 'moments' in title_lower or 'compilation' in title_lower:
                        v_type = 'Best Moments'
                    elif 'trailer' in title_lower:
                        v_type = 'Trailer'
                    date_str = snippet.get('publishedAt', '')[:4]
                    label2 = f'{v_type}'
                    if date_str:
                        label2 += f' • {date_str}'
                    icon = snippet.get('thumbnails', {}).get('high', {}).get('url', '')
                    if not icon:
                        icon = f'https://img.youtube.com/vi/{video_id}/mqdefault.jpg'
                    li = xbmcgui.ListItem(title)
                    li.setLabel2(label2)
                    li.setArt({'thumb': icon, 'icon': icon})
                    li.setProperty('youtube_id', video_id)
                    list_items.append(li)
            if control_exists(self, list_id):
                ctl = self.getControl(list_id)
                ctl.addItems(list_items)
        except Exception as e:
            pass

    def fill_image_list(self, list_id, images, img_type):
        try:
            ctl = self.getControl(list_id)
            ctl.reset()
            l_items = []
            base = IMG_FULL
            for idx, img in enumerate(images):
                path = img.get('file_path', '')
                if not path:
                    continue
                full_url = base + path
                thumb_url = IMG_THUMB_SMALL + path
                li = xbmcgui.ListItem()
                li.setArt({'thumb': thumb_url, 'icon': thumb_url})
                li.setProperty('image_url', full_url)
                l_items.append(li)
            ctl.addItems(l_items)
        except:
            pass

    def fill_tagged_images(self, list_id, images):
        try:
            ctl = self.getControl(list_id)
            ctl.reset()
            l_items = []
            for idx, img in enumerate(images[:30]):
                path = img.get('file_path', '')
                if not path:
                    continue
                full_url = BACKDROP_BASE + path
                thumb_url = IMG_THUMB_SMALL + path
                li = xbmcgui.ListItem()
                li.setArt({'thumb': thumb_url, 'icon': thumb_url})
                li.setProperty('image_url', full_url)
                l_items.append(li)
            ctl.addItems(l_items)
        except:
            pass

    def get_selected_image_url(self, list_id):
        try:
            item = self.getControl(list_id).getSelectedItem()
            if item:
                return item.getProperty('image_url')
        except:
            pass
        return None

    def onAction(self, action):
        if action.getId() in [ACTION_PREVIOUS_MENU, ACTION_NAV_BACK]:
            self.go_back = True
            self.close()

    def onClick(self, controlId):
        if controlId == 132:
            if self.biography_text and (not self.showing_text_dialog):
                self.showing_text_dialog = True
                show_text_dialog(self.actor_name, self.biography_text)
                self.showing_text_dialog = False
            return
        if controlId == 150:
            item = self.getControl(150).getSelectedItem()
            if item and item.getProperty('id'):
                self.next_info = ('media', {'id': item.getProperty('id'), 'type': 'movie'})
                self.close()
        elif controlId == 250:
            item = self.getControl(250).getSelectedItem()
            if item and item.getProperty('id'):
                self.next_info = ('media', {'id': item.getProperty('id'), 'type': 'tv'})
                self.close()
        elif controlId == 350:
            item = self.getControl(350).getSelectedItem()
            if item:
                yt_id = item.getProperty('youtube_id')
                if yt_id:
                    self.next_info = ('youtube_play', yt_id)
                    self.close()
        elif controlId == 450:
            show_full_image(self, 450)
        elif controlId == 750:
            show_full_image(self, 750)

def run_extended_info(tmdb_id, media_type='movie', clear_stack=True, season=None, episode=None, tv_name=''):
    if clear_stack:
        adapter.begin_session()
        NAVIGATION_STACK.clear()
    if media_type == 'actor':
        NAVIGATION_STACK.append({'type': 'actor', 'actor_id': tmdb_id})
    elif media_type == 'tv' and season is not None and (episode is not None):
        log(f'[RunLoop] Direct Launch: EPISODE S{season}E{episode}')
        NAVIGATION_STACK.append({'type': 'episode', 'tv_id': tmdb_id, 'season_num': season, 'episode_num': episode, 'tv_name': tv_name})
    elif media_type == 'tv' and season is not None:
        log(f'[RunLoop] Direct Launch: SEASON {season}')
        NAVIGATION_STACK.append({'type': 'season', 'tv_id': tmdb_id, 'season_num': season, 'tv_name': tv_name})
    else:
        log(f'[RunLoop] Direct Launch: MAIN MEDIA ({media_type})')
        NAVIGATION_STACK.append({'type': 'media', 'tmdb_id': tmdb_id, 'media_type': media_type})
    while NAVIGATION_STACK:
        current = NAVIGATION_STACK[-1]
        log(f"[RunLoop] Processing Stack Item: {current['type']}")
        if current['type'] == 'media':
            wd = ExtendedInfo(XML_VIDEO_INFO, ADDON_PATH, 'Default', '1080i', tmdb_id=current['tmdb_id'], media_type=current['media_type'])
            wd.doModal()
            if wd.next_info and wd.next_info[0] == 'trailer_choice':
                del wd
                kind = current.get('media_type') or current['type']
                media_id = current.get('tmdb_id') or current.get('tv_id')
                _play_and_wait(lambda: adapter.trailer(media_id, kind,
                    current.get('season_num'), current.get('episode_num')))
                continue
            if wd.go_back:
                NAVIGATION_STACK.pop()
            elif wd.next_info:
                next_type, next_data = wd.next_info
                if next_type == 'youtube_play':
                    meta = getattr(wd, 'meta', {})
                    t = meta.get('title') or meta.get('name')
                    g = ' / '.join([x['name'] for x in meta.get('genres', [])]) if meta.get('genres') else None
                    del wd
                    play_youtube_and_return(next_data, title=t, genre=g, plot=_trailer_info_plot(meta, g)[0], studio=_trailer_info_plot(meta, g)[1] or None, tmdb_id=current.get('tmdb_id'), dbtype=current.get('media_type'))
                    continue
                else:
                    handle_next_info(wd.next_info)
            else:
                del wd
                break
            del wd
        elif current['type'] == 'actor':
            wd = ActorInfo(XML_ACTOR_INFO, ADDON_PATH, 'Default', '1080i', actor_id=current['actor_id'])
            wd.doModal()
            if wd.next_info and wd.next_info[0] == 'trailer_choice':
                del wd
                kind = current.get('media_type') or current['type']
                media_id = current.get('tmdb_id') or current.get('tv_id')
                _play_and_wait(lambda: adapter.trailer(media_id, kind,
                    current.get('season_num'), current.get('episode_num')))
                continue
            if wd.go_back:
                NAVIGATION_STACK.pop()
            elif wd.next_info:
                next_type, next_data = wd.next_info
                if next_type == 'youtube_play':
                    meta = getattr(wd, 'meta', {})
                    t = meta.get('title') or meta.get('name')
                    g = ' / '.join([x['name'] for x in meta.get('genres', [])]) if meta.get('genres') else None
                    del wd
                    play_youtube_and_return(next_data, title=t, genre=g, plot=_trailer_info_plot(meta, g)[0], studio=_trailer_info_plot(meta, g)[1] or None, tmdb_id=current.get('tmdb_id'), dbtype=current.get('media_type'))
                    continue
                else:
                    handle_next_info(wd.next_info)
            else:
                del wd
                break
            del wd
        elif current['type'] == 'season':
            wd = SeasonInfo(XML_VIDEO_INFO, ADDON_PATH, 'Default', '1080i', tv_id=current['tv_id'], season_num=current['season_num'], tv_name=current.get('tv_name', ''))
            wd.doModal()
            if wd.next_info and wd.next_info[0] == 'trailer_choice':
                del wd
                kind = current.get('media_type') or current['type']
                media_id = current.get('tmdb_id') or current.get('tv_id')
                _play_and_wait(lambda: adapter.trailer(media_id, kind,
                    current.get('season_num'), current.get('episode_num')))
                continue
            if wd.go_back:
                NAVIGATION_STACK.pop()
            elif wd.next_info:
                next_type, next_data = wd.next_info
                if next_type == 'youtube_play':
                    meta = getattr(wd, 'meta', {}) or {}
                    _tg, _gn = _show_tagline_genres(current.get('tv_id'))
                    if _tg and (not meta.get('tagline')):
                        meta['tagline'] = _tg
                    if _gn and (not meta.get('genres')):
                        meta['genres'] = [{'name': x.strip()} for x in _gn.split(',')]
                    t = meta.get('title') or meta.get('name') or current.get('tv_name')
                    g = ' / '.join([x['name'] for x in meta.get('genres', [])]) if meta.get('genres') else None
                    del wd
                    play_youtube_and_return(next_data, title=t, genre=g, plot=_trailer_info_plot(meta, g)[0], studio=_trailer_info_plot(meta, g)[1] or None, tmdb_id=current.get('tv_id'), dbtype='tv' if current.get('type') == 'season' else None)
                    continue
                log(f'[RunLoop] Season Next Info: {wd.next_info}')
                handle_next_info_season(wd.next_info, current)
            else:
                del wd
                break
            del wd
        elif current['type'] == 'episode':
            wd = EpisodeInfo(XML_VIDEO_INFO, ADDON_PATH, 'Default', '1080i', tv_id=current['tv_id'], season_num=current['season_num'], episode_num=current['episode_num'], tv_name=current.get('tv_name', ''))
            wd.doModal()
            if wd.next_info and wd.next_info[0] == 'trailer_choice':
                del wd
                kind = current.get('media_type') or current['type']
                media_id = current.get('tmdb_id') or current.get('tv_id')
                _play_and_wait(lambda: adapter.trailer(media_id, kind,
                    current.get('season_num'), current.get('episode_num')))
                continue
            if wd.go_back:
                NAVIGATION_STACK.pop()
            elif wd.next_info:
                handle_next_info_episode(wd.next_info)
            else:
                del wd
                break
            del wd
        else:
            break
    NAVIGATION_STACK.clear()
_season_show_cache = {}

def _show_tagline_genres(tv_id):
    """Tagline + genurile SERIALULUI. Sezonul TMDb (tv/{id}/season/{n}) nu are
    campuri de tagline/genres, deci antetul 'motto | gen' pentru OSD-ul
    trailerului nu s-ar putea construi din meta-ul sezonului."""
    try:
        if tv_id not in _season_show_cache:
            _season_show_cache[tv_id] = get_tmdb_data(f'tv/{tv_id}') or {}
        d = _season_show_cache[tv_id]
        tg = (d.get('tagline') or '').strip()
        gn = ', '.join([g.get('name') for g in d.get('genres') or [] if g.get('name')])
        return (tg, gn)
    except Exception:
        return ('', '')

def _trailer_info_plot(meta, genres_str):
    tagline = ((meta or {}).get('tagline') or '').strip()
    overview = ((meta or {}).get('overview') or '').strip()
    head = ''
    if tagline and genres_str:
        head = f'[B][COLOR yellow]{tagline}[/COLOR][/B] | [B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n'
    elif tagline:
        head = f'[B][COLOR yellow]{tagline}[/COLOR][/B]\n'
    elif genres_str:
        head = f'[B][COLOR FF00CED1]{genres_str}[/COLOR][/B]\n'
    studio = ''
    try:
        cos = ((meta or {}).get('production_companies') or []) or ((meta or {}).get('networks') or [])
        if cos and isinstance(cos, list) and cos[0].get('name'):
            studio = cos[0]['name']
    except:
        pass
    return (head + overview, studio)

def play_youtube_and_return(yt_id, title=None, genre=None, tmdb_id=None, dbtype=None, year=None, plot=None, studio=None):
    params = {'mode': 'trailer.play', 'video_id': yt_id, 'title': title or '', 'genre': genre or '', 'tmdb_id': tmdb_id or '', 'dbtype': 'tvshow' if dbtype == 'tv' else dbtype or 'movie', 'year': year or '', 'plot': plot or '', 'studio': studio or ''}
    _play_and_wait(lambda: xbmc.executebuiltin('PlayMedia(%s)' % kodi_utils.build_url(params)))


class _TrailerPlayback(xbmc.Player):
    """Keep the ExtendedInfo dialog closed while Kodi resolves and plays a trailer."""
    def __init__(self):
        super().__init__()
        self.finished = False

    def onPlayBackEnded(self):
        self.finished = True

    def onPlayBackStopped(self):
        self.finished = True

    def onPlayBackError(self):
        self.finished = True


def _play_and_wait(start_playback):
    player = _TrailerPlayback()
    monitor = xbmc.Monitor()
    if start_playback() is False:
        return
    # Resolution/network buffering can exceed the old six-second tile timeout.
    deadline = time.monotonic() + 120
    while not player.finished and not player.isPlaying():
        if time.monotonic() >= deadline:
            log('Trailer startup wait expired; returning to ExtendedInfo')
            return
        if monitor.waitForAbort(0.2):
            return
    while not player.finished and player.isPlaying():
        if monitor.waitForAbort(0.2):
            return


def handle_next_info(next_info):
    info_type, data = next_info
    if info_type == 'actor':
        NAVIGATION_STACK.append({'type': 'actor', 'actor_id': data})
    elif info_type == 'media':
        NAVIGATION_STACK.append({'type': 'media', 'tmdb_id': data['id'], 'media_type': data['type']})
    elif info_type == 'season':
        NAVIGATION_STACK.append({'type': 'season', 'tv_id': data['tv_id'], 'season_num': data['season_num'], 'tv_name': data['tv_name']})

def handle_next_info_season(next_info, current_season):
    info_type, data = next_info
    if info_type == 'actor':
        NAVIGATION_STACK.append({'type': 'actor', 'actor_id': data})
    elif info_type == 'episode':
        NAVIGATION_STACK.append({'type': 'episode', 'tv_id': current_season['tv_id'], 'season_num': current_season['season_num'], 'episode_num': data, 'tv_name': current_season['tv_name']})

def handle_next_info_episode(next_info):
    info_type, data = next_info
    if info_type == 'actor':
        NAVIGATION_STACK.append({'type': 'actor', 'actor_id': data})

def _fmt_dmy(value):
    return datetime.strptime(value, '%Y-%m-%d').strftime(xbmc.getRegion('dateshort').replace('%-', '%'))


def run_actor_info(actor_id):
    return run_extended_info(actor_id, media_type="actor")
