# -*- coding: utf-8 -*-
import sys

from caches.navigator_cache import navigator_cache as nc
from caches.settings_cache import get_setting, set_setting
from modules import kodi_utils as k
from modules import settings as s

# logger = k.logger


class Navigator:
	def __init__(self, params):
		self.params = params
		self.params_get = self.params.get
		self.category_name = self.params_get("name", "redlight")
		self.list_name = self.params_get("action", "RootList")
		self.is_external = k.external()
		self.make_listitem = k.make_listitem
		self.build_url = k.build_url
		self.add_item = k.add_item
		self.get_icon = k.get_icon
		self.fanart = k.get_addon_fanart()
		self.run_plugin = "RunPlugin(%s)"

	def main(self):
		def _process():
			for count, item in enumerate(browse_list):
				try:
					url = self.build_url(item)
					cm_items = [
						("[B]Move[/B]", self.run_plugin % self.build_url({"mode": "menu_editor.move", "active_list": self.list_name, "position": count})),
						("[B]Remove[/B]", self.run_plugin % self.build_url({"mode": "menu_editor.remove", "active_list": self.list_name, "position": count})),
						("[B]Add Content[/B]", self.run_plugin % self.build_url({"mode": "menu_editor.add", "active_list": self.list_name, "position": count})),
						(
							"[B]Restore Menu[/B]",
							self.run_plugin % self.build_url({"mode": "menu_editor.restore", "active_list": self.list_name, "position": count}),
						),
						(
							"[B]Check for New Menu Items[/B]",
							self.run_plugin % self.build_url({"mode": "menu_editor.update", "active_list": self.list_name, "position": count}),
						),
						(
							"[B]Reload Menu[/B]",
							self.run_plugin % self.build_url({"mode": "menu_editor.reload", "active_list": self.list_name, "position": count}),
						),
						(
							"[B]Browse Removed items[/B]",
							self.run_plugin % self.build_url({"mode": "menu_editor.browse", "active_list": self.list_name, "position": count}),
						),
						("[B]Add to Shortcut Folder[/B]", self.run_plugin % self.build_url({"mode": "menu_editor.shortcut_folder_add_known", "url": url})),
					]
					icon = item.get("iconImage", "")
					if not icon.startswith("http"):
						icon = self.get_icon(icon)
						item["iconImage"] = icon
					listitem = self.make_listitem()
					listitem.setLabel(item.get("name", ""))
					listitem.setArt({"icon": icon, "poster": icon, "thumb": icon, "fanart": self.fanart, "banner": icon, "landscape": icon})
					info_tag = listitem.getVideoInfoTag(True)
					info_tag.setPlot(" ")
					if not self.is_external:
						listitem.addContextMenuItems(cm_items)
					yield ((url, listitem, True), count)
				except:
					pass

		if self.params_get("full_list", "false") == "true":
			browse_list = nc.get_main_lists(self.list_name)[0]
		else:
			browse_list = nc.currently_used_list(self.list_name)
		results = sorted(list(_process()), key=lambda k: k[1])
		k.add_items(int(sys.argv[1]), [i[0] for i in results])
		self.end_directory()

	def discover(self):
		self.add({"mode": "navigator.discover_contents", "media_type": "movie"}, "Movies", "movies")
		self.add({"mode": "navigator.discover_contents", "media_type": "tvshow"}, "TV Shows", "tv")
		self.end_directory()

	def premium(self):
		if s.authorized_debrid_check("rd"):
			self.add({"mode": "navigator.real_debrid"}, "Real Debrid", "realdebrid")
		if s.authorized_debrid_check("pm"):
			self.add({"mode": "navigator.premiumize"}, "Premiumize", "premiumize")
		if s.authorized_debrid_check("ad"):
			self.add({"mode": "navigator.alldebrid"}, "All Debrid", "alldebrid")
		if s.authorized_debrid_check("tb"):
			self.add({"mode": "navigator.torbox"}, "TorBox", "torbox")
		if s.easynews_authorized():
			self.add({"mode": "navigator.easynews"}, "Easynews", "easynews")
		self.end_directory()

	def easynews(self):
		self.add({"mode": "navigator.search_history", "action": "easynews_video"}, "Search Videos", "search")
		self.add({"mode": "navigator.search_history", "action": "easynews_image"}, "Search Images", "search")
		self.add({"mode": "easynews.account_info", "isFolder": "false"}, "Account Info", "easynews")
		self.end_directory()

	def real_debrid(self):
		self.add({"mode": "real_debrid.rd_cloud"}, "Cloud Storage", "realdebrid")
		self.add({"mode": "real_debrid.rd_downloads"}, "History", "realdebrid")
		self.add({"mode": "real_debrid.rd_account_info", "isFolder": "false"}, "Account Info", "realdebrid")
		self.end_directory()

	def premiumize(self):
		self.add({"mode": "premiumize.pm_cloud"}, "Cloud Storage", "premiumize")
		self.add({"mode": "premiumize.pm_transfers"}, "History", "premiumize")
		self.add({"mode": "premiumize.pm_account_info", "isFolder": "false"}, "Account Info", "premiumize")
		self.end_directory()

	def alldebrid(self):
		self.add({"mode": "alldebrid.ad_cloud"}, "Cloud Storage", "alldebrid")
		self.add({"mode": "alldebrid.ad_downloads"}, "History", "alldebrid")
		self.add({"mode": "alldebrid.ad_saved_links"}, "Saved Links", "alldebrid")
		self.add({"mode": "alldebrid.ad_account_info", "isFolder": "false"}, "Account Info", "alldebrid")
		self.end_directory()

	def torbox(self):
		self.add({"mode": "torbox.tb_cloud"}, "Cloud Storage", "torbox")
		self.add({"mode": "torbox.tb_account_info", "isFolder": "false"}, "Account Info", "torbox")
		self.end_directory()

	def favorites(self):
		self.add({"mode": "build_movie_list", "action": "favorites_movies", "name": "Movies"}, "Movies", "movies")
		(self.add({"mode": "build_tvshow_list", "action": "favorites_tvshows", "name": "TV Shows"}, "TV Shows", "tv"),)
		(self.add({"mode": "build_tvshow_list", "action": "favorites_anime", "is_anime_list": "true", "name": "Anime"}, "Anime", "anime"),)
		self.add({"mode": "favorite_people", "isFolder": "false", "name": "People"}, "People", "empty_person")
		self.end_directory()

	def my_content(self):
		if s.trakt_user_active():
			self.add({"mode": "navigator.trakt_lists_personal"}, "Trakt Lists", "trakt")
		self.add({"mode": "navigator.trakt_lists_public"}, "Trakt Public Lists", "trakt")
		if s.tmdblist_user_active():
			self.add({"mode": "navigator.tmdb_lists_personal"}, "TMDb Lists", "tmdb")
		# if s.tmdblist_user_active(): self.add({'mode': 'tmdblist.get_tmdb_lists'}, 'TMDb Lists', 'tmdb')
		self.add({"mode": "personal_lists.get_personal_lists"}, "Personal Lists", "lists")
		self.add({"mode": "navigator.discover_contents", "media_type": "movie", "show_new": "false"}, "Discover Lists (Movies)", "movies")
		self.add({"mode": "navigator.discover_contents", "media_type": "tvshow", "show_new": "false"}, "Discover Lists (TV Shows)", "tv")
		self.end_directory()

	def tmdb_lists_personal(self):
		self.add({"mode": "navigator.tmdb_watchlists"}, "Watchlist", "tmdb")
		self.add({"mode": "navigator.tmdb_favorites"}, "Favorites", "tmdb")
		self.add({"mode": "navigator.tmdb_recommendations"}, "Recommendations", "tmdb")
		self.add({"mode": "tmdblist.get_tmdb_lists"}, "My Lists", "tmdb")
		self.end_directory()

	def tmdb_watchlists(self):
		self.category_name = "Watchlist"
		self.add(
			{"mode": "tmdblist.build_tmdb_list", "list_id": "watchlist", "media_type": "movie", "list_name": "Movie Watchlist"}, "Movies Watchlist", "tmdb"
		)
		self.add(
			{"mode": "tmdblist.build_tmdb_list", "list_id": "watchlist", "media_type": "tv", "list_name": "TV Show Watchlist"}, "TV Shows Watchlist", "tmdb"
		)
		self.end_directory()

	def tmdb_favorites(self):
		self.category_name = "Favorites"
		self.add({"mode": "tmdblist.build_tmdb_list", "list_id": "favorites", "media_type": "movie", "list_name": "Movie Favorites"}, "Movie Favorites", "tmdb")
		self.add(
			{"mode": "tmdblist.build_tmdb_list", "list_id": "favorites", "media_type": "tv", "list_name": "TV Show Favorites"}, "TV Show Favorites", "tmdb"
		)
		self.end_directory()

	def tmdb_recommendations(self):
		self.category_name = "Recommendations"
		self.add(
			{"mode": "tmdblist.build_tmdb_list", "list_id": "recommendations", "media_type": "movie", "list_name": "Movie Recommendations"},
			"Movie Recommendations",
			"tmdb",
		)
		self.add(
			{"mode": "tmdblist.build_tmdb_list", "list_id": "recommendations", "media_type": "tv", "list_name": "TV Show Recommendations"},
			"TV Show Recommendations",
			"tmdb",
		)
		self.end_directory()

	def trakt_lists_personal(self):
		self.add({"mode": "navigator.trakt_collections"}, "Collection", "trakt")
		self.add({"mode": "navigator.trakt_watchlists"}, "Watchlist", "trakt")
		self.add({"mode": "trakt.list.get_trakt_lists", "list_type": "my_lists", "category_name": "My Lists"}, "My Lists", "trakt")
		self.add({"mode": "trakt.list.get_trakt_lists", "list_type": "liked_lists", "category_name": "Liked Lists"}, "Liked Lists", "trakt")
		self.add({"mode": "navigator.trakt_favorites", "category_name": "Favorites"}, "Favorites", "trakt")
		self.add({"mode": "navigator.trakt_recommendations", "category_name": "Recommended"}, "Recommended", "trakt")
		self.add({"mode": "build_my_calendar"}, "Calendar", "trakt")
		self.end_directory()

	def trakt_lists_public(self):
		self.add({"mode": "trakt.list.get_trakt_user_lists", "list_type": "trending", "category_name": "Trending User Lists"}, "Trending User Lists", "trakt")
		self.add({"mode": "trakt.list.get_trakt_user_lists", "list_type": "popular", "category_name": "Popular User Lists"}, "Popular User Lists", "trakt")
		self.add({"mode": "navigator.search_history", "action": "trakt_lists"}, "Search User Lists", "search")
		self.end_directory()

	def random_lists(self):
		self.add({"mode": "navigator.build_random_lists", "menu_type": "movie"}, "Random Movie Lists", "movies")
		self.add({"mode": "navigator.build_random_lists", "menu_type": "tvshow"}, "Random TV Show Lists", "tv")
		self.add({"mode": "navigator.build_random_lists", "menu_type": "mixed"}, "Random Mixed Lists", "random")
		self.add({"mode": "navigator.build_random_lists", "menu_type": "anime"}, "Random Anime Lists", "anime")
		self.add({"mode": "navigator.build_random_lists", "menu_type": "because_you_watched"}, "Random Because You Watched", "because_you_watched")
		if s.tmdblist_user_active():
			self.add({"mode": "navigator.build_random_lists", "menu_type": "tmdb_lists"}, "Random TMDb Lists", "tmdb")
		self.add({"mode": "navigator.build_random_lists", "menu_type": "personal_lists"}, "Random Personal Lists", "lists")
		if s.trakt_user_active():
			self.add({"mode": "navigator.build_random_lists", "menu_type": "trakt_personal"}, "Random Trakt Lists (Personal)", "trakt")
			self.add({"mode": "navigator.build_random_lists", "menu_type": "trakt_public"}, "Random Trakt Lists (Public)", "trakt")
		self.end_directory()

	def trakt_collections(self):
		self.category_name = "Collection"
		self.add({"mode": "build_movie_list", "action": "trakt_collection", "category_name": "Movies Collection"}, "Movies Collection", "trakt")
		self.add({"mode": "build_tvshow_list", "action": "trakt_collection", "category_name": "TV Shows Collection"}, "TV Shows Collection", "trakt")
		self.add(
			{"mode": "build_movie_list", "action": "trakt_collection_lists", "new_page": "recent", "category_name": "Recently Added Movies"},
			"Recently Added Movies",
			"trakt",
		)
		self.add(
			{"mode": "build_tvshow_list", "action": "trakt_collection_lists", "new_page": "recent", "category_name": "Recently Added TV Shows"},
			"Recently Added TV Shows",
			"trakt",
		)
		self.add({"mode": "build_my_calendar", "recently_aired": "true"}, "Recently Aired Episodes", "trakt")
		self.end_directory()

	def trakt_watchlists(self):
		self.category_name = "Watchlist"
		self.add({"mode": "build_movie_list", "action": "trakt_watchlist", "category_name": "Movies Watchlist"}, "Movies Watchlist", "trakt")
		self.add({"mode": "build_tvshow_list", "action": "trakt_watchlist", "category_name": "TV Shows Watchlist"}, "TV Shows Watchlist", "trakt")
		self.add(
			{"mode": "build_movie_list", "action": "trakt_watchlist_lists", "new_page": "recent", "category_name": "Recently Added Movies"},
			"Recently Added Movies",
			"trakt",
		)
		self.add(
			{"mode": "build_tvshow_list", "action": "trakt_watchlist_lists", "new_page": "recent", "category_name": "Recently Added TV Shows"},
			"Recently Added TV Shows",
			"trakt",
		)
		self.end_directory()

	def trakt_recommendations(self):
		self.category_name = "Recommended"
		self.add({"mode": "build_movie_list", "action": "trakt_recommendations", "category_name": "Recommended Movies"}, "Movies Recommended", "trakt")
		self.add({"mode": "build_tvshow_list", "action": "trakt_recommendations", "category_name": "Recommended TV Shows"}, "TV Shows Recommended", "trakt")
		self.end_directory()

	def trakt_favorites(self):
		self.category_name = "Favorites"
		self.add({"mode": "build_movie_list", "action": "trakt_favorites", "category_name": "Favorite Movies"}, "Movies", "trakt")
		self.add({"mode": "build_tvshow_list", "action": "trakt_favorites", "category_name": "Favorite TV Shows"}, "TV Shows", "trakt")
		self.end_directory()

	def people(self):
		self.add({"mode": "build_tmdb_people", "action": "popular", "isFolder": "false", "name": "Popular"}, "Popular", "popular")
		self.add({"mode": "build_tmdb_people", "action": "day", "isFolder": "false", "name": "Trending"}, "Trending", "trending")
		self.add({"mode": "build_tmdb_people", "action": "week", "isFolder": "false", "name": "Trending This Week"}, "Trending This Week", "trending_recent")
		self.end_directory()

	def search(self):
		self.add({"mode": "navigator.search_history", "action": "movie", "name": "Search History Movies"}, "Search Movies", "movies")
		self.add({"mode": "navigator.search_history", "action": "tvshow", "name": "Search History TV Shows"}, "Search TV Shows", "tv")
		self.add({"mode": "navigator.search_history", "action": "anime", "name": "Search History Anime"}, "Search Anime", "anime")
		self.add({"mode": "navigator.search_history", "action": "tvshow_anime", "name": "Search History TV Show & Anime"}, "Search TV Show & Anime", "tv_anime")
		self.add({"mode": "navigator.search_history", "action": "people", "name": "Search History People"}, "Search People", "people")
		self.add(
			{"mode": "navigator.search_history", "action": "tmdb_keyword_movie", "name": "Search History Keywords (Movies)"}, "Search Keywords (Movies)", "tmdb"
		)
		self.add(
			{"mode": "navigator.search_history", "action": "tmdb_keyword_tvshow", "name": "Search History Keywords (TV Shows)"},
			"Search Keywords (TV Shows)",
			"tmdb",
		)
		self.add({"mode": "navigator.search_history", "action": "trakt_lists"}, "Search Trakt User Lists", "trakt")
		if s.easynews_authorized():
			self.add({"mode": "navigator.search_history", "action": "easynews_video"}, "Search Easynews Videos", "easynews")
			self.add({"mode": "navigator.search_history", "action": "easynews_image"}, "Search Easynews Images", "easynews")
		self.end_directory()

	def downloads(self):
		self.add({"mode": "downloader.manager", "name": "Download Manager", "isFolder": "false"}, "Download Manager", "downloads")
		self.add({"mode": "downloader.viewer", "folder_type": "movie", "name": "Movies"}, "Movies", "movies")
		self.add({"mode": "downloader.viewer", "folder_type": "episode", "name": "TV Shows"}, "TV Shows", "tv")
		self.add({"mode": "downloader.viewer", "folder_type": "premium", "name": "Premium Files"}, "Premium Files", "premium")
		self.add({"mode": "browser_image", "folder_path": s.download_directory("image"), "isFolder": "false"}, "Images", "people")
		self.end_directory()

	def tools(self):
		self.add({"mode": "open_settings", "isFolder": "false"}, "Settings", "settings")
		if get_setting("redlight.external_scraper.module") not in ("empty_setting", ""):
			self.add({"mode": "open_external_scraper_settings", "isFolder": "false"}, "External Scraper Settings", "settings")
		self.add({"mode": "navigator.tips"}, "Tips for Use", "settings2")
		if get_setting("redlight.use_viewtypes", "true") == "true" and not get_setting("redlight.manual_viewtypes", "false") == "true":
			self.add({"mode": "navigator.set_view_modes"}, "Set Views", "settings2")
		self.add({"mode": "navigator.changelog_utils"}, "Changelog & Log Utils", "settings2")
		self.add({"mode": "build_next_episode_manager"}, "TV Shows Progress Manager", "settings2")
		self.add({"mode": "navigator.shortcut_folders"}, "Shortcut Folders Manager", "settings2")
		self.add({"mode": "navigator.maintenance"}, "Database & Cache Maintenance", "settings2")
		self.add({"mode": "tmdbhelper.install_player", "isFolder": "false"}, "Install TMDBHelper Player", "settings2")
		self.add({"mode": "navigator.update_utils"}, "Update Utilities", "settings2")
		self.add({"mode": "language_invoker_choice", "isFolder": "false"}, "Toggle Language Invoker (ADVANCED!!)", "settings2")
		self.end_directory()

	def maintenance(self):
		self.add({"mode": "check_databases_integrity_cache", "isFolder": "false"}, "Check for Corrupt Databases", "settings")
		self.add({"mode": "clean_databases_cache", "isFolder": "false"}, "Clean Databases", "settings")
		self.add({"mode": "sync_settings", "silent": "false", "isFolder": "false"}, "Remake Settings Cache", "settings")
		self.add({"mode": "clear_all_cache", "isFolder": "false"}, "Clear All Cache (Excluding Favorites)", "settings")
		self.add({"mode": "clear_favorites_choice", "isFolder": "false"}, "Clear Favorites Cache", "settings")
		self.add({"mode": "search.clear_search", "isFolder": "false"}, "Clear Search History Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "main", "isFolder": "false"}, "Clear Main Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "meta", "isFolder": "false"}, "Clear Meta Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "list", "isFolder": "false"}, "Clear Lists Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "ai_functions", "isFolder": "false"}, "Clear AI Data Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "tmdb_list", "isFolder": "false"}, "Clear TMDb Personal List Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "skip_markers", "isFolder": "false"}, "Clear Skip Markers Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "trakt", "isFolder": "false"}, "Clear Trakt Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "imdb", "isFolder": "false"}, "Clear IMDb Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "internal_scrapers", "isFolder": "false"}, "Clear Internal Scrapers Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "external_scrapers", "isFolder": "false"}, "Clear External Scrapers Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "rd_cloud", "isFolder": "false"}, "Clear Real Debrid Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "pm_cloud", "isFolder": "false"}, "Clear Premiumize Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "ad_cloud", "isFolder": "false"}, "Clear All Debrid Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "ed_cloud", "isFolder": "false"}, "Clear Easy Debrid Cache", "settings")
		self.add({"mode": "clear_cache", "cache": "tb_cloud", "isFolder": "false"}, "Clear TorBox Cache", "settings")
		self.end_directory()

	def set_view_modes(self):
		self.add({"mode": "navigator.choose_view", "view_type": "view.main", "content": "", "name": "menus"}, "Set Menus", "folder")
		self.add({"mode": "navigator.choose_view", "view_type": "view.movies", "content": "movies"}, "Set Movies", "movies")
		self.add({"mode": "navigator.choose_view", "view_type": "view.tvshows", "content": "tvshows"}, "Set TV Shows", "tv")
		self.add({"mode": "navigator.choose_view", "view_type": "view.seasons", "content": "seasons"}, "Set Seasons", "ontheair")
		self.add({"mode": "navigator.choose_view", "view_type": "view.episodes", "content": "episodes"}, "Set Episodes", "next_episodes")
		self.add(
			{"mode": "navigator.choose_view", "view_type": "view.episodes_single", "content": "episodes", "name": "episode lists"},
			"Set Episode Lists",
			"calender",
		)
		self.add({"mode": "navigator.choose_view", "view_type": "view.premium", "content": "files", "name": "premium files"}, "Set Premium Files", "premium")
		self.end_directory()

	def update_utils(self):
		self.add({"mode": "updater.update_check", "isFolder": "false"}, "Check For Updates", "github")
		self.add({"mode": "updater.rollback_check", "isFolder": "false"}, "Rollback to a Previous Version", "github")
		self.add({"mode": "updater.get_changes", "isFolder": "false"}, "Check Online Version Changelog", "github")
		self.end_directory()

	def changelog_utils(self):
		log_loc, old_log_loc = k.translate_path("special://logpath/kodi.log"), k.translate_path("special://logpath/kodi.old.log")
		redlight_clogpath = k.translate_path("special://home/addons/plugin.video.redlight/resources/text/changelog.txt")
		self.add({"mode": "show_text", "heading": "Changelog", "file": redlight_clogpath, "font_size": "large", "isFolder": "false"}, "Changelog", "lists")
		self.add({"mode": "show_text", "heading": "Kodi Log Viewer", "file": log_loc, "kodi_log": "true", "isFolder": "false"}, "Kodi Log Viewer", "lists")
		self.add(
			{"mode": "show_text", "heading": "Kodi Log Viewer (Old)", "file": old_log_loc, "kodi_log": "true", "isFolder": "false"},
			"Kodi Log Viewer (Old)",
			"lists",
		)
		self.add({"mode": "upload_logfile", "isFolder": "false"}, "Upload Kodi Log to Pastebin", "lists")
		self.end_directory()

	def certifications(self):
		from modules.meta_lists import movie_certifications, tvshow_certifications

		menu_type = self.params_get("menu_type")
		function = movie_certifications if menu_type == "movie" else tvshow_certifications
		if menu_type == "movie":
			mode, action = "build_movie_list", "tmdb_movies_certifications"
		else:
			mode = "build_tvshow_list"
			if menu_type == "tvshow":
				action = "trakt_tv_certifications"
			else:
				action = "trakt_anime_certifications"
		for i in function():
			self.add({"mode": mode, "action": action, "key_id": i["id"], "name": i["name"]}, i["name"], "certifications")
		self.end_directory()

	def languages(self):
		from modules.meta_lists import languages as function

		menu_type = self.params_get("menu_type")
		if menu_type == "movie":
			mode, action = "build_movie_list", "tmdb_movies_languages"
		else:
			mode, action = "build_tvshow_list", "tmdb_tv_languages"
		for i in function():
			self.add({"mode": mode, "action": action, "key_id": i["id"], "name": i["name"]}, i["name"], "languages")
		self.end_directory()

	def years(self):
		menu_type = self.params_get("menu_type")
		if menu_type == "movie":
			from modules.meta_lists import years_movies as function

			mode, action = "build_movie_list", "tmdb_movies_year"
		else:
			mode = "build_tvshow_list"
			if menu_type == "tvshow":
				from modules.meta_lists import years_tvshows as function

				action = "tmdb_tv_year"
			else:
				from modules.meta_lists import years_anime as function

				action = "tmdb_anime_year"
		for i in function():
			self.add({"mode": mode, "action": action, "key_id": i["id"], "name": i["name"]}, i["name"], "calender")
		self.end_directory()

	def decades(self):
		menu_type = self.params_get("menu_type")
		if menu_type == "movie":
			from modules.meta_lists import decades_movies as function

			mode, action = "build_movie_list", "tmdb_movies_decade"
		else:
			mode = "build_tvshow_list"
			if menu_type == "tvshow":
				from modules.meta_lists import decades_tvshows as function

				action = "tmdb_tv_decade"
			else:
				from modules.meta_lists import decades_anime as function

				action = "tmdb_anime_decade"
		for i in function():
			self.add({"mode": mode, "action": action, "key_id": i["id"], "name": i["name"]}, i["name"], "calendar_decades")
		self.end_directory()

	def networks(self):
		menu_type = self.params_get("menu_type")
		if menu_type == "movie":
			return
		from modules.meta_lists import networks

		for i in sorted(networks(), key=lambda k: k["name"]):
			self.add(
				{"mode": "build_tvshow_list", "action": "tmdb_tv_networks", "key_id": i["id"], "name": i["name"]},
				i["name"],
				self.get_icon(i["logo"], "network_icons"),
				original_image=True,
			)
		self.end_directory()

	def _add_provider_icon(self, url_params, name, local_icon, tmdb_logo):
		# Shared brand/provider icon cascade used by Mixed Channels, Mixed Providers, and the Movie/TV
		# Providers menus: a crisp local network_icons basename wins, then the (smaller) TMDb provider
		# logo, then a generic icon. Keeping the fallback policy in one place stops the menus drifting
		# apart and guards every caller against a row that lacks both an icon and a logo.
		if local_icon:
			self.add(url_params, name, self.get_icon(local_icon, "network_icons"), original_image=True)
		elif tmdb_logo:
			self.add(url_params, name, "https://image.tmdb.org/t/p/original/%s" % tmdb_logo, original_image=True)
		else:
			self.add(url_params, name, "providers")

	def providers(self):
		menu_type = self.params_get("menu_type")
		if menu_type == "mixed":
			from modules.meta_lists import watch_providers_mixed

			for i in watch_providers_mixed():
				# Some TMDb provider names carry a trailing space (e.g. "… Apple TV Channel ").
				name = i["name"].strip()
				url_params = {"mode": "navigator.mixed_keyed_list", "action": "mixed_providers", "key_id": i["id"], "name": name}
				self._add_provider_icon(url_params, name, i.get("icon"), i.get("logo"))
			return self.end_directory()
		if menu_type == "movie":
			from modules.meta_lists import watch_providers_movies as function

			mode, action = "build_movie_list", "tmdb_movies_providers"
		else:
			from modules.meta_lists import watch_providers_tvshows as function

			mode = "build_tvshow_list"
			if menu_type == "tvshow":
				action = "tmdb_tv_providers"
			else:
				action = "tmdb_anime_providers"
		for i in function():
			url_params = {"mode": mode, "action": action, "key_id": i["id"], "name": i["name"]}
			self._add_provider_icon(url_params, i["name"], None, i.get("logo"))
		self.end_directory()

	def genres(self):
		menu_type = self.params_get("menu_type")
		if menu_type == "mixed":
			from modules.meta_lists import mixed_genres

			for i in mixed_genres():
				self.add(
					{"mode": "navigator.mixed_keyed_list", "action": "mixed_genres", "movie_key": i["movie_id"], "tv_key": i["tv_id"], "name": i["name"]},
					i["name"],
					i["icon"],
				)
			return self.end_directory()
		if menu_type == "movie":
			from modules.meta_lists import movie_genres as function

			mode, action = "build_movie_list", "tmdb_movies_genres"
		else:
			mode = "build_tvshow_list"
			if menu_type == "tvshow":
				from modules.meta_lists import tvshow_genres as function

				action = "tmdb_tv_genres"
			else:
				from modules.meta_lists import anime_genres as function

				action = "tmdb_anime_genres"
		for i in function():
			self.add({"mode": mode, "action": action, "key_id": i["id"], "name": i["name"]}, i["name"], i["icon"])
		self.end_directory()

	def search_history(self):
		from urllib.parse import unquote

		from caches.main_cache import main_cache

		search_mode_dict = {
			"movie": ("movie_queries", {"mode": "search.get_key_id", "media_type": "movie", "isFolder": "false"}),
			"tvshow": ("tvshow_queries", {"mode": "search.get_key_id", "media_type": "tv_show", "isFolder": "false"}),
			"anime": ("anime_queries", {"mode": "search.get_key_id", "media_type": "anime", "isFolder": "false"}),
			"tvshow_anime": ("tvshow_anime_queries", {"mode": "search.get_key_id", "media_type": "tvshow_anime", "isFolder": "false"}),
			"people": ("people_queries", {"mode": "search.get_key_id", "search_type": "people", "isFolder": "false"}),
			"tmdb_keyword_movie": (
				"keyword_tmdb_movie_queries",
				{"mode": "search.get_key_id", "search_type": "tmdb_keyword", "media_type": "movie", "isFolder": "false"},
			),
			"tmdb_keyword_tvshow": (
				"keyword_tmdb_tvshow_queries",
				{"mode": "search.get_key_id", "search_type": "tmdb_keyword", "media_type": "tvshow", "isFolder": "false"},
			),
			"trakt_lists": ("trakt_list_queries", {"mode": "search.get_key_id", "search_type": "trakt_lists", "isFolder": "false"}),
			"easynews_video": ("easynews_video_queries", {"mode": "search.get_key_id", "search_type": "easynews_video", "isFolder": "false"}),
			"easynews_image": ("easynews_image_queries", {"mode": "search.get_key_id", "search_type": "easynews_image", "isFolder": "false"}),
		}
		setting_id, action_dict = search_mode_dict[self.list_name]
		url_params = dict(action_dict)
		data = main_cache.get(setting_id) or []
		self.add(action_dict, "[B]NEW SEARCH...[/B]", "new")
		for i in data:
			try:
				key_id = unquote(i)
				url_params["key_id"] = key_id
				url_params["setting_id"] = setting_id
				cm_items = [
					("[B]Remove from history[/B]", "RunPlugin(%s)" % self.build_url({"mode": "search.remove", "setting_id": setting_id, "key_id": key_id})),
					("[B]Clear All History[/B]", "RunPlugin(%s)" % self.build_url({"mode": "search.clear_all", "setting_id": setting_id, "refresh": "true"})),
				]
				self.add(url_params, key_id, "calender", cm_items=cm_items)
			except:
				pass
		self.category_name = self.params_get("name") or "History"
		self.end_directory()

	def keyword_results(self):
		from apis.tmdb_api import tmdb_keywords_by_query

		media_type, key_id = self.params_get("media_type"), self.params_get("key_id") or self.params_get("query")
		try:
			page_no = int(self.params_get("new_page", "1"))
		except:
			page_no = self.params_get("new_page")
		mode = "build_movie_list" if media_type == "movie" else "build_tvshow_list"
		action = "tmdb_movie_keyword_results" if media_type == "movie" else "tmdb_tv_keyword_results"
		data = tmdb_keywords_by_query(key_id, page_no)
		results = data["results"]
		for item in results:
			name = item["name"].upper()
			self.add({"mode": mode, "action": action, "key_id": item["id"], "iconImage": "tmdb", "category_name": name}, name, iconImage="tmdb")
		if data["total_pages"] > page_no:
			new_page = {"mode": "navigator.keyword_results", "key_id": key_id, "category_name": self.category_name, "new_page": str(data["page"] + 1)}
			self.add(new_page, "Next Page (%s) >>" % new_page["new_page"], "nextpage", False)
		self.category_name = "Search Results for %s" % key_id.upper()
		self.end_directory()

	def choose_view(self):
		handle = int(sys.argv[1])
		content = self.params["content"]
		view_type, name = self.params["view_type"], self.params.get("name") or content
		self.add({"mode": "navigator.set_view", "view_type": view_type, "name": name, "isFolder": "false"}, "Set view and then click here", "settings")
		k.set_content(handle, content)
		k.end_directory(handle)
		k.set_view_mode(view_type, content, False)

	def set_view(self):
		window = k.current_window_object()
		if window is None:
			return
		set_setting(self.params["view_type"], str(window.getFocusId()))
		k.notification("%s: %s" % (self.params["name"].upper(), k.get_infolabel("Container.Viewmode").upper()), time=500)

	def shortcut_folders(self):
		folders = nc.get_shortcut_folders()
		if folders:
			for i in folders:
				name = i[0]
				convert_sr = "[B]Remove Random[/B]" if "[COLOR red][RANDOM][/COLOR]" in name else "[B]Make Random[/B]"
				cm_items = [
					("[B]Rename[/B]", self.run_plugin % self.build_url({"mode": "menu_editor.shortcut_folder_rename"})),
					("[B]Delete Folder[/B]", self.run_plugin % self.build_url({"mode": "menu_editor.shortcut_folder_delete"})),
					("[B]Make New Folder[/B]", self.run_plugin % self.build_url({"mode": "menu_editor.shortcut_folder_make"})),
					(convert_sr, self.run_plugin % self.build_url({"mode": "menu_editor.shortcut_folder_convert", "name": name})),
				]
				self.add({"mode": "navigator.build_shortcut_folder_contents", "name": name, "iconImage": "folder"}, name, "folder", cm_items=cm_items)
		else:
			self.add({"mode": "menu_editor.shortcut_folder_make", "isFolder": "false"}, "[I]Make New Folder...[/I]", "new")
		self.category_name = "Shortcut Folders"
		self.end_directory()

	def build_shortcut_folder_contents(self):
		list_name = self.params_get("name")
		is_random = "[COLOR red][RANDOM][/COLOR]" in list_name
		contents = nc.get_shortcut_folder_contents(list_name)
		folder_icon = self.get_icon("folder")
		if is_random:
			from indexers.random_lists import random_shortcut_folders

			return random_shortcut_folders(list_name.replace(" [COLOR red][RANDOM][/COLOR]", ""), contents)
		if contents:
			for count, item in enumerate(contents):
				item_get = item.get
				iconImage = item_get("iconImage", None)
				icon = iconImage
				if iconImage:
					if iconImage.startswith("http") or "plugin.video.redlight" in iconImage:
						original_image = True
					else:
						original_image = False
				else:
					icon, original_image = folder_icon, False
				cm_items = [
					(
						"[B]Move[/B]",
						self.run_plugin
						% self.build_url({"mode": "menu_editor.shortcut_folder_edit", "active_list": list_name, "position": count, "action": "move"}),
					),
					(
						"[B]Remove[/B]",
						self.run_plugin
						% self.build_url({"mode": "menu_editor.shortcut_folder_edit", "active_list": list_name, "position": count, "action": "remove"}),
					),
					("[B]Add Content[/B]", self.run_plugin % self.build_url({"mode": "menu_editor.shortcut_folder_add", "name": list_name})),
					(
						"[B]Rename[/B]",
						self.run_plugin
						% self.build_url({"mode": "menu_editor.shortcut_folder_edit", "active_list": list_name, "position": count, "action": "rename"}),
					),
					(
						"[B]Clear All[/B]",
						self.run_plugin
						% self.build_url({"mode": "menu_editor.shortcut_folder_edit", "active_list": list_name, "position": count, "action": "clear"}),
					),
				]
				self.add(item, item_get("name"), icon, original_image, cm_items=cm_items)
		elif is_random:
			pass
		else:
			self.add({"mode": "menu_editor.shortcut_folder_add", "name": list_name, "isFolder": "false"}, "[I]Add Content...[/I]", "new")
		self.end_directory()

	def discover_contents(self):
		from caches.discover_cache import discover_cache

		action, media_type = self.params_get("action", ""), self.params_get("media_type")
		if not action:
			if self.params_get("show_new", "true") == "true":
				self.add({"mode": "discover_choice", "media_type": media_type, "isFolder": "false"}, "[I]Make New Discover List...[/I]", "new")
			results = discover_cache.get_all(media_type)
			if media_type == "movie":
				mode, action = "build_movie_list", "tmdb_movies_discover"
			else:
				mode, action = "build_tvshow_list", "tmdb_tv_discover"
			for item in results:
				name, data = item["id"], item["data"]
				cm_items = [
					(
						"[B]Remove from history[/B]",
						"RunPlugin(%s)" % self.build_url({"mode": "navigator.discover_contents", "action": "delete_one", "name": name}),
					),
					(
						"[B]Clear All History[/B]",
						"RunPlugin(%s)" % self.build_url({"mode": "navigator.discover_contents", "action": "clear_cache", "media_type": media_type}),
					),
				]
				if "[random]" in data:
					self.add(
						{"mode": "random.%s" % mode, "action": action, "name": name, "url": data, "new_page": "random", "random": "true"},
						name,
						"discover",
						cm_items=cm_items,
					)
				else:
					self.add({"mode": mode, "action": action, "name": name, "url": data}, name, "discover", cm_items=cm_items)
			self.end_directory()
		else:
			if action == "delete_one":
				discover_cache.delete_one(self.params_get("name"))
			elif action == "clear_cache":
				discover_cache.clear_cache(media_type)
			k.container_refresh()

	def exit_media_menu(self):
		params = k.get_property("redlight.exit_params")
		if params:
			return k.container_refresh_input(params)

	def tips(self):
		tips_location = "special://home/addons/plugin.video.redlight/resources/text/tips"
		files = sorted(k.list_dirs(tips_location)[1])
		tips_location += "/%s"
		tips_list = []
		tips_append = tips_list.append
		for item in files:
			tip = item.replace(".txt", "")[4:]
			if "!!HELP!!" in tip:
				tip, sort_order = tip.replace("!!HELP!!", "[COLOR crimson][B]HELP!!![/B][/COLOR] "), 0
			elif "!!NEW!!" in tip:
				tip, sort_order = tip.replace("!!NEW!!", "[COLOR chartreuse][B]NEW!![/B][/COLOR] "), 1
			elif "!!SPOTLIGHT!!" in tip:
				tip, sort_order = tip.replace("!!SPOTLIGHT!!", "[COLOR orange][B]SPOTLIGHT![/B][/COLOR] "), 2
			else:
				sort_order = 3
			params = {"mode": "show_text", "heading": tip, "file": k.translate_path(tips_location % item), "font_size": "large", "isFolder": "false"}
			tips_append((params, tip, sort_order))
		item_list = sorted(tips_list, key=lambda x: x[2])
		for c, i in enumerate(item_list, 1):
			self.add(i[0], "[B]%02d. [/B]%s" % (c, i[1]), "information")
		self.end_directory()

	def because_you_watched(self):
		from modules.episode_tools import single_last_watched_episodes
		from modules.watched_status import get_recently_watched

		recommend_type = s.recommend_service()
		menu_type = self.params_get("menu_type")
		action_dict = {
			"movie": {
				"mode": "build_movie_list",
				"action": {0: "tmdb_movies_recommendations", 1: "imdb_more_like_this", 2: "tmdb_movies_recommendations", 3: "trakt_movies_related"},
				"media_type": "movie",
			},
			"tvshow": {
				"mode": "build_tvshow_list",
				"action": {0: "tmdb_tv_recommendations", 1: "imdb_more_like_this", 2: "tmdb_tv_recommendations", 3: "trakt_tv_related"},
				"media_type": "episode",
			},
		}
		action_params = action_dict[menu_type]
		mode, action, media_type = action_params["mode"], action_params["action"][recommend_type], action_params["media_type"]
		recently_watched = get_recently_watched(media_type)
		if media_type == "episode":
			recently_watched = single_last_watched_episodes(recently_watched)
		for item in recently_watched:
			if media_type == "movie":
				name = item["title"]
				key_id = item["media_id"] if recommend_type in (0, 1, 3) else "movie|%s" % item["media_id"]
			else:
				name = "%s - %sx%s" % (item["title"], str(item["season"]), str(item["episode"]))
				key_id = item["media_ids"]["tmdb"] if recommend_type in (0, 1, 3) else "tvshow|%s" % item["media_ids"]["tmdb"]
			params = {"mode": mode, "action": action, "key_id": key_id, "name": "Because You Watched %s" % name}
			if recommend_type == 1:
				params["get_imdb"] = "true"
			self.add(params, name, "because_you_watched")
		self.end_directory()

	def build_random_lists(self):
		random_list_dict = {
			"movie": ("Random Movie Lists", nc.random_movie_lists),
			"tvshow": ("Random TV Show Lists", nc.random_tvshow_lists),
			"mixed": ("Random Mixed Lists", nc.random_mixed_lists),
			"anime": ("Random Anime Lists", nc.random_anime_lists),
			"because_you_watched": ("Random Because You Watched Lists", nc.random_because_you_watched_lists),
			"tmdb_lists": ("Random TMDb Lists", nc.random_tmdb_lists),
			"personal_lists": ("Random Personal Lists", nc.random_personal_lists),
			"trakt_personal": ("Random Trakt Lists (Personal)", nc.random_trakt_lists_personal),
			"trakt_public": ("Random Trakt Lists (Public)", nc.random_trakt_lists_public),
		}
		self.category_name, function = random_list_dict[self.params_get("menu_type")]
		func = function()
		for item in func:
			self.add(item, item["name"], item["iconImage"])
		self.end_directory()

	def mixed(self):
		from modules.mixed_utils import MIXED_LIST_MENU

		self.category_name = "Mixed Movies & TV"
		self.add({"mode": "navigator.in_progress_mixed"}, "Mixed In Progress", "player")
		for label, action, icon in MIXED_LIST_MENU:
			self.add({"mode": "navigator.mixed_list", "action": action}, label, icon)
		self.add({"mode": "navigator.mixed_my_lists"}, "Mixed My Lists", "trakt")
		self.add({"mode": "navigator.genres", "menu_type": "mixed"}, "Mixed Genres", "genres")
		self.add({"mode": "navigator.providers", "menu_type": "mixed"}, "Mixed Providers", "providers")
		self.add({"mode": "navigator.mixed_brands"}, "Mixed Channels", "providers")
		self.end_directory()

	def in_progress_mixed(self):
		# Build phases run sequentially, not on their own threads. Crash investigation
		# (kodi_crashlog 2026-06-13, AV in python3.8.dll pymalloc free-block pop, RVA
		# 0x109516) traced repeated access violations to CPython allocator corruption
		# under redlight's nested thread fan-out: this handler spawned fetch/build threads
		# that each fan out further capped TaskPool threads, running concurrently with the
		# other home-screen widget scripts. Removing this handler's own thread layer keeps
		# the inner (joined, capped) pools while halving the script's peak concurrency.
		# See docs/ai-docs/changes-from-redlight.md.
		from indexers.episodes import build_single_episode
		from indexers.movies import Movies
		from modules import settings as _settings
		from modules.metadata import is_anime_check
		from modules.watched_status import get_in_progress_episodes, get_in_progress_movies

		handle = int(sys.argv[1])
		try:
			page_no = max(1, int(self.params_get("new_page", "1")))
		except (TypeError, ValueError):
			page_no = 1
		per_type = 20
		# redlight.exit_params drives the context-menu "Exit … List" action only (Navigator.exit_media_menu);
		# plain back navigation does not consume it, so stale values are harmless across visits.
		if page_no == 1 and not self.is_external:
			k.set_property("redlight.exit_params", k.folder_path())
		k.logger("redlight", "in_progress_mixed: page=%s start" % page_no)

		movie_data, episode_data = [], []

		def _fetch_movies():
			try:
				movie_data.extend(get_in_progress_movies("movie", 1) or [])
			except Exception as e:
				k.logger("redlight", "in_progress_mixed._fetch_movies: %s" % e)

		def _fetch_episodes():
			try:
				episode_data.extend(get_in_progress_episodes() or [])
			except Exception as e:
				k.logger("redlight", "in_progress_mixed._fetch_episodes: %s" % e)

		_fetch_movies()
		_fetch_episodes()

		if not _settings.mixed_include_anime() and episode_data:
			show_ids = {e.get("media_ids", {}).get("tmdb") for e in episode_data}
			show_ids.discard(None)
			anime_show_ids = {sid for sid in show_ids if is_anime_check(tmdb_id=sid)}
			if anime_show_ids:
				before = len(episode_data)
				episode_data[:] = [e for e in episode_data if e.get("media_ids", {}).get("tmdb") not in anime_show_ids]
				k.logger("redlight", "in_progress_mixed: dropped %s anime episode(s)" % (before - len(episode_data)))

		movie_data.sort(key=lambda x: x.get("last_played") or 0, reverse=True)
		episode_data.sort(key=lambda x: x.get("date") or 0, reverse=True)

		start, end = (page_no - 1) * per_type, page_no * per_type
		movie_page = movie_data[start:end]
		episode_page = episode_data[start:end]
		has_next = len(movie_data) > end or len(episode_data) > end

		for m in movie_page:
			m["_mixed_type"], m["_sort_ts"] = "movie", m.get("last_played") or 0
		for e in episode_page:
			e["_mixed_type"], e["_sort_ts"] = "episode", e.get("date") or 0

		combined = sorted(movie_page + episode_page, key=lambda x: x["_sort_ts"], reverse=True)
		for idx, item in enumerate(combined):
			item["_order"] = idx

		movie_items = [(item["_order"], item["media_id"]) for item in combined if item["_mixed_type"] == "movie"]
		episode_items = [dict(item, custom_order=item["_order"]) for item in combined if item["_mixed_type"] == "episode"]

		results = {"movies": [], "episodes": []}

		# Fan-out cap: per_type * 2 = 40 items per page. Movies.worker() and build_single_episode()
		# each fan out further metadata threads via TaskPool over their slice, bounded by that cap.
		def _build_movies():
			if not movie_items:
				return
			try:
				params = {"list": movie_items, "custom_order": "true", "id_type": "tmdb_id", "menu_type": "movie", "action": "in_progress_movies"}
				results["movies"] = Movies(params).worker() or []
			except Exception as e:
				k.logger("redlight", "in_progress_mixed._build_movies: %s" % e)

		def _build_episodes():
			# build_single_episode falls through to the "params is a list" escape hatch
			# (episodes.py:730) when list_type is unrecognised — returns
			# [(list_items, sort_order), ...] tuples instead of rendering directly.
			if not episode_items:
				return
			try:
				results["episodes"] = build_single_episode("episode.mixed_in_progress", episode_items) or []
			except Exception as e:
				k.logger("redlight", "in_progress_mixed._build_episodes: %s" % e)

		_build_movies()
		_build_episodes()

		item_list = results["movies"] + results["episodes"]
		item_list.sort(key=lambda entry: entry[1])
		item_list = [entry[0] for entry in item_list]

		content_type = "movies" if len(movie_items) >= len(episode_items) else "episodes"
		self.category_name = "Mixed In Progress"
		k.add_items(handle, item_list)
		if has_next:
			next_page = str(page_no + 1)
			k.add_dir(
				handle,
				{"mode": "navigator.in_progress_mixed", "new_page": next_page},
				"Next Page (%s) >>" % next_page,
				"nextpage",
				k.get_icon("nextpage_landscape"),
			)
		k.set_content(handle, content_type)
		k.set_category(handle, self.category_name)
		k.end_directory(handle, cacheToDisc=False if self.is_external else True)
		if not self.is_external:
			view_key = "view.episodes_single" if content_type == "episodes" else "view.movies"
			k.set_view_mode(view_key, content_type, self.is_external)
		k.logger("redlight", "in_progress_mixed: page=%s done (movies=%s episodes=%s)" % (page_no, len(movie_items), len(episode_items)))

	def _finish_mixed_directory(self, handle, combined, n_movies, n_shows, label, next_page_params=None, next_page=None, shuffle_if_random=False):
		# Shared render tail for the Mixed * handlers (mixed_list, mixed_keyed_list, mixed_my_list,
		# mixed_brand_list): optionally shuffle on a widget sort_by=random, pick the content type from
		# the bucket sizes, add the items, optionally append a Next Page link, finalize the directory
		# and set the view. `n_shows` should include any anime bucket. Returns the chosen content_type.
		from modules import settings as _settings

		# Honor sort_by=random (what a user adds to a widget path) by shuffling the rendered page in
		# place. The keyed/brand/personal lists opt in; only the paginated mixed_list does not.
		if shuffle_if_random and (self.params_get("sort_by", "") == "random" or self.params_get("random", "") == "true"):
			from random import shuffle

			shuffle(combined)
		content_type = "movies" if n_movies >= n_shows else "tvshows"
		self.category_name = label
		k.add_items(handle, combined)
		# Skip the Next Page link when this page is empty (would otherwise loop forever pointing to
		# another empty page) and when the user has hidden it in widgets.
		if next_page_params is not None and combined and not (self.is_external and _settings.widget_hide_next_page()):
			k.add_dir(handle, dict(next_page_params, new_page=str(next_page)), "Next Page (%s) >>" % next_page, "nextpage", k.get_icon("nextpage_landscape"))
		k.set_content(handle, content_type)
		k.set_category(handle, self.category_name)
		k.end_directory(handle, cacheToDisc=False if self.is_external else True)
		if not self.is_external:
			k.set_view_mode("view." + content_type, content_type, self.is_external)
		return content_type

	def mixed_list(self):
		from threading import Thread

		from indexers.movies import Movies
		from indexers.tvshows import TVShows
		from modules import settings as _settings
		from modules.mixed_utils import MIXED_LIST_MENU, MIXED_LIST_SOURCES, interleave_buckets, trakt_ids
		from modules.utils import manual_function_import

		handle = int(sys.argv[1])
		action = self.params_get("action", "")
		sources = MIXED_LIST_SOURCES.get(action)
		if not sources:
			k.logger("redlight", "mixed_list: unknown action %s" % action)
			k.end_directory(handle)
			return
		try:
			page_no = max(1, int(self.params_get("new_page", "1")))
		except (TypeError, ValueError):
			page_no = 1
		if page_no == 1 and not self.is_external:
			k.set_property("redlight.exit_params", k.folder_path())
		label = next((entry[0] for entry in MIXED_LIST_MENU if entry[1] == action), "Mixed")
		k.logger("redlight", "mixed_list: action=%s page=%s start" % (action, page_no))

		include_anime = _settings.mixed_include_anime()
		is_trakt = sources["api"] == "trakt"
		movie_fn = manual_function_import(*sources["movie"])
		tv_fn = manual_function_import(*sources["tv"])
		anime_fn = manual_function_import(*sources["anime"]) if include_anime else None

		movie_raw, show_raw, anime_raw = [], [], []

		def _fetch(target, fn):
			try:
				raw = fn(page_no)
				if is_trakt:
					target.extend(raw or [])
				else:
					target.extend((raw or {}).get("results", []) or [])
			except Exception as e:
				k.logger("redlight", "mixed_list._fetch %s: %s" % (getattr(fn, "__name__", "?"), e))

		fetch_threads = [Thread(target=_fetch, args=(movie_raw, movie_fn)), Thread(target=_fetch, args=(show_raw, tv_fn))]
		if anime_fn is not None:
			fetch_threads.append(Thread(target=_fetch, args=(anime_raw, anime_fn)))
		[t.start() for t in fetch_threads]
		[t.join() for t in fetch_threads]

		if is_trakt:
			movie_ids = [i for i in (trakt_ids(x, "movie") for x in movie_raw) if i]
			show_ids = [i for i in (trakt_ids(x, "show") for x in show_raw) if i]
			anime_ids = [i for i in (trakt_ids(x, "show") for x in anime_raw) if i]
			id_type = "trakt_dict"
		else:
			movie_ids = [x["id"] for x in movie_raw if x.get("id")]
			show_ids = [x["id"] for x in show_raw if x.get("id")]
			anime_ids = [x["id"] for x in anime_raw if x.get("id")]
			id_type = "tmdb_id"

		results = {"movies": [], "shows": [], "anime": []}

		def _build(bucket_key, builder_cls, ids, menu_type):
			if not ids:
				return
			try:
				params = {"list": ids, "id_type": id_type, "menu_type": menu_type, "action": action}
				results[bucket_key] = builder_cls(params).worker() or []
			except Exception as e:
				k.logger("redlight", "mixed_list._build %s: %s" % (bucket_key, e))

		build_threads = [
			Thread(target=_build, args=("movies", Movies, movie_ids, "movie")),
			Thread(target=_build, args=("shows", TVShows, show_ids, "tvshow")),
		]
		if anime_fn is not None:
			build_threads.append(Thread(target=_build, args=("anime", TVShows, anime_ids, "tvshow")))
		[t.start() for t in build_threads]
		[t.join() for t in build_threads]

		combined = interleave_buckets(results["movies"], results["shows"], results["anime"])
		self._finish_mixed_directory(
			handle,
			combined,
			len(results["movies"]),
			len(results["shows"]) + len(results["anime"]),
			label,
			next_page_params={"mode": "navigator.mixed_list", "action": action},
			next_page=page_no + 1,
		)
		k.logger(
			"redlight",
			"mixed_list: action=%s page=%s done (movies=%s shows=%s anime=%s)"
			% (action, page_no, len(results["movies"]), len(results["shows"]), len(results["anime"])),
		)

	def mixed_keyed_list(self):
		# Keyed sibling of mixed_list: the source functions take (key_id, page_no) instead of
		# (page_no). Used by Mixed Genres (separate movie/tv genre ids) and Mixed Providers
		# (shared id). TMDb-only — no Trakt branch needed.
		from threading import Thread

		from indexers.movies import Movies
		from indexers.tvshows import TVShows
		from modules import settings as _settings
		from modules.mixed_utils import MIXED_KEYED_SOURCES, interleave_buckets
		from modules.utils import manual_function_import

		handle = int(sys.argv[1])
		action = self.params_get("action", "")
		sources = MIXED_KEYED_SOURCES.get(action)
		if not sources:
			k.logger("redlight", "mixed_keyed_list: unknown action %s" % action)
			k.end_directory(handle)
			return
		# Mixed Providers passes a single key_id (same id for both types); Mixed Genres passes
		# distinct movie_key/tv_key. Anime reuses the tv key (tmdb_anime_* are /discover/tv calls).
		movie_key = self.params_get("movie_key") or self.params_get("key_id")
		tv_key = self.params_get("tv_key") or self.params_get("key_id")
		anime_key = tv_key
		if not movie_key or not tv_key:
			k.logger("redlight", "mixed_keyed_list: missing key for action %s" % action)
			k.end_directory(handle)
			return
		try:
			page_no = max(1, int(self.params_get("new_page", "1")))
		except (TypeError, ValueError):
			page_no = 1
		if page_no == 1 and not self.is_external:
			k.set_property("redlight.exit_params", k.folder_path())
		label = self.params_get("name", "Mixed")
		k.logger("redlight", "mixed_keyed_list: action=%s page=%s start" % (action, page_no))

		include_anime = _settings.mixed_include_anime()
		movie_fn = manual_function_import(*sources["movie"])
		tv_fn = manual_function_import(*sources["tv"])
		anime_fn = manual_function_import(*sources["anime"]) if include_anime else None

		movie_raw, show_raw, anime_raw = [], [], []

		def _fetch(target, fn, key):
			try:
				raw = fn(key, page_no)
				target.extend((raw or {}).get("results", []) or [])
			except Exception as e:
				k.logger("redlight", "mixed_keyed_list._fetch %s: %s" % (getattr(fn, "__name__", "?"), e))

		fetch_threads = [Thread(target=_fetch, args=(movie_raw, movie_fn, movie_key)), Thread(target=_fetch, args=(show_raw, tv_fn, tv_key))]
		if anime_fn is not None:
			fetch_threads.append(Thread(target=_fetch, args=(anime_raw, anime_fn, anime_key)))
		[t.start() for t in fetch_threads]
		[t.join() for t in fetch_threads]

		movie_ids = [x["id"] for x in movie_raw if x.get("id")]
		show_ids = [x["id"] for x in show_raw if x.get("id")]
		anime_ids = [x["id"] for x in anime_raw if x.get("id")]

		results = {"movies": [], "shows": [], "anime": []}

		def _build(bucket_key, builder_cls, ids, menu_type):
			if not ids:
				return
			try:
				params = {"list": ids, "id_type": "tmdb_id", "menu_type": menu_type, "action": action}
				results[bucket_key] = builder_cls(params).worker() or []
			except Exception as e:
				k.logger("redlight", "mixed_keyed_list._build %s: %s" % (bucket_key, e))

		build_threads = [
			Thread(target=_build, args=("movies", Movies, movie_ids, "movie")),
			Thread(target=_build, args=("shows", TVShows, show_ids, "tvshow")),
		]
		if anime_fn is not None:
			build_threads.append(Thread(target=_build, args=("anime", TVShows, anime_ids, "tvshow")))
		[t.start() for t in build_threads]
		[t.join() for t in build_threads]

		combined = interleave_buckets(results["movies"], results["shows"], results["anime"])
		# Like mixed_brand_list, this is a live popularity-paginated TMDb query, so a sort_by=random
		# shuffle reorders the current page's titles rather than the whole catalog. Covers both Mixed
		# Providers and Mixed Genres (they share this handler).
		self._finish_mixed_directory(
			handle,
			combined,
			len(results["movies"]),
			len(results["shows"]) + len(results["anime"]),
			label,
			next_page_params={"mode": "navigator.mixed_keyed_list", "action": action, "name": label, "movie_key": movie_key, "tv_key": tv_key},
			next_page=page_no + 1,
			shuffle_if_random=True,
		)
		k.logger(
			"redlight",
			"mixed_keyed_list: action=%s page=%s done (movies=%s shows=%s anime=%s)"
			% (action, page_no, len(results["movies"]), len(results["shows"]), len(results["anime"])),
		)

	def mixed_my_lists(self):
		# Submenu of the user's own lists, each blended movie+TV (Mixed My Lists).
		from modules.mixed_utils import MIXED_MY_LIST_MENU

		self.category_name = "Mixed My Lists"
		for label, action, icon in MIXED_MY_LIST_MENU:
			self.add({"mode": "navigator.mixed_my_list", "action": action}, label, icon)
		self.end_directory()

	def mixed_my_list(self):
		# Personal-list sibling of mixed_list: blends the movie and TV halves of one of the user's
		# own lists (Trakt collection/watchlist, TMDb watchlist/favorites/recommendations). These
		# return the whole list at once — no page param, no anime bucket, no Next Page link — and
		# carry ids in non-standard shapes, so the source row (MIXED_MY_LIST_SOURCES) carries the
		# api/id_field/id_type/tv_media_type as data; only the fetch mechanism branches on api.
		from threading import Thread

		from indexers.movies import Movies
		from indexers.tmdb_lists import get_tmdb_list
		from indexers.tvshows import TVShows
		from modules.mixed_utils import MIXED_MY_LIST_SOURCES, interleave_buckets
		from modules.utils import manual_function_import

		handle = int(sys.argv[1])
		action = self.params_get("action", "")
		sources = MIXED_MY_LIST_SOURCES.get(action)
		if not sources:
			k.logger("redlight", "mixed_my_list: unknown action %s" % action)
			k.end_directory(handle)
			return
		if not self.is_external:
			k.set_property("redlight.exit_params", k.folder_path())
		label, id_field = sources["label"], sources["id_field"]
		k.logger("redlight", "mixed_my_list: action=%s start" % action)

		movie_raw, show_raw = [], []

		def _fetch(target, media_type):
			try:
				if sources["api"] == "trakt":
					# Trakt fetchers take (media_type, "") and already sort their side internally.
					raw = manual_function_import(*sources["fn"])(media_type, "")
				else:
					# get_tmdb_list applies the same "Contents sort order" setting the single-type
					# TMDb list uses, so a list and its mixed counterpart order identically per side.
					raw = get_tmdb_list({"list_id": sources["list_id"], "media_type": media_type})
				target.extend([i[id_field] for i in (raw or []) if i.get(id_field)])
			except Exception as e:
				k.logger("redlight", "mixed_my_list._fetch %s/%s: %s" % (action, media_type, e))

		fetch_threads = [Thread(target=_fetch, args=(movie_raw, "movie")), Thread(target=_fetch, args=(show_raw, sources["tv_media_type"]))]
		[t.start() for t in fetch_threads]
		[t.join() for t in fetch_threads]

		id_type = sources["id_type"]
		results = {"movies": [], "shows": []}

		def _build(bucket_key, builder_cls, ids, menu_type):
			if not ids:
				return
			try:
				params = {"list": ids, "id_type": id_type, "menu_type": menu_type, "action": action}
				results[bucket_key] = builder_cls(params).worker() or []
			except Exception as e:
				k.logger("redlight", "mixed_my_list._build %s: %s" % (bucket_key, e))

		build_threads = [
			Thread(target=_build, args=("movies", Movies, movie_raw, "movie")),
			Thread(target=_build, args=("shows", TVShows, show_raw, "tvshow")),
		]
		[t.start() for t in build_threads]
		[t.join() for t in build_threads]

		combined = interleave_buckets(results["movies"], results["shows"])
		self._finish_mixed_directory(handle, combined, len(results["movies"]), len(results["shows"]), label, shuffle_if_random=True)
		k.logger("redlight", "mixed_my_list: action=%s done (movies=%s shows=%s)" % (action, len(results["movies"]), len(results["shows"])))

	def mixed_brands(self):
		# Menu of curated streaming "brands" (Mixed Channels). Each row carries pipe-joined provider
		# + network id strings consumed by mixed_brand_list. Logos resolve from watch_providers data.
		from modules.meta_lists import mixed_brands as get_brands

		self.category_name = "Mixed Channels"
		for b in get_brands():
			url_params = {"mode": "navigator.mixed_brand_list", "name": b["name"], "providers": b["providers"], "networks": b["networks"]}
			# Prefer crisp local network icons (same source as the TV Networks menu): an explicit
			# per-brand override, then the networks.json icon; fall back to the TMDb provider logo,
			# then a generic icon.
			self._add_provider_icon(url_params, b["name"], b["icon"] or b["network_logo"], b["logo"])
		self.end_directory()

	def mixed_brand_list(self):
		# Curated "brand" sibling of mixed_keyed_list. Movies come from the watch provider; TV is the
		# OR of network originals + streamable providers (two /discover/tv queries merged + deduped,
		# because TMDb ANDs different filter params). providers/networks are pipe-joined id strings.
		from threading import Thread

		from apis.tmdb_api import tmdb_anime_providers, tmdb_movies_providers, tmdb_tv_networks, tmdb_tv_providers
		from indexers.movies import Movies
		from indexers.tvshows import TVShows
		from modules import settings as _settings
		from modules.mixed_utils import dedupe_by_id, interleave_buckets

		handle = int(sys.argv[1])
		providers = self.params_get("providers", "")
		networks = self.params_get("networks", "")
		if not providers and not networks:
			k.logger("redlight", "mixed_brand_list: no providers/networks")
			k.end_directory(handle)
			return
		try:
			page_no = max(1, int(self.params_get("new_page", "1")))
		except (TypeError, ValueError):
			page_no = 1
		if page_no == 1 and not self.is_external:
			k.set_property("redlight.exit_params", k.folder_path())
		label = self.params_get("name", "Mixed")
		k.logger("redlight", "mixed_brand_list: name=%s page=%s start" % (label, page_no))

		include_anime = _settings.mixed_include_anime()
		movie_raw, tv_provider_raw, tv_network_raw, anime_raw = [], [], [], []

		def _fetch(target, fn, key):
			try:
				raw = fn(key, page_no)
				target.extend((raw or {}).get("results", []) or [])
			except Exception as e:
				k.logger("redlight", "mixed_brand_list._fetch %s: %s" % (getattr(fn, "__name__", "?"), e))

		fetch_threads = []
		if providers:
			fetch_threads.append(Thread(target=_fetch, args=(movie_raw, tmdb_movies_providers, providers)))
			fetch_threads.append(Thread(target=_fetch, args=(tv_provider_raw, tmdb_tv_providers, providers)))
			if include_anime:
				fetch_threads.append(Thread(target=_fetch, args=(anime_raw, tmdb_anime_providers, providers)))
		if networks:
			fetch_threads.append(Thread(target=_fetch, args=(tv_network_raw, tmdb_tv_networks, networks)))
		[t.start() for t in fetch_threads]
		[t.join() for t in fetch_threads]

		# TV bucket = network originals OR streamable providers, deduped (TMDb ANDs filter params,
		# so the OR has to happen here across two responses rather than in one query). Interleave the
		# two sources before dedupe so originals and streamable titles blend throughout the page
		# instead of all-streamable-then-all-originals.
		show_raw = dedupe_by_id(interleave_buckets(tv_provider_raw, tv_network_raw))
		movie_ids = [x["id"] for x in movie_raw if x.get("id")]
		show_ids = [x["id"] for x in show_raw if x.get("id")]
		anime_ids = [x["id"] for x in anime_raw if x.get("id")]

		results = {"movies": [], "shows": [], "anime": []}

		def _build(bucket_key, builder_cls, ids, menu_type):
			if not ids:
				return
			try:
				params = {"list": ids, "id_type": "tmdb_id", "menu_type": menu_type, "action": "mixed_brands"}
				results[bucket_key] = builder_cls(params).worker() or []
			except Exception as e:
				k.logger("redlight", "mixed_brand_list._build %s: %s" % (bucket_key, e))

		build_threads = [
			Thread(target=_build, args=("movies", Movies, movie_ids, "movie")),
			Thread(target=_build, args=("shows", TVShows, show_ids, "tvshow")),
		]
		if include_anime:
			build_threads.append(Thread(target=_build, args=("anime", TVShows, anime_ids, "tvshow")))
		[t.start() for t in build_threads]
		[t.join() for t in build_threads]

		combined = interleave_buckets(results["movies"], results["shows"], results["anime"])
		# This list is a live popularity-paginated TMDb query, so a sort_by=random shuffle reorders
		# the current page's titles rather than the whole catalog (handled in _finish_mixed_directory).
		self._finish_mixed_directory(
			handle,
			combined,
			len(results["movies"]),
			len(results["shows"]) + len(results["anime"]),
			label,
			next_page_params={"mode": "navigator.mixed_brand_list", "name": label, "providers": providers, "networks": networks},
			next_page=page_no + 1,
			shuffle_if_random=True,
		)
		k.logger(
			"redlight",
			"mixed_brand_list: name=%s page=%s done (movies=%s shows=%s anime=%s)"
			% (label, page_no, len(results["movies"]), len(results["shows"]), len(results["anime"])),
		)

	def add(self, url_params, list_name, iconImage="folder", original_image=False, cm_items=[]):
		isFolder = url_params.get("isFolder", "true") == "true"
		try:
			if original_image:
				icon = iconImage
			else:
				icon = self.get_icon(iconImage)
		except:
			pass
		url_params["iconImage"] = icon
		url = self.build_url(url_params)
		listitem = self.make_listitem()
		listitem.setLabel(list_name)
		listitem.setArt({"icon": icon, "poster": icon, "thumb": icon, "fanart": self.fanart, "banner": icon, "landscape": icon})
		info_tag = listitem.getVideoInfoTag(True)
		info_tag.setPlot(" ")
		if not self.is_external:
			if isFolder:
				url_params.update({"iconImage": iconImage, "name": list_name})
				folder_item = (
					"[B]Add to Shortcut Folder[/B]",
					self.run_plugin % self.build_url({"mode": "menu_editor.shortcut_folder_add_known", "url": self.build_url(url_params)}),
				)
				if cm_items:
					cm_items.append(folder_item)
				else:
					cm_items = [folder_item]
			listitem.addContextMenuItems(cm_items)
		self.add_item(int(sys.argv[1]), url, listitem, isFolder)

	def end_directory(self):
		handle = int(sys.argv[1])
		k.set_content(handle, "")
		k.set_category(handle, self.category_name)
		k.end_directory(handle)
		k.set_view_mode("view.main", "")
